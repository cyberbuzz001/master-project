"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DhanAdapter = void 0;
const ws_1 = __importDefault(require("ws"));
const SafetyLock_1 = require("../services/SafetyLock");
const dhanTokenRefresh_1 = require("../utils/dhanTokenRefresh");
const telegramAlert_1 = require("../utils/telegramAlert");
class DhanAdapter {
    name = 'DHAN';
    healthy = false;
    ws = null;
    reconnectTimer = null;
    reconnectAttempts = 0;
    lastErrorWasRateLimit = false;
    connectedAt = 0;
    tokenCheckInterval = null;
    pingTimer = null;
    livenessWatchdogTimer = null;
    callbacks = new Set();
    tickCache = new Map();
    subscribedTokens = new Set();
    requestedTokens = new Set();
    subscribedSecurityIds = new Set();
    clientId;
    accessToken;
    apiKey;
    apiSecret;
    baseUrl = 'https://api.dhan.co';
    wsUrl = 'wss://api-feed.dhan.co';
    // Common Dhan Security IDs mapping
    static DHAN_SECURITY_MAP = {
        'NSE_NIFTY50': { segment: 'IDX_I', securityId: '13' },
        'NSE_NIFTY': { segment: 'IDX_I', securityId: '13' },
        'NIFTY': { segment: 'IDX_I', securityId: '13' },
        'NSE_BANKNIFTY': { segment: 'IDX_I', securityId: '25' },
        'BANKNIFTY': { segment: 'IDX_I', securityId: '25' },
        'BSE_SENSEX': { segment: 'IDX_I', securityId: '51' },
        'SENSEX': { segment: 'IDX_I', securityId: '51' },
        'NSE_FINNIFTY': { segment: 'IDX_I', securityId: '27' },
        'FINNIFTY': { segment: 'IDX_I', securityId: '27' },
        'NSE_MIDCPNIFTY': { segment: 'IDX_I', securityId: '33' },
        'MIDCPNIFTY': { segment: 'IDX_I', securityId: '33' },
        'NSE_RELIANCE': { segment: 'NSE_EQ', securityId: '2885' },
        'RELIANCE': { segment: 'NSE_EQ', securityId: '2885' },
        'NSE_TCS': { segment: 'NSE_EQ', securityId: '11536' },
        'TCS': { segment: 'NSE_EQ', securityId: '11536' },
        'NSE_INFY': { segment: 'NSE_EQ', securityId: '1594' },
        'INFY': { segment: 'NSE_EQ', securityId: '1594' },
        'NSE_HDFCBANK': { segment: 'NSE_EQ', securityId: '1333' },
        'HDFCBANK': { segment: 'NSE_EQ', securityId: '1333' },
        'NSE_ICICIBANK': { segment: 'NSE_EQ', securityId: '4963' },
        'ICICIBANK': { segment: 'NSE_EQ', securityId: '4963' },
        'NSE_SBIN': { segment: 'NSE_EQ', securityId: '3045' },
        'SBIN': { segment: 'NSE_EQ', securityId: '3045' },
        'NSE_ITC': { segment: 'NSE_EQ', securityId: '1660' },
        'ITC': { segment: 'NSE_EQ', securityId: '1660' },
        'NSE_BHARTIARTL': { segment: 'NSE_EQ', securityId: '10604' },
        'BHARTIARTL': { segment: 'NSE_EQ', securityId: '10604' },
        'NSE_LT': { segment: 'NSE_EQ', securityId: '11483' },
        'LT': { segment: 'NSE_EQ', securityId: '11483' },
        'NSE_MARUTI': { segment: 'NSE_EQ', securityId: '10999' },
        'MARUTI': { segment: 'NSE_EQ', securityId: '10999' },
        'NSE_TATAMOTORS': { segment: 'NSE_EQ', securityId: '3456' },
        'TATAMOTORS': { segment: 'NSE_EQ', securityId: '3456' },
        'NSE_TATASTEEL': { segment: 'NSE_EQ', securityId: '3499' },
        'TATASTEEL': { segment: 'NSE_EQ', securityId: '3499' },
        'NSE_WIPRO': { segment: 'NSE_EQ', securityId: '3787' },
        'WIPRO': { segment: 'NSE_EQ', securityId: '3787' },
        'NSE_BAJFINANCE': { segment: 'NSE_EQ', securityId: '317' },
        'BAJFINANCE': { segment: 'NSE_EQ', securityId: '317' },
        'NSE_ADANIENT': { segment: 'NSE_EQ', securityId: '25' },
        'ADANIENT': { segment: 'NSE_EQ', securityId: '25' },
        'NSE_ZOMATO': { segment: 'NSE_EQ', securityId: '5097' },
        'ZOMATO': { segment: 'NSE_EQ', securityId: '5097' },
        'NSE_KOTAKBANK': { segment: 'NSE_EQ', securityId: '1922' },
        'KOTAKBANK': { segment: 'NSE_EQ', securityId: '1922' },
        'NSE_AXISBANK': { segment: 'NSE_EQ', securityId: '5900' },
        'AXISBANK': { segment: 'NSE_EQ', securityId: '5900' },
        'NSE_HCLTECH': { segment: 'NSE_EQ', securityId: '7229' },
        'HCLTECH': { segment: 'NSE_EQ', securityId: '7229' },
        'NSE_SUNPHARMA': { segment: 'NSE_EQ', securityId: '3351' },
        'SUNPHARMA': { segment: 'NSE_EQ', securityId: '3351' },
        'NSE_TATAPOWER': { segment: 'NSE_EQ', securityId: '3426' },
        'TATAPOWER': { segment: 'NSE_EQ', securityId: '3426' },
    };
    // Max number of option token entries kept in the static security map to prevent unbounded growth
    static SECURITY_MAP_MAX_SIZE = 2000;
    // Track dynamic (option) keys separately so we can evict oldest when map grows too large
    static dynamicSecurityMapKeys = [];
    // Bidirectional reverse mapping: securityId -> canonical instrumentToken for O(1) tick dispatch
    static reverseSecurityIdMap = new Map([
        ['13', 'NSE_NIFTY50'],
        ['25', 'NSE_BANKNIFTY'],
        ['51', 'BSE_SENSEX'],
        ['27', 'NSE_FINNIFTY'],
        ['33', 'NSE_MIDCPNIFTY'],
        ['2885', 'NSE_RELIANCE'],
        ['11536', 'NSE_TCS'],
        ['1594', 'NSE_INFY'],
        ['1333', 'NSE_HDFCBANK'],
        ['4963', 'NSE_ICICIBANK'],
        ['3045', 'NSE_SBIN'],
        ['1660', 'NSE_ITC'],
        ['10604', 'NSE_BHARTIARTL'],
        ['11483', 'NSE_LT'],
        ['10999', 'NSE_MARUTI'],
        ['3456', 'NSE_TATAMOTORS'],
        ['3499', 'NSE_TATASTEEL'],
        ['3787', 'NSE_WIPRO'],
        ['317', 'NSE_BAJFINANCE'],
        ['5097', 'NSE_ZOMATO'],
        ['1922', 'NSE_KOTAKBANK'],
        ['5900', 'NSE_AXISBANK'],
        ['7229', 'NSE_HCLTECH'],
        ['3351', 'NSE_SUNPHARMA'],
        ['3426', 'NSE_TATAPOWER'],
    ]);
    /**
     * Add a dynamic security mapping (option strikes etc.) with LRU-style eviction at SECURITY_MAP_MAX_SIZE.
     * Maintains bidirectional mapping so Dhan binary tick security IDs map back to canonical tokens in O(1).
     */
    static addDynamicSecurityMapping(token, mapping) {
        if (!token || !mapping || !mapping.securityId)
            return;
        const cleanToken = token.trim();
        const cleanSecId = String(mapping.securityId).trim();
        if (!DhanAdapter.DHAN_SECURITY_MAP[cleanToken]) {
            // Evict oldest dynamic entries if we're at the cap
            while (DhanAdapter.dynamicSecurityMapKeys.length >= DhanAdapter.SECURITY_MAP_MAX_SIZE) {
                const oldest = DhanAdapter.dynamicSecurityMapKeys.shift();
                if (oldest) {
                    const oldMap = DhanAdapter.DHAN_SECURITY_MAP[oldest];
                    if (oldMap && oldMap.securityId) {
                        DhanAdapter.reverseSecurityIdMap.delete(oldMap.securityId);
                    }
                    delete DhanAdapter.DHAN_SECURITY_MAP[oldest];
                }
            }
            DhanAdapter.dynamicSecurityMapKeys.push(cleanToken);
        }
        DhanAdapter.DHAN_SECURITY_MAP[cleanToken] = mapping;
        // Prefer canonical option/index tokens over raw numeric IDs or prefixed IDs
        const isGenericIdToken = /^\d+$/.test(cleanToken) || /^[A-Z]{3}_\d+$/.test(cleanToken);
        if (!isGenericIdToken) {
            DhanAdapter.reverseSecurityIdMap.set(cleanSecId, cleanToken);
        }
        else if (!DhanAdapter.reverseSecurityIdMap.has(cleanSecId)) {
            DhanAdapter.reverseSecurityIdMap.set(cleanSecId, cleanToken);
        }
    }
    constructor() {
        this.clientId = process.env.DHAN_CLIENT_ID || '1113019677';
        this.accessToken = process.env.DHAN_ACCESS_TOKEN || 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJpc3MiOiJkaGFuIiwicGFydG5lcklkIjoiIiwiZXhwIjoxNzg3Mjg4NTAwLCJpYXQiOjE3ODcyMDIxMDAsInRva2VuQ29uc3VtZXJUeXBlIjoiU0VMRiIsIndlYmhvb2tVcmwiOiIiLCJkaGFuQ2xpZW50SWQiOiIxMTEzMDE5Njc3In0.v8SJgFEJQnYgh5W92wbdYl2JrjvBFrkqvpRBVEFtXLWJaqwW1mFPY8zJTJTObZBzsVcX07ekuoXzSzHM-L2_AA';
        this.apiKey = process.env.DHAN_API_KEY || '21483ef7';
        this.apiSecret = process.env.DHAN_API_SECRET || 'e9730aa4-682c-4e75-a944-94f703449b09';
    }
    optionChainData = null;
    chainFilePath = '';
    lastTickTime = 0;
    isHealthy() {
        return this.healthy && (this.lastTickTime === 0 || Date.now() - this.lastTickTime < 45000);
    }
    async initialize() {
        console.log(`[DhanAdapter] Initializing Dhan HQ API v2 Adapter (ClientId: ${this.clientId})...`);
        SafetyLock_1.SafetyLock.assertSimulationOnly('DhanAdapter.initialize');
        await this.connectWebSocket();
        // Start periodic JWT expiry check — every 30 minutes
        // Store ref so it can be cleared on stop()
        this.tokenCheckInterval = setInterval(() => {
            this.checkTokenExpiry();
        }, 30 * 60 * 1000);
        // Also check immediately on startup
        setTimeout(() => this.checkTokenExpiry(), 5000);
    }
    /**
     * Returns the current Dhan access token.
     * Used by cron jobs to check expiry without direct field access.
     */
    getAccessToken() {
        return this.accessToken;
    }
    /**
     * Hot-swap the Dhan access token and re-establish the WebSocket connection.
     * No server restart required.
     * Called by POST /api/internal/update-dhan-token
     */
    async setAccessToken(newToken) {
        console.log('[DhanAdapter] 🔄 Hot-swapping Dhan access token...');
        this.accessToken = newToken;
        if (this.reconnectTimer) {
            clearTimeout(this.reconnectTimer);
            this.reconnectTimer = null;
        }
        // Re-establish WebSocket with the new token
        await this.connectWebSocket();
        console.log('[DhanAdapter] ✅ Access token updated and WebSocket reconnected.');
    }
    /**
     * Decodes the current JWT token, checks time remaining, and auto-renews via TOTP
     * if expired or expiring within 30 minutes.
     */
    async checkTokenExpiry() {
        if (!this.accessToken || (0, dhanTokenRefresh_1.isTokenExpiringSoon)(this.accessToken, 30)) {
            console.warn(`[DhanAdapter] ⚠️ Dhan token is expired or expiring within 30m. Auto-generating fresh token via TOTP...`);
            try {
                const res = await (0, dhanTokenRefresh_1.autoGenerateDhanToken)();
                if (res.success && res.accessToken) {
                    console.log('[DhanAdapter] 🎉 Successfully auto-renewed Dhan access token via TOTP!');
                    return;
                }
            }
            catch (err) {
                console.error('[DhanAdapter] Automated token renewal failed:', err.message);
            }
        }
        const minutesLeft = (0, dhanTokenRefresh_1.getTokenExpiryMinutes)(this.accessToken);
        if (minutesLeft < 0) {
            console.error('[DhanAdapter] 🚨 Dhan access token is EXPIRED! Market data may be unavailable.');
            await (0, telegramAlert_1.sendTelegramAlert)(`🚨 <b>Trade Grow — Dhan Token EXPIRED!</b>\n\n` +
                `❌ The Dhan access token has expired and WebSocket is disconnected.\n\n` +
                `🔑 Please update the token via:\n` +
                `<code>POST /api/internal/update-dhan-token</code>\n` +
                `Body: <code>{"accessToken": "YOUR_NEW_TOKEN"}</code>`);
        }
        else if ((0, dhanTokenRefresh_1.isTokenExpiringSoon)(this.accessToken, 60)) {
            const hoursLeft = (minutesLeft / 60).toFixed(1);
            console.warn(`[DhanAdapter] ⚠️ Dhan token expiring in ${minutesLeft} min (${hoursLeft}h).`);
        }
        else {
            console.log(`[DhanAdapter] ✅ Token health OK. Expires in ${minutesLeft} minutes (~${(minutesLeft / 60).toFixed(1)}h).`);
        }
    }
    cleanupHeartbeat() {
        if (this.pingTimer) {
            clearInterval(this.pingTimer);
            this.pingTimer = null;
        }
        if (this.livenessWatchdogTimer) {
            clearInterval(this.livenessWatchdogTimer);
            this.livenessWatchdogTimer = null;
        }
    }
    stop() {
        console.log('[DhanAdapter] Stopping Dhan Market Data Adapter...');
        this.healthy = false;
        this.cleanupHeartbeat();
        if (this.tokenCheckInterval) {
            clearInterval(this.tokenCheckInterval);
            this.tokenCheckInterval = null;
        }
        if (this.reconnectTimer) {
            clearTimeout(this.reconnectTimer);
            this.reconnectTimer = null;
        }
        if (this.ws) {
            try {
                this.ws.removeAllListeners();
                this.ws.terminate();
            }
            catch (_) { }
            this.ws = null;
        }
    }
    connectWebSocket() {
        return new Promise((resolve) => {
            this.cleanupHeartbeat();
            if (this.reconnectTimer) {
                clearTimeout(this.reconnectTimer);
                this.reconnectTimer = null;
            }
            if (this.ws) {
                try {
                    this.ws.removeAllListeners();
                    this.ws.terminate();
                }
                catch (_) { }
                this.ws = null;
            }
            const fullWsUrl = `${this.wsUrl}?version=2&token=${encodeURIComponent(this.accessToken)}&clientId=${encodeURIComponent(this.clientId)}&authType=2`;
            console.log(`[DhanAdapter] Connecting to Dhan WebSocket Feed...`);
            let connectionResolved = false;
            const timeout = setTimeout(() => {
                if (!connectionResolved) {
                    connectionResolved = true;
                    console.warn('[DhanAdapter] WebSocket connection handshake timed out (3s). Proceeding with healthy state...');
                    this.healthy = true;
                    resolve(true);
                }
            }, 3000);
            try {
                this.ws = new ws_1.default(fullWsUrl);
                this.ws.on('open', () => {
                    console.log('[DhanAdapter] ✅ Connected to Dhan HQ WebSocket Feed!');
                    this.healthy = true;
                    this.connectedAt = Date.now();
                    this.lastErrorWasRateLimit = false;
                    this.cleanupHeartbeat();
                    // Send WS ping every 20 seconds to prevent silent socket drop
                    this.pingTimer = setInterval(() => {
                        if (this.ws && this.ws.readyState === ws_1.default.OPEN) {
                            try {
                                this.ws.ping();
                            }
                            catch (_) { }
                        }
                    }, 20000);
                    // Watchdog: If subscribed tokens exist and feed stalled >40s, reconnect
                    this.livenessWatchdogTimer = setInterval(() => {
                        if (this.subscribedTokens.size > 0 && this.lastTickTime > 0) {
                            const msSinceLastTick = Date.now() - this.lastTickTime;
                            if (msSinceLastTick > 40000) {
                                console.warn(`[DhanAdapter] ⚠️ Watchdog: No ticks received for ${(msSinceLastTick / 1000).toFixed(0)}s while subscribed. Re-establishing feed...`);
                                this.cleanupHeartbeat();
                                if (this.ws) {
                                    try {
                                        this.ws.terminate();
                                    }
                                    catch (_) { }
                                }
                            }
                        }
                    }, 15000);
                    this.subscribedTokens.clear();
                    this.subscribedSecurityIds.clear();
                    // Resubscribe: prioritize core indices first so they are guaranteed active slots
                    const coreIndices = ['BSE_SENSEX', 'NSE_NIFTY50', 'NSE_BANKNIFTY', 'NSE_FINNIFTY', 'NSE_MIDCPNIFTY'];
                    const tokensToResub = Array.from(new Set([...coreIndices, ...this.requestedTokens]));
                    if (tokensToResub.length > 0) {
                        this.sendSubscription(tokensToResub);
                    }
                    if (!connectionResolved) {
                        connectionResolved = true;
                        clearTimeout(timeout);
                        resolve(true);
                    }
                });
                this.ws.on('message', (data) => {
                    this.lastTickTime = Date.now();
                    this.healthy = true;
                    try {
                        if (Buffer.isBuffer(data)) {
                            this.handleBinaryMessage(data);
                        }
                        else {
                            this.handleJsonMessage(data.toString());
                        }
                    }
                    catch (e) {
                        console.warn('[DhanAdapter] Error parsing WebSocket message:', e.message);
                    }
                });
                this.ws.on('error', (err) => {
                    console.error('[DhanAdapter] WebSocket Error:', err.message);
                    this.healthy = false;
                    this.cleanupHeartbeat();
                    this.lastErrorWasRateLimit = /\b429\b/.test(err.message);
                    if (!connectionResolved) {
                        connectionResolved = true;
                        clearTimeout(timeout);
                        resolve(false);
                    }
                });
                this.ws.on('close', (code, reason) => {
                    this.healthy = false;
                    this.cleanupHeartbeat();
                    this.scheduleReconnect(code, reason);
                });
            }
            catch (err) {
                console.error('[DhanAdapter] Failed connecting WebSocket:', err.message);
                this.healthy = false;
                this.cleanupHeartbeat();
                if (!connectionResolved) {
                    connectionResolved = true;
                    clearTimeout(timeout);
                    resolve(false);
                }
                this.scheduleReconnect();
            }
        });
    }
    /**
     * Exponential backoff for ordinary disconnects; longer cooldown when rate limited.
     */
    scheduleReconnect(code, reason) {
        if (this.reconnectTimer) {
            clearTimeout(this.reconnectTimer);
            this.reconnectTimer = null;
        }
        const STABLE_CONNECTION_MS = 10000;
        const wasStable = this.connectedAt > 0 && (Date.now() - this.connectedAt) >= STABLE_CONNECTION_MS;
        this.reconnectAttempts = wasStable ? 1 : this.reconnectAttempts + 1;
        this.connectedAt = 0;
        const minutesLeft = (0, dhanTokenRefresh_1.getTokenExpiryMinutes)(this.accessToken);
        const tokenSuspectDead = minutesLeft <= 10 || code === 1008 || code === 4401 || (this.reconnectAttempts >= 3 && (Date.now() - this.lastTickTime > 45000 || this.lastTickTime === 0));
        if (tokenSuspectDead) {
            console.warn(`[DhanAdapter] 🔄 Dhan connection repeatedly dropped or token invalid (${minutesLeft}m left, attempt ${this.reconnectAttempts}, code ${code}). Triggering automatic token refresh via TOTP...`);
            (0, dhanTokenRefresh_1.autoGenerateDhanToken)().catch(() => { });
            return;
        }
        const RATE_LIMIT_DELAY_MS = 15 * 1000;
        const BASE_DELAY_MS = 2000;
        const MAX_DELAY_MS = 30 * 1000;
        const delay = this.lastErrorWasRateLimit
            ? RATE_LIMIT_DELAY_MS
            : Math.min(BASE_DELAY_MS * Math.pow(2, this.reconnectAttempts - 1), MAX_DELAY_MS);
        console.warn(`[DhanAdapter] WebSocket closed (code=${code}, reason=${reason || 'None'}). ` +
            `Reconnecting in ${(delay / 1000).toFixed(0)}s (attempt ${this.reconnectAttempts}${this.lastErrorWasRateLimit ? ', rate-limited' : ''})...`);
        this.reconnectTimer = setTimeout(() => {
            this.connectWebSocket();
        }, delay);
    }
    sendSubscription(tokens) {
        if (!this.ws || this.ws.readyState !== ws_1.default.OPEN)
            return;
        // Core index security IDs that MUST ALWAYS remain active on the Dhan WebSocket:
        // SENSEX: 51, NIFTY: 13, BANKNIFTY: 25, FINNIFTY: 27, MIDCPNIFTY: 33
        const CORE_SEC_IDS = new Set(['51', '13', '25', '27', '33']);
        // Deduplicate by SecurityId to avoid duplicate slots & Dhan payload rejections
        const newItemsMap = new Map();
        for (const t of tokens) {
            const mapping = this.resolveSecurityMapping(t);
            if (mapping && mapping.segment && mapping.securityId) {
                this.subscribedTokens.add(t);
                const secId = String(mapping.securityId).trim();
                if (!this.subscribedSecurityIds.has(secId) && !newItemsMap.has(secId)) {
                    newItemsMap.set(secId, { ExchangeSegment: mapping.segment, SecurityId: secId });
                }
            }
        }
        if (newItemsMap.size === 0)
            return;
        // Dhan WebSocket hard limit: max 100 instruments simultaneously per session
        const MAX_DHAN_INSTRUMENTS = 100;
        const currentActive = this.subscribedSecurityIds.size;
        const availableSlots = Math.max(0, MAX_DHAN_INSTRUMENTS - currentActive);
        let listToSubscribe = Array.from(newItemsMap.values());
        if (listToSubscribe.length > availableSlots) {
            // Prioritize core indices, then fill remaining available slots
            const core = listToSubscribe.filter(i => CORE_SEC_IDS.has(i.SecurityId));
            const nonCore = listToSubscribe.filter(i => !CORE_SEC_IDS.has(i.SecurityId));
            const prioritized = [...core, ...nonCore];
            listToSubscribe = prioritized.slice(0, availableSlots);
            console.warn(`[DhanAdapter] ⚠️ Dhan 100-instrument limit: Capping subscription batch to ${listToSubscribe.length} instruments (slots remaining: ${availableSlots}).`);
        }
        if (listToSubscribe.length === 0)
            return;
        listToSubscribe.forEach(i => this.subscribedSecurityIds.add(i.SecurityId));
        console.log(`[DhanAdapter] 📡 Subscribing to ${listToSubscribe.length} unique instruments on Dhan WebSocket feed (total active: ${this.subscribedSecurityIds.size}/100)...`);
        const payload = JSON.stringify({
            RequestCode: 15, // High-frequency live tick stream (Ticker packet Code 2 / LTP)
            InstrumentCount: listToSubscribe.length,
            InstrumentList: listToSubscribe
        });
        try {
            this.ws.send(payload);
        }
        catch (err) {
            console.warn('[DhanAdapter] Error sending subscription batch:', err.message);
        }
    }
    /**
     * DHAN MARKET FEED SPECIFICATION & STREAMING ARCHITECTURE:
     * Dhan's official WebSocket market feed (wss://api-feed.dhan.co) streams real-time binary
     * packets (Quote Code 21 / Ticker Code 15 / PrevClose Code 6).
     * Multiple packets may arrive concatenated within a single WebSocket frame buffer.
     * We iterate through the buffer unpacking every packet sequentially and broadcasting each tick.
     */
    handleBinaryMessage(buf) {
        if (buf.length < 8)
            return;
        let offset = 0;
        while (offset + 8 <= buf.length) {
            const responseCode = buf.readUInt8(offset);
            const msgLen = buf.readUInt16LE(offset + 1);
            const securityId = buf.readInt32LE(offset + 4).toString();
            // Determine packet size for advancing cursor
            const packetLen = msgLen >= 8 ? msgLen : (responseCode === 2 ? 16 :
                responseCode === 4 ? 50 :
                    responseCode === 6 ? 12 :
                        responseCode === 7 ? 50 :
                            responseCode === 8 ? 184 : 8);
            // Map securityId back to canonical instrument token
            const token = this.findTokenBySecurityId(securityId);
            if (!token) {
                offset += Math.max(8, packetLen);
                continue;
            }
            if (responseCode === 6) {
                // Packet Code 6: Previous Close Price and Open Interest
                if (offset + 12 <= buf.length) {
                    const prevClose = buf.readFloatLE(offset + 8);
                    if (prevClose > 0) {
                        const existing = this.tickCache.get(token);
                        if (existing) {
                            existing.close = Number(prevClose.toFixed(2));
                            existing.change = Number((existing.ltp - prevClose).toFixed(2));
                            existing.changePercent = Number(((existing.change / prevClose) * 100).toFixed(2));
                            this.tickCache.set(token, existing);
                            this.callbacks.forEach(cb => cb(existing));
                        }
                        else {
                            const preTick = {
                                instrumentToken: token,
                                exchange: token.startsWith('MCX_') ? 'MCX' : (token.startsWith('BSE_') || token.startsWith('BFO_')) ? 'BSE' : 'NSE',
                                symbol: token.replace(/^(NSE_|BSE_|NFO_|BFO_|MCX_)/, ''),
                                ltp: Number(prevClose.toFixed(2)),
                                open: Number(prevClose.toFixed(2)),
                                high: Number(prevClose.toFixed(2)),
                                low: Number(prevClose.toFixed(2)),
                                close: Number(prevClose.toFixed(2)),
                                volume: 0,
                                change: 0,
                                changePercent: 0,
                                bid: Number(prevClose.toFixed(2)),
                                ask: Number(prevClose.toFixed(2)),
                                bidQty: 100,
                                askQty: 100,
                                source: 'dhan',
                                isSynthetic: false,
                                timestamp: Date.now()
                            };
                            this.tickCache.set(token, preTick);
                        }
                    }
                }
            }
            else if (responseCode === 2 || responseCode === 4 || responseCode === 7 || responseCode === 8) {
                // Packet Codes: 2 (Ticker LTP), 4 (Quote), 7 (Market Depth + Quote), 8 (Full Packet)
                let ltp = 0;
                let volume = 0;
                if (offset + 12 <= buf.length) {
                    ltp = buf.readFloatLE(offset + 8);
                }
                if (offset + 26 <= buf.length) {
                    volume = buf.readInt32LE(offset + 22);
                }
                else if (offset + 20 <= buf.length) {
                    volume = buf.readInt32LE(offset + 16);
                }
                if (ltp > 0) {
                    const existing = this.tickCache.get(token);
                    const close = existing && existing.close > 0 ? existing.close : ltp;
                    const open = existing ? existing.open : ltp;
                    const high = existing ? Math.max(existing.high, ltp) : ltp;
                    const low = existing ? Math.min(existing.low, ltp) : ltp;
                    const change = Number((ltp - close).toFixed(2));
                    const changePercent = close > 0 ? Number(((change / close) * 100).toFixed(2)) : 0;
                    const tick = {
                        instrumentToken: token,
                        exchange: token.startsWith('MCX_') ? 'MCX' : (token.startsWith('BSE_') || token.startsWith('BFO_')) ? 'BSE' : 'NSE',
                        symbol: token.replace(/^(NSE_|BSE_|NFO_|BFO_|MCX_)/, ''),
                        ltp: Number(ltp.toFixed(2)),
                        open: Number(open.toFixed(2)),
                        high: Number(high.toFixed(2)),
                        low: Number(low.toFixed(2)),
                        close: Number(close.toFixed(2)),
                        volume: volume > 0 ? volume : (existing ? existing.volume : 50000),
                        change,
                        changePercent,
                        bid: Number((ltp - 0.05).toFixed(2)),
                        ask: Number((ltp + 0.05).toFixed(2)),
                        bidQty: 100,
                        askQty: 100,
                        source: 'dhan',
                        isSynthetic: false,
                        timestamp: Date.now()
                    };
                    this.lastTickTime = Date.now();
                    this.healthy = true;
                    this.tickCache.set(token, tick);
                    this.callbacks.forEach(cb => cb(tick));
                }
            }
            offset += Math.max(8, packetLen);
        }
    }
    handleJsonMessage(str) {
        let parsed;
        try {
            parsed = JSON.parse(str);
        }
        catch (_) {
            return;
        }
        if (parsed.status === 'success' && parsed.data) {
            for (const [segment, secObj] of Object.entries(parsed.data)) {
                if (typeof secObj === 'object') {
                    for (const [secId, item] of Object.entries(secObj)) {
                        const token = this.findTokenBySecurityId(secId);
                        if (!token || !item || !item.last_price)
                            continue;
                        const ltp = Number(item.last_price);
                        const open = Number(item.ohlc?.open || item.open || ltp);
                        const high = Number(item.ohlc?.high || item.high || ltp);
                        const low = Number(item.ohlc?.low || item.low || ltp);
                        const close = Number(item.ohlc?.close || item.close || ltp);
                        const volume = Number(item.volume || 0);
                        const change = Number((ltp - close).toFixed(2));
                        const changePercent = close > 0 ? Number(((change / close) * 100).toFixed(2)) : 0;
                        const tick = {
                            instrumentToken: token,
                            exchange: token.startsWith('MCX_') ? 'MCX' : (token.startsWith('BSE_') || token.startsWith('BFO_')) ? 'BSE' : 'NSE',
                            symbol: token.replace(/^(NSE_|BSE_|NFO_|BFO_|MCX_)/, ''),
                            ltp,
                            open,
                            high,
                            low,
                            close,
                            volume,
                            change,
                            changePercent,
                            bid: Number((ltp - 0.05).toFixed(2)),
                            ask: Number((ltp + 0.05).toFixed(2)),
                            bidQty: 100,
                            askQty: 100,
                            source: 'dhan',
                            isSynthetic: false,
                            timestamp: Date.now()
                        };
                        this.tickCache.set(token, tick);
                        this.callbacks.forEach(cb => cb(tick));
                    }
                }
            }
        }
    }
    resolveSecurityMapping(token) {
        if (!token)
            return null;
        const cleanToken = token.trim();
        if (DhanAdapter.DHAN_SECURITY_MAP[cleanToken]) {
            return DhanAdapter.DHAN_SECURITY_MAP[cleanToken];
        }
        // Explicit index spot security ID mappings
        if (cleanToken === 'NSE_NIFTY50' || cleanToken === 'NSE_NIFTY' || cleanToken === 'NIFTY' || cleanToken === 'NIFTY50' || cleanToken === 'NIFTY 50')
            return { segment: 'IDX_I', securityId: '13' };
        if (cleanToken === 'NSE_BANKNIFTY' || cleanToken === 'BANKNIFTY' || cleanToken === 'BANK NIFTY')
            return { segment: 'IDX_I', securityId: '25' };
        if (cleanToken === 'BSE_SENSEX' || cleanToken === 'SENSEX' || cleanToken === 'BSE SENSEX')
            return { segment: 'IDX_I', securityId: '51' };
        if (cleanToken === 'NSE_FINNIFTY' || cleanToken === 'FINNIFTY' || cleanToken === 'FIN NIFTY')
            return { segment: 'IDX_I', securityId: '27' };
        if (cleanToken === 'NSE_MIDCPNIFTY' || cleanToken === 'MIDCPNIFTY' || cleanToken === 'MIDCAP NIFTY')
            return { segment: 'IDX_I', securityId: '33' };
        // Query InstrumentMasterService loaded Dhan Scrip Master
        try {
            const { InstrumentMasterService } = require('./InstrumentMasterService');
            const scrip = InstrumentMasterService.getInstance().getDhanScripByToken(cleanToken);
            if (scrip) {
                const mapping = { segment: scrip.segment, securityId: scrip.securityId };
                DhanAdapter.addDynamicSecurityMapping(cleanToken, mapping);
                return mapping;
            }
            // Dynamic resolution from option token structure e.g. NFO_NIFTY_24500_CE, BFO_SENSEX_74400_CE, MCX_CRUDEOIL_7000_CE
            const optMatch = cleanToken.match(/^(NFO|BFO|MCX)_([A-Z0-9]+)_(\d+(?:\.\d+)?)(?:_)?(CE|PE)(?:_(\d{4}-\d{2}-\d{2}))?$/i);
            if (optMatch) {
                const segPrefix = optMatch[1].toUpperCase();
                const underlying = optMatch[2].toUpperCase();
                const strike = parseFloat(optMatch[3]);
                const optionType = optMatch[4].toUpperCase();
                const expiry = optMatch[5];
                const secId = InstrumentMasterService.getInstance().getDhanSecurityId(underlying, strike, optionType, expiry);
                if (secId) {
                    const seg = segPrefix === 'MCX' ? 'MCX_COMM' : (underlying === 'SENSEX' || underlying === 'BANKEX' || segPrefix === 'BFO') ? 'BSE_FNO' : 'NSE_FNO';
                    const mapping = { segment: seg, securityId: secId };
                    DhanAdapter.addDynamicSecurityMapping(cleanToken, mapping);
                    return mapping;
                }
            }
        }
        catch (_) { }
        // If pure numeric token (e.g. "35000")
        if (/^\d+$/.test(cleanToken)) {
            const seg = cleanToken === '51' ? 'IDX_I' : ['13', '25', '27', '33'].includes(cleanToken) ? 'NSE_INDEX' : 'NSE_FNO';
            return { segment: seg, securityId: cleanToken };
        }
        return null;
    }
    findTokenBySecurityId(securityId) {
        if (!securityId)
            return null;
        const cleanId = String(securityId).trim();
        // 1. Authoritative Index Spot IDs — must NEVER be overwritten by option mappings
        if (cleanId === '13')
            return 'NSE_NIFTY50';
        if (cleanId === '25')
            return 'NSE_BANKNIFTY';
        if (cleanId === '51')
            return 'BSE_SENSEX';
        if (cleanId === '27')
            return 'NSE_FINNIFTY';
        if (cleanId === '33')
            return 'NSE_MIDCPNIFTY';
        // 2. High-speed O(1) reverse lookup map
        const mappedToken = DhanAdapter.reverseSecurityIdMap.get(cleanId);
        if (mappedToken)
            return mappedToken;
        // 3. Query InstrumentMasterService first (authoritative Dhan Scrip Master from CSV)
        try {
            const { InstrumentMasterService } = require('./InstrumentMasterService');
            const masterToken = InstrumentMasterService.getInstance().findTokenBySecurityId(cleanId);
            if (masterToken) {
                DhanAdapter.reverseSecurityIdMap.set(cleanId, masterToken);
                return masterToken;
            }
        }
        catch (_) { }
        // 4. Subscribed tokens match
        for (const token of this.subscribedTokens) {
            const map = this.resolveSecurityMapping(token);
            if (map && map.securityId === cleanId) {
                DhanAdapter.reverseSecurityIdMap.set(cleanId, token);
                return token;
            }
        }
        // 5. Fallback to static mapping
        for (const [token, map] of Object.entries(DhanAdapter.DHAN_SECURITY_MAP)) {
            if (map.securityId === cleanId) {
                DhanAdapter.reverseSecurityIdMap.set(cleanId, token);
                return token;
            }
        }
        return null;
    }
    subscribe(instrumentTokens, callback) {
        SafetyLock_1.SafetyLock.assertSimulationOnly('DhanAdapter.subscribe');
        if (callback) {
            this.callbacks.add(callback);
        }
        const tokensToResolve = [];
        for (const token of instrumentTokens) {
            if (!token)
                continue;
            const clean = token.trim();
            this.requestedTokens.add(clean);
            if (!this.subscribedTokens.has(clean)) {
                tokensToResolve.push(clean);
            }
        }
        if (tokensToResolve.length > 0) {
            this.sendSubscription(tokensToResolve);
        }
    }
    unsubscribe(instrumentTokens) {
        for (const token of instrumentTokens) {
            if (!token)
                continue;
            const clean = token.trim();
            this.subscribedTokens.delete(clean);
            this.requestedTokens.delete(clean);
            const mapping = this.resolveSecurityMapping(clean);
            if (mapping && mapping.securityId) {
                this.subscribedSecurityIds.delete(String(mapping.securityId).trim());
            }
        }
    }
    async getQuote(instrumentToken) {
        SafetyLock_1.SafetyLock.assertSimulationOnly('DhanAdapter.getQuote');
        const cached = this.tickCache.get(instrumentToken);
        if (cached)
            return cached;
        // Call Dhan REST Marketfeed Quote API
        const mapping = DhanAdapter.DHAN_SECURITY_MAP[instrumentToken];
        if (mapping) {
            try {
                const url = `${this.baseUrl}/v2/marketfeed/quote`;
                const payload = {
                    [mapping.segment]: [parseInt(mapping.securityId, 10)]
                };
                const res = await fetch(url, {
                    method: 'POST',
                    headers: {
                        'access-token': this.accessToken,
                        'client-id': this.clientId,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(payload)
                });
                if (res.ok) {
                    const json = await res.json();
                    if (json.status === 'success' && json.data) {
                        this.handleJsonMessage(JSON.stringify(json));
                        const updated = this.tickCache.get(instrumentToken);
                        if (updated)
                            return updated;
                    }
                }
            }
            catch (err) {
                console.warn(`[DhanAdapter] REST Quote API error for ${instrumentToken}:`, err.message);
            }
        }
        return null;
    }
    async getHistoricalCandles(instrumentToken, timeframe, count) {
        SafetyLock_1.SafetyLock.assertSimulationOnly('DhanAdapter.getHistoricalCandles');
        const { InstrumentMasterService } = require('./InstrumentMasterService');
        const master = InstrumentMasterService.getInstance();
        let secId = null;
        let exchangeSegment = 'NSE_FNO';
        let instrument = 'OPTIDX';
        const staticMapping = DhanAdapter.DHAN_SECURITY_MAP[instrumentToken];
        if (staticMapping) {
            secId = staticMapping.securityId;
            const isIndex = staticMapping.segment.includes('INDEX') || instrumentToken.includes('NIFTY') || instrumentToken.includes('SENSEX');
            exchangeSegment = isIndex ? 'IDX_I' : staticMapping.segment;
            instrument = isIndex ? 'INDEX' : staticMapping.segment === 'MCX_COMM' ? 'FUTCOM' : 'EQUITY';
        }
        else {
            // Dynamic lookup from Dhan Scrip Master
            const dhanRec = master.getDhanScripByToken(instrumentToken);
            if (dhanRec) {
                secId = dhanRec.securityId;
                exchangeSegment = dhanRec.segment || (dhanRec.exchange === 'MCX' ? 'MCX_COMM' : dhanRec.exchange === 'BSE' ? 'BFO' : 'NSE_FNO');
                const isOpt = dhanRec.optionType === 'CE' || dhanRec.optionType === 'PE';
                const isIndex = ['NIFTY', 'BANKNIFTY', 'FINNIFTY', 'MIDCPNIFTY', 'SENSEX', 'BANKEX'].includes(dhanRec.symbolName.toUpperCase());
                if (exchangeSegment === 'MCX_COMM') {
                    instrument = isOpt ? 'OPTFUT' : 'FUTCOM';
                }
                else if (exchangeSegment === 'IDX_I' || exchangeSegment.includes('INDEX')) {
                    instrument = 'INDEX';
                }
                else if (exchangeSegment === 'NSE_EQ' || exchangeSegment === 'BSE_EQ') {
                    instrument = 'EQUITY';
                }
                else {
                    instrument = isOpt ? (isIndex ? 'OPTIDX' : 'OPTSTK') : (isIndex ? 'FUTIDX' : 'FUTSTK');
                }
            }
            else {
                // Parse token structure e.g. NFO_NIFTY_24000_PE or MCX_CRUDEOIL_8500_PE
                const parts = instrumentToken.split('_');
                if (parts.length >= 4) {
                    const seg = parts[0];
                    const sym = parts[1];
                    const strike = parseFloat(parts[2]);
                    const optType = parts[3];
                    secId = master.getDhanSecurityId(sym, strike, optType);
                    exchangeSegment = seg === 'BFO' ? 'BSE_FNO' : seg === 'MCX' ? 'MCX_COMM' : 'NSE_FNO';
                    const isIndex = ['NIFTY', 'BANKNIFTY', 'FINNIFTY', 'MIDCPNIFTY', 'SENSEX', 'BANKEX'].includes(sym.toUpperCase());
                    instrument = exchangeSegment === 'MCX_COMM' ? 'OPTFUT' : (isIndex ? 'OPTIDX' : 'OPTSTK');
                }
            }
        }
        if (secId) {
            try {
                const now = new Date();
                const toDateObj = now;
                const fromDateObj = new Date();
                // Request past 7 days for intraday to ensure full session candles
                fromDateObj.setDate(fromDateObj.getDate() - Math.max(7, Math.ceil(count / 75)));
                const tf = (timeframe || '5m').toLowerCase();
                const isIntraday = tf !== '1d';
                const isMcx = exchangeSegment === 'MCX_COMM';
                const formatDate = (d) => {
                    const y = d.getFullYear();
                    const m = String(d.getMonth() + 1).padStart(2, '0');
                    const day = String(d.getDate()).padStart(2, '0');
                    return `${y}-${m}-${day}`;
                };
                const fromDateStr = `${formatDate(fromDateObj)} ${isMcx ? '09:00:00' : '09:15:00'}`;
                const toDateStr = `${formatDate(toDateObj)} ${isMcx ? '23:30:00' : '15:30:00'}`;
                const intervalMap = {
                    '1m': '1', '1': '1',
                    '3m': '1', '3': '1',
                    '5m': '5', '5': '5',
                    '15m': '15', '15': '15',
                    '25m': '25', '25': '25',
                    '30m': '25', '30': '25',
                    '60m': '60', '1h': '60', '60': '60'
                };
                const interval = intervalMap[tf] || '5';
                const url = `${this.baseUrl}/v2/charts/${isIntraday ? 'intraday' : 'historical'}`;
                const payload = {
                    securityId: String(secId),
                    exchangeSegment,
                    instrument,
                    expiryCode: 0,
                    fromDate: isIntraday ? fromDateStr : formatDate(fromDateObj),
                    toDate: isIntraday ? toDateStr : formatDate(toDateObj)
                };
                if (isIntraday)
                    payload.interval = interval;
                const res = await fetch(url, {
                    method: 'POST',
                    headers: {
                        'access-token': this.accessToken,
                        'client-id': this.clientId,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(payload),
                    signal: AbortSignal.timeout(2000)
                });
                if (res.ok) {
                    const json = await res.json();
                    const timestamps = json.timestamp || json.start_Time || [];
                    if (Array.isArray(timestamps) && timestamps.length > 0) {
                        const candles = [];
                        for (let i = 0; i < timestamps.length; i++) {
                            const open = Number(json.open[i] || 0);
                            const high = Number(json.high[i] || 0);
                            const low = Number(json.low[i] || 0);
                            const close = Number(json.close[i] || 0);
                            const volume = Number(json.volume ? json.volume[i] : 0);
                            if (open > 0 || close > 0 || high > 0) {
                                candles.push({
                                    time: timestamps[i],
                                    open,
                                    high,
                                    low,
                                    close,
                                    volume
                                });
                            }
                        }
                        if (candles.length > 0) {
                            return candles.slice(-count);
                        }
                    }
                }
                else {
                    const errText = await res.text().catch(() => '');
                    console.warn(`[DhanAdapter] Charts API non-200 for ${instrumentToken} (${secId}):`, res.status, errText);
                }
            }
            catch (err) {
                console.warn(`[DhanAdapter] Historical Candles error for ${instrumentToken} (${secId}):`, err.message);
            }
        }
        // Fallback Generator: Smooth backwards random-walk anchored at current price (ZERO price spike)
        const { MarketDataEngine } = require('./MarketDataEngine');
        const cachedLiveTick = MarketDataEngine.getInstance().getCachedTick(instrumentToken);
        const quote = cachedLiveTick || await this.getQuote(instrumentToken);
        const isOption = instrumentToken.includes('_CE') || instrumentToken.includes('_PE') || instrumentToken.includes('BFO_') || instrumentToken.includes('NFO_');
        const basePrice = quote && quote.ltp > 0 ? quote.ltp : (isOption ? 185.50 : 24500);
        const tf = (timeframe || '5m').toLowerCase();
        const stepSecs = tf === '1d' ? 86400 : tf === '1h' || tf === '60m' ? 3600 : tf === '15m' ? 900 : tf === '5m' ? 300 : 60;
        const nowSec = Math.floor(Date.now() / 1000);
        // Generate backwards from basePrice to guarantee perfect continuity and NO artificial spike
        const tempCandles = [];
        let walkingPrice = basePrice;
        const volatility = isOption ? 0.008 : 0.0015;
        for (let i = 0; i < count; i++) {
            const time = nowSec - (i * stepSecs);
            const close = walkingPrice;
            const noise = (Math.random() - 0.49) * volatility * walkingPrice;
            const open = Math.max(0.05, close - noise);
            const high = Math.max(open, close) + (Math.random() * volatility * walkingPrice * 0.5);
            const low = Math.min(open, close) - (Math.random() * volatility * walkingPrice * 0.5);
            tempCandles.push({
                time,
                open: Number(open.toFixed(2)),
                high: Number(high.toFixed(2)),
                low: Number(Math.max(0.05, low).toFixed(2)),
                close: Number(close.toFixed(2)),
                volume: Math.floor(Math.random() * 2500) + 100
            });
            walkingPrice = open;
        }
        return tempCandles.reverse();
    }
    static expiryListCache = new Map();
    static pendingExpiryListRequests = new Map();
    static expiryListFailureCooldown = new Map();
    async getExpiryList(symbol) {
        const cleanSym = (symbol || 'NIFTY').toUpperCase().replace(/^(NSE_|BSE_)/, '');
        const SUPPORTED_SYMS = {
            'NIFTY': 13, 'BANKNIFTY': 25, 'FINNIFTY': 27, 'MIDCPNIFTY': 33, 'SENSEX': 51
        };
        if (!SUPPORTED_SYMS[cleanSym]) {
            return [];
        }
        const now = Date.now();
        const cached = DhanAdapter.expiryListCache.get(cleanSym);
        if (cached && now - cached.timestamp < 60000 && cached.expiries.length > 0) {
            return cached.expiries;
        }
        const cooldownUntil = DhanAdapter.expiryListFailureCooldown.get(cleanSym) || 0;
        if (now < cooldownUntil) {
            return cached ? cached.expiries : [];
        }
        const existingPromise = DhanAdapter.pendingExpiryListRequests.get(cleanSym);
        if (existingPromise) {
            return existingPromise;
        }
        const fetchPromise = (async () => {
            const underlyingSeg = 'IDX_I';
            const underlyingScrip = SUPPORTED_SYMS[cleanSym];
            try {
                const res = await fetch(`${this.baseUrl}/v2/optionchain/expirylist`, {
                    method: 'POST',
                    headers: {
                        'access-token': this.accessToken,
                        'client-id': this.clientId,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ UnderlyingScrip: underlyingScrip, UnderlyingSeg: underlyingSeg }),
                    signal: AbortSignal.timeout(2000)
                });
                if (res.ok) {
                    const json = await res.json();
                    const expiries = json.data && Array.isArray(json.data) ? json.data : [];
                    if (expiries.length > 0) {
                        DhanAdapter.expiryListCache.set(cleanSym, { timestamp: Date.now(), expiries });
                        return expiries;
                    }
                }
                DhanAdapter.expiryListFailureCooldown.set(cleanSym, Date.now() + 30000);
            }
            catch (err) {
                console.warn(`[DhanAdapter] getExpiryList failed for ${cleanSym} (${err.message}). Entering 30s cooldown.`);
                DhanAdapter.expiryListFailureCooldown.set(cleanSym, Date.now() + 30000);
            }
            finally {
                DhanAdapter.pendingExpiryListRequests.delete(cleanSym);
            }
            return cached ? cached.expiries : [];
        })();
        DhanAdapter.pendingExpiryListRequests.set(cleanSym, fetchPromise);
        return fetchPromise;
    }
    static optionChainCache = new Map();
    static pendingOptionChainRequests = new Map();
    static optionChainFailureCooldown = new Map();
    async getOptionChain(symbol, expiry) {
        SafetyLock_1.SafetyLock.assertSimulationOnly('DhanAdapter.getOptionChain');
        const cleanSym = (symbol || 'NIFTY').toUpperCase().replace(/^(NSE_|BSE_)/, '');
        const SUPPORTED_SYMS = {
            'NIFTY': 13, 'BANKNIFTY': 25, 'FINNIFTY': 27, 'MIDCPNIFTY': 33, 'SENSEX': 51
        };
        if (!SUPPORTED_SYMS[cleanSym]) {
            return [];
        }
        const underlyingSeg = 'IDX_I';
        const underlyingScrip = SUPPORTED_SYMS[cleanSym];
        let targetExpiry = expiry ? expiry.trim() : '';
        if (!targetExpiry) {
            const liveExpiries = await this.getExpiryList(cleanSym);
            if (liveExpiries.length > 0) {
                targetExpiry = liveExpiries[0];
            }
            else {
                const { ExpiryCalendarService } = require('../services/ExpiryCalendarService');
                const cat = await ExpiryCalendarService.getInstance().getValidExpiries(cleanSym);
                targetExpiry = cat.nearestExpiry || new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Kolkata' }).format(new Date());
            }
        }
        const cacheKey = `${cleanSym}_${targetExpiry}`;
        const now = Date.now();
        const cached = DhanAdapter.optionChainCache.get(cacheKey);
        // 12-second memory cache for live trading freshness while preventing rate limits
        if (cached && now - cached.timestamp < 12000 && cached.rows.length > 0) {
            return cached.rows;
        }
        const cooldownUntil = DhanAdapter.optionChainFailureCooldown.get(cacheKey) || 0;
        if (now < cooldownUntil) {
            return cached ? cached.rows : [];
        }
        const existingPromise = DhanAdapter.pendingOptionChainRequests.get(cacheKey);
        if (existingPromise) {
            return existingPromise;
        }
        const fetchPromise = (async () => {
            try {
                const url = `${this.baseUrl}/v2/optionchain`;
                const payload = {
                    UnderlyingScrip: underlyingScrip,
                    UnderlyingSeg: underlyingSeg,
                    Expiry: targetExpiry
                };
                const res = await fetch(url, {
                    method: 'POST',
                    headers: {
                        'access-token': this.accessToken,
                        'client-id': this.clientId,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(payload),
                    signal: AbortSignal.timeout(4500)
                });
                if (res.ok) {
                    const json = await res.json();
                    if (json.data && json.data.oc && Object.keys(json.data.oc).length > 0) {
                        const spot = Number(json.data.last_price || json.data.spot_price || 0);
                        const oc = json.data.oc || {};
                        const rows = [];
                        const { MarketDataEngine } = require('./MarketDataEngine');
                        const engine = MarketDataEngine.getInstance();
                        if (spot > 0) {
                            const spotTokens = cleanSym === 'SENSEX'
                                ? ['BSE_SENSEX', 'SENSEX']
                                : cleanSym === 'NIFTY'
                                    ? ['NSE_NIFTY50', 'NSE_NIFTY', 'NIFTY']
                                    : cleanSym === 'BANKNIFTY'
                                        ? ['NSE_BANKNIFTY', 'BANKNIFTY']
                                        : cleanSym === 'FINNIFTY'
                                            ? ['NSE_FINNIFTY', 'FINNIFTY']
                                            : cleanSym === 'MIDCPNIFTY'
                                                ? ['NSE_MIDCPNIFTY', 'MIDCPNIFTY']
                                                : [`NSE_${cleanSym}`, cleanSym];
                            const exch = cleanSym === 'SENSEX' ? 'BSE' : 'NSE';
                            const trSym = cleanSym === 'SENSEX' ? 'BSE SENSEX' : `NSE ${cleanSym}`;
                            for (const st of spotTokens) {
                                const tickObj = {
                                    instrumentToken: st,
                                    exchange: exch,
                                    symbol: cleanSym,
                                    ltp: spot,
                                    open: spot,
                                    high: Number((spot * 1.002).toFixed(2)),
                                    low: Number((spot * 0.998).toFixed(2)),
                                    close: spot,
                                    change: 0,
                                    changePercent: 0,
                                    volume: 5000000,
                                    bid: Number((spot - 0.05).toFixed(2)),
                                    ask: Number((spot + 0.05).toFixed(2)),
                                    bidQty: 100,
                                    askQty: 100,
                                    source: 'dhan',
                                    isSynthetic: false,
                                    timestamp: Date.now()
                                };
                                engine.setCachedTick(tickObj);
                                this.tickCache.set(st, tickObj);
                            }
                        }
                        const optPrefix = cleanSym === 'SENSEX' ? 'BFO' : 'NFO';
                        const optSeg = cleanSym === 'SENSEX' ? 'BSE_FNO' : 'NSE_FNO';
                        for (const [strikeStr, strikeData] of Object.entries(oc)) {
                            const strikePrice = parseFloat(strikeStr);
                            if (isNaN(strikePrice))
                                continue;
                            const ceData = strikeData.ce || {};
                            const peData = strikeData.pe || {};
                            const ceSecurityId = String(ceData.security_id || '');
                            const peSecurityId = String(peData.security_id || '');
                            const ceToken = `${optPrefix}_${cleanSym}_${strikePrice}_CE`;
                            const peToken = `${optPrefix}_${cleanSym}_${strikePrice}_PE`;
                            if (ceSecurityId) {
                                DhanAdapter.addDynamicSecurityMapping(ceToken, { segment: optSeg, securityId: ceSecurityId });
                                DhanAdapter.addDynamicSecurityMapping(ceSecurityId, { segment: optSeg, securityId: ceSecurityId });
                                DhanAdapter.addDynamicSecurityMapping(`${optPrefix}_${ceSecurityId}`, { segment: optSeg, securityId: ceSecurityId });
                            }
                            if (peSecurityId) {
                                DhanAdapter.addDynamicSecurityMapping(peToken, { segment: optSeg, securityId: peSecurityId });
                                DhanAdapter.addDynamicSecurityMapping(peSecurityId, { segment: optSeg, securityId: peSecurityId });
                                DhanAdapter.addDynamicSecurityMapping(`${optPrefix}_${peSecurityId}`, { segment: optSeg, securityId: peSecurityId });
                            }
                            const ceLtp = Number(ceData.last_price ?? ceData.ltp ?? 0);
                            const peLtp = Number(peData.last_price ?? peData.ltp ?? 0);
                            const cePrevClose = Number(ceData.previous_close_price || (ceLtp > 0 ? ceLtp : 0));
                            const pePrevClose = Number(peData.previous_close_price || (peLtp > 0 ? peLtp : 0));
                            const ceChange = ceLtp > 0 && cePrevClose > 0 ? Number((ceLtp - cePrevClose).toFixed(2)) : 0;
                            const peChange = peLtp > 0 && pePrevClose > 0 ? Number((peLtp - pePrevClose).toFixed(2)) : 0;
                            const ceChangePercent = cePrevClose > 0 ? Number(((ceChange / cePrevClose) * 100).toFixed(2)) : 0;
                            const peChangePercent = pePrevClose > 0 ? Number(((peChange / pePrevClose) * 100).toFixed(2)) : 0;
                            const ceGreeks = ceData.greeks || {};
                            const peGreeks = peData.greeks || {};
                            const ceBid = Number(ceData.top_bid_price || (ceLtp > 0 ? Number((ceLtp - 0.05).toFixed(2)) : 0));
                            const ceAsk = Number(ceData.top_ask_price || (ceLtp > 0 ? Number((ceLtp + 0.05).toFixed(2)) : 0));
                            const peBid = Number(peData.top_bid_price || (peLtp > 0 ? Number((peLtp - 0.05).toFixed(2)) : 0));
                            const peAsk = Number(peData.top_ask_price || (peLtp > 0 ? Number((peLtp + 0.05).toFixed(2)) : 0));
                            if (ceLtp > 0) {
                                const ceTickObj = {
                                    instrumentToken: ceToken,
                                    exchange: cleanSym === 'SENSEX' ? 'BSE' : 'NSE',
                                    symbol: `${cleanSym} ${strikePrice} CE`,
                                    ltp: ceLtp,
                                    open: Number(ceData.average_price || ceLtp),
                                    high: Number(ceData.high || ceLtp),
                                    low: Number(ceData.low || ceLtp),
                                    close: cePrevClose,
                                    volume: Number(ceData.volume || 0),
                                    change: ceChange,
                                    changePercent: ceChangePercent,
                                    bid: ceBid,
                                    ask: ceAsk,
                                    bidQty: Number(ceData.top_bid_quantity || 100),
                                    askQty: Number(ceData.top_ask_quantity || 100),
                                    source: 'dhan',
                                    isSynthetic: false,
                                    timestamp: Date.now()
                                };
                                engine.setCachedTick(ceTickObj);
                                this.tickCache.set(ceToken, ceTickObj);
                                if (ceSecurityId) {
                                    engine.setCachedTick({ ...ceTickObj, instrumentToken: ceSecurityId });
                                    engine.setCachedTick({ ...ceTickObj, instrumentToken: `${optPrefix}_${ceSecurityId}` });
                                }
                            }
                            if (peLtp > 0) {
                                const peTickObj = {
                                    instrumentToken: peToken,
                                    exchange: cleanSym === 'SENSEX' ? 'BSE' : 'NSE',
                                    symbol: `${cleanSym} ${strikePrice} PE`,
                                    ltp: peLtp,
                                    open: Number(peData.average_price || peLtp),
                                    high: Number(peData.high || peLtp),
                                    low: Number(peData.low || peLtp),
                                    close: pePrevClose,
                                    volume: Number(peData.volume || 0),
                                    change: peChange,
                                    changePercent: peChangePercent,
                                    bid: peBid,
                                    ask: peAsk,
                                    bidQty: Number(peData.top_bid_quantity || 100),
                                    askQty: Number(peData.top_ask_quantity || 100),
                                    source: 'dhan',
                                    isSynthetic: false,
                                    timestamp: Date.now()
                                };
                                engine.setCachedTick(peTickObj);
                                this.tickCache.set(peToken, peTickObj);
                                if (peSecurityId) {
                                    engine.setCachedTick({ ...peTickObj, instrumentToken: peSecurityId });
                                    engine.setCachedTick({ ...peTickObj, instrumentToken: `${optPrefix}_${peSecurityId}` });
                                }
                            }
                            rows.push({
                                strikePrice,
                                expiry: targetExpiry,
                                ce: {
                                    instrumentToken: ceToken,
                                    ltp: ceLtp,
                                    bid: ceBid,
                                    ask: ceAsk,
                                    change: ceChange,
                                    changePercent: ceChangePercent,
                                    volume: Number(ceData.volume || 0),
                                    openInterest: Number(ceData.oi || 0),
                                    iv: Number(Number(ceData.implied_volatility || ceData.iv || 14.5).toFixed(1)),
                                    delta: Number(ceGreeks.delta ?? 0.5),
                                    gamma: Number(ceGreeks.gamma ?? 0.001),
                                    theta: Number(ceGreeks.theta ?? -10),
                                    vega: Number(ceGreeks.vega ?? 5),
                                    source: 'dhan',
                                },
                                pe: {
                                    instrumentToken: peToken,
                                    ltp: peLtp,
                                    bid: peBid,
                                    ask: peAsk,
                                    change: peChange,
                                    changePercent: peChangePercent,
                                    volume: Number(peData.volume || 0),
                                    openInterest: Number(peData.oi || 0),
                                    iv: Number(Number(peData.implied_volatility || peData.iv || 14.5).toFixed(1)),
                                    delta: Number(peGreeks.delta ?? -0.5),
                                    gamma: Number(peGreeks.gamma ?? 0.001),
                                    theta: Number(peGreeks.theta ?? -10),
                                    vega: Number(peGreeks.vega ?? 5),
                                    source: 'dhan',
                                }
                            });
                        }
                        if (rows.length > 0) {
                            const sorted = rows.sort((a, b) => a.strikePrice - b.strikePrice);
                            DhanAdapter.optionChainCache.set(cacheKey, { timestamp: Date.now(), rows: sorted });
                            return sorted;
                        }
                    }
                }
                else {
                    DhanAdapter.optionChainFailureCooldown.set(cacheKey, Date.now() + 30000);
                    if (cached && cached.rows && cached.rows.length > 0) {
                        DhanAdapter.optionChainCache.set(cacheKey, { timestamp: Date.now(), rows: cached.rows });
                    }
                }
            }
            catch (err) {
                console.warn(`[DhanAdapter] getOptionChain failed for ${cleanSym} (${err.message}). Entering 30s cooldown.`);
                DhanAdapter.optionChainFailureCooldown.set(cacheKey, Date.now() + 30000);
            }
            finally {
                DhanAdapter.pendingOptionChainRequests.delete(cacheKey);
            }
            if (cached && cached.rows && cached.rows.length > 0) {
                return cached.rows;
            }
            return [];
        })();
        DhanAdapter.pendingOptionChainRequests.set(cacheKey, fetchPromise);
        return fetchPromise;
    }
    /**
     * Calls Dhan HQ official POST /margincalculator API according to Dhan v2 spec.
     */
    async calculateMargin(params) {
        try {
            const url = `${this.baseUrl}/v2/margincalculator`;
            const res = await fetch(url, {
                method: 'POST',
                headers: {
                    'access-token': this.accessToken,
                    'client-id': this.clientId,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    dhanClientId: this.clientId,
                    exchangeSegment: params.exchangeSegment,
                    transactionType: params.transactionType,
                    quantity: params.quantity,
                    productType: params.productType,
                    securityId: params.securityId,
                    price: params.price
                })
            });
            if (res.ok) {
                return await res.json();
            }
        }
        catch (err) {
            console.warn('[DhanAdapter] Margin Calculator API error:', err.message);
        }
        return null;
    }
}
exports.DhanAdapter = DhanAdapter;
