"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MarketDataEngine = void 0;
const AngelOneAdapter_1 = require("./AngelOneAdapter");
const DhanAdapter_1 = require("./DhanAdapter");
const FyersAdapter_1 = require("./FyersAdapter");
const MockMarketDataProvider_1 = require("./MockMarketDataProvider");
const redis_1 = require("../db/redis");
const crypto_1 = require("../utils/crypto");
class MarketDataEngine {
    static instance;
    instanceId = (0, crypto_1.generateUUID)();
    providers = new Map();
    activeProvider;
    dhanProvider;
    fyersProvider;
    angelOneProvider;
    mockProvider;
    tickCache = new Map();
    globalCallbacks = new Set();
    subscribedTokens = new Set();
    // ── Auto-Failover Telemetry & State ──────────────────────────────────────
    lastTickTime = 0;
    failoverActive = false;
    failoverTimer = null;
    configuredProviderName = 'ANGEL_ONE';
    constructor() {
        this.mockProvider = new MockMarketDataProvider_1.MockMarketDataProvider();
        this.angelOneProvider = new AngelOneAdapter_1.AngelOneAdapter();
        this.dhanProvider = new DhanAdapter_1.DhanAdapter();
        this.fyersProvider = new FyersAdapter_1.FyersAdapter();
        this.providers.set(this.angelOneProvider.name, this.angelOneProvider);
        this.providers.set('ANGEL_ONE', this.angelOneProvider);
        this.providers.set('ANGELONE', this.angelOneProvider);
        this.providers.set(this.dhanProvider.name, this.dhanProvider);
        this.providers.set('DHAN', this.dhanProvider);
        this.providers.set(this.fyersProvider.name, this.fyersProvider);
        this.providers.set('FYERS', this.fyersProvider);
        this.providers.set(this.mockProvider.name, this.mockProvider);
        this.providers.set('MOCK', this.mockProvider);
        const configured = (process.env.PRIMARY_MARKET_DATA_PROVIDER || 'ANGELONE').toUpperCase();
        if (configured.includes('ANGEL')) {
            this.configuredProviderName = 'ANGEL_ONE';
            this.activeProvider = this.angelOneProvider;
        }
        else if (configured === 'FYERS') {
            this.configuredProviderName = 'FYERS';
            this.activeProvider = this.fyersProvider;
        }
        else {
            this.configuredProviderName = 'DHAN';
            this.activeProvider = this.dhanProvider;
        }
        // Subscribe to Redis pub/sub for tick broadcasts only in multi-node cluster deployments
        if (process.env.CLUSTER_MODE === 'true') {
            redis_1.redis.subscribe('market:ticks', (msg) => {
                try {
                    const payload = JSON.parse(msg);
                    // Ignore self-published frames to avoid double fan-out loop
                    if (payload._origin && payload._origin === this.instanceId)
                        return;
                    this.lastTickTime = Date.now();
                    this.failoverActive = false;
                    const tick = payload;
                    this.setCachedTick(tick);
                    this.globalCallbacks.forEach(cb => cb(tick));
                }
                catch (_) { }
            });
            // Primary node listens to subscription requests forwarded by worker nodes
            if (process.env.PROCESS_ROLE !== 'worker') {
                redis_1.redis.subscribe('market:subscriptions', (msg) => {
                    try {
                        const tokens = JSON.parse(msg);
                        if (Array.isArray(tokens) && tokens.length > 0) {
                            this.subscribe(tokens);
                        }
                    }
                    catch (_) { }
                });
            }
        }
    }
    static getInstance() {
        if (!MarketDataEngine.instance) {
            MarketDataEngine.instance = new MarketDataEngine();
        }
        return MarketDataEngine.instance;
    }
    /**
     * Evaluates if current time is within Indian Market hours:
     * - EQUITY: 9:15 AM - 3:30 PM IST (Mon-Fri)
     * - COMMODITY / MCX: 9:00 AM - 11:30 PM IST (Mon-Fri)
     */
    static isMarketHours(segment = 'EQUITY') {
        const now = new Date();
        const utcMs = now.getTime() + (now.getTimezoneOffset() * 60000);
        const istDate = new Date(utcMs + (330 * 60000));
        const day = istDate.getDay(); // 0 = Sun, 6 = Sat
        if (day === 0 || day === 6)
            return false; // Weekend
        const hours = istDate.getHours();
        const minutes = istDate.getMinutes();
        const timeInMins = hours * 60 + minutes;
        const seg = (segment || 'EQUITY').toUpperCase();
        if (seg === 'COMMODITY' || seg === 'MCX' || seg === 'MCX_COMM') {
            return timeInMins >= 540 && timeInMins <= 1435;
        }
        return timeInMins >= 555 && timeInMins <= 930;
    }
    async initialize() {
        const configured = (process.env.PRIMARY_MARKET_DATA_PROVIDER || 'ANGELONE').toUpperCase();
        if (configured.includes('ANGEL')) {
            this.configuredProviderName = 'ANGEL_ONE';
            this.activeProvider = this.angelOneProvider;
        }
        else if (configured === 'FYERS') {
            this.configuredProviderName = 'FYERS';
            this.activeProvider = this.fyersProvider;
        }
        else {
            this.configuredProviderName = 'DHAN';
            this.activeProvider = this.dhanProvider;
        }
        console.log(`[MarketDataEngine] 🚀 Initializing Market Data Engine with active provider: ${this.configuredProviderName}...`);
        const defaultTokens = [
            'NSE_NIFTY50', 'NSE_BANKNIFTY', 'BSE_SENSEX', 'NSE_FINNIFTY', 'NSE_MIDCPNIFTY',
            'NSE_RELIANCE', 'NSE_TCS', 'NSE_INFY', 'NSE_HDFCBANK', 'NSE_ICICIBANK', 'NSE_TATAMOTORS',
            'MCX_CRUDEOIL', 'MCX_GOLD', 'MCX_SILVER', 'MCX_NATURALGAS', 'MCX_COPPER', 'MCX_GOLDM', 'MCX_SILVERM',
        ];
        defaultTokens.forEach(t => this.subscribedTokens.add(t));
        // Hydrate local cache from persistent Redis tick store
        try {
            for (const tok of defaultTokens) {
                const cachedRaw = await redis_1.redis.get(`tick:${tok}`);
                if (cachedRaw) {
                    const tick = JSON.parse(cachedRaw);
                    if (tick && tick.ltp > 0) {
                        this.setCachedTick(tick);
                    }
                }
            }
        }
        catch (_) { }
        const isWorker = process.env.PROCESS_ROLE === 'worker';
        if (isWorker) {
            console.log(`[MarketDataEngine] 🛡️ Worker Role Active (${process.env.PORT || 'replica'}) — Skipping direct upstream WebSocket feed. Consuming ticks via Redis Pub/Sub.`);
            try {
                if (typeof this.activeProvider.seedCoreIndexQuotes === 'function') {
                    await this.activeProvider.seedCoreIndexQuotes();
                }
            }
            catch (_) { }
            console.log(`[MarketDataEngine] ✅ Engine Ready (Worker Replica) | Active: ${this.configuredProviderName} | Tokens: ${this.subscribedTokens.size} | Cached: ${this.tickCache.size}`);
            return;
        }
        // Connect to configured primary broker feed
        try {
            if (this.configuredProviderName === 'DHAN') {
                const { setDhanAdapterRef } = require('../utils/dhanTokenRefresh');
                setDhanAdapterRef(this.dhanProvider);
            }
            this.activeProvider.subscribe(Array.from(this.subscribedTokens), (tick) => {
                this.lastTickTime = Date.now();
                this.failoverActive = false;
                this.broadcastTick(tick);
            });
            await this.activeProvider.initialize();
            // Seed any quotes received during initialization into cache & Redis
            if (typeof this.activeProvider.getAllCachedTicks === 'function') {
                for (const tick of this.activeProvider.getAllCachedTicks()) {
                    this.broadcastTick(tick);
                }
            }
        }
        catch (err) {
            console.warn(`[MarketDataEngine] ${this.configuredProviderName} initialization warning:`, err.message);
        }
        console.log(`[MarketDataEngine] ✅ Engine Ready | Active: ${this.configuredProviderName} (Live Feed) | Tokens: ${this.subscribedTokens.size} | Cached: ${this.tickCache.size}`);
    }
    lastRedisWriteByToken = new Map();
    /**
     * Broadcasts tick to local cache, Redis circular buffer, and all client WebSocket listeners.
     * Dispatches immediately to local in-memory subscribers (0ms latency), and throttles
     * Redis pipeline writes to 250ms per token to prevent TCP socket buffer saturation and memory leaks.
     */
    broadcastTick(tick) {
        this.setCachedTick(tick);
        this.globalCallbacks.forEach(cb => cb(tick));
        const now = Date.now();
        const lastWrite = this.lastRedisWriteByToken.get(tick.instrumentToken) || 0;
        if (now - lastWrite >= 250) {
            this.lastRedisWriteByToken.set(tick.instrumentToken, now);
            redis_1.redis.set(`tick:${tick.instrumentToken}`, JSON.stringify(tick), 3600).catch(() => { });
            redis_1.redis.rpushTrim(`market:ticks:${tick.instrumentToken}`, JSON.stringify({
                ltp: tick.ltp,
                timestamp: tick.timestamp || now,
                volume: tick.volume,
                open: tick.open,
                high: tick.high,
                low: tick.low,
                close: tick.close
            }), 500).catch(() => { });
            if (process.env.CLUSTER_MODE === 'true') {
                redis_1.redis.publish('market:ticks', JSON.stringify({ ...tick, _origin: this.instanceId })).catch(() => { });
            }
        }
    }
    /**
     * Retrieves buffered tick history from Redis circular list
     */
    async getTickHistory(token, limit = 500) {
        if (!token)
            return [];
        try {
            const rawList = await redis_1.redis.lrange(`market:ticks:${token}`, -Math.min(limit, 1000), -1);
            return rawList.map(item => {
                try {
                    return JSON.parse(item);
                }
                catch {
                    return null;
                }
            }).filter(Boolean);
        }
        catch {
            return [];
        }
    }
    getDhanAdapter() {
        return this.dhanProvider;
    }
    getAngelOneAdapter() {
        return this.angelOneProvider;
    }
    getActiveProviderName() {
        return this.activeProvider ? this.activeProvider.name : this.configuredProviderName;
    }
    getHybridStatus() {
        const now = Date.now();
        const activeName = this.getActiveProviderName();
        return {
            mode: `${activeName}_PRIMARY`,
            primaryLiveStream: activeName,
            historicalCandlesProvider: activeName,
            optionGreeksProvider: `${activeName} / OptionChainEngine`,
            failoverActive: false,
            lastTickMsAgo: this.lastTickTime > 0 ? now - this.lastTickTime : -1,
            subscribedTokenCount: this.subscribedTokens.size
        };
    }
    getFeedHealth() {
        const now = Date.now();
        const marketOpen = MarketDataEngine.isMarketHours();
        const quietMs = this.lastTickTime > 0 ? (now - this.lastTickTime) : Infinity;
        let status = 'DISCONNECTED';
        if (!marketOpen) {
            status = 'CLOSED';
        }
        else if (quietMs <= 15000) {
            status = 'LIVE';
        }
        else if (quietMs < 60000) {
            status = 'STALE';
        }
        else {
            status = 'DISCONNECTED';
        }
        return {
            ...this.getHybridStatus(),
            status,
            marketOpen,
            provider: this.getActiveProviderName()
        };
    }
    getPipelineMetrics() {
        return {
            activeProvider: this.getActiveProviderName(),
            cachedTicksCount: this.tickCache.size,
            subscribedTokensCount: this.subscribedTokens.size,
            providerConnections: 1,
            refCountedTokens: this.subscribedTokens.size,
            failoverActive: this.failoverActive
        };
    }
    async switchPrimaryProvider(providerName) {
        const targetName = providerName.toUpperCase();
        const provider = this.providers.get(targetName) || this.providers.get(providerName);
        if (!provider) {
            throw new Error(`Market Data Provider '${providerName}' is not recognized.`);
        }
        console.log(`[MarketDataEngine] 🔄 Switching Primary Provider to '${provider.name}'`);
        this.configuredProviderName = targetName;
        this.activeProvider = provider;
        this.failoverActive = (targetName === 'MOCK' || targetName === 'MOCK_ENGINE');
        process.env.PRIMARY_MARKET_DATA_PROVIDER = targetName;
        try {
            if (typeof provider.initialize === 'function') {
                await provider.initialize();
            }
            provider.subscribe(Array.from(this.subscribedTokens), (tick) => {
                this.lastTickTime = Date.now();
                this.broadcastTick(tick);
            });
        }
        catch (err) {
            console.warn(`[MarketDataEngine] Warning when switching to ${targetName}:`, err.message);
        }
        return true;
    }
    updateProviderCredentials(keys) {
        if (keys.FYERS_APP_ID)
            process.env.FYERS_APP_ID = keys.FYERS_APP_ID;
        if (keys.FYERS_SECRET_KEY)
            process.env.FYERS_SECRET_KEY = keys.FYERS_SECRET_KEY;
        if (keys.FYERS_TOTP_SECRET)
            process.env.FYERS_TOTP_SECRET = keys.FYERS_TOTP_SECRET;
        if (keys.FYERS_PIN)
            process.env.FYERS_PIN = keys.FYERS_PIN;
        if (keys.FYERS_CLIENT_ID)
            process.env.FYERS_CLIENT_ID = keys.FYERS_CLIENT_ID;
        if (keys.FYERS_ACCESS_TOKEN)
            process.env.FYERS_ACCESS_TOKEN = keys.FYERS_ACCESS_TOKEN;
        if (keys.FYERS_REDIRECT_URI)
            process.env.FYERS_REDIRECT_URI = keys.FYERS_REDIRECT_URI;
        if (keys.ANGELONE_API_KEY) {
            process.env.ANGELONE_API_KEY = keys.ANGELONE_API_KEY;
            process.env.SMARTAPI_API_KEY = keys.ANGELONE_API_KEY;
        }
        if (keys.ANGELONE_CLIENT_ID) {
            process.env.ANGELONE_CLIENT_ID = keys.ANGELONE_CLIENT_ID;
            process.env.SMARTAPI_CLIENT_CODE = keys.ANGELONE_CLIENT_ID;
        }
        if (keys.ANGELONE_CLIENT_SECRET) {
            process.env.ANGELONE_CLIENT_SECRET = keys.ANGELONE_CLIENT_SECRET;
            process.env.SMARTAPI_PASSWORD = keys.ANGELONE_CLIENT_SECRET;
        }
        if (keys.ANGELONE_TOTP_SECRET) {
            process.env.ANGELONE_TOTP_SECRET = keys.ANGELONE_TOTP_SECRET;
            process.env.SMARTAPI_TOTP_SECRET = keys.ANGELONE_TOTP_SECRET;
        }
        if (keys.DHAN_CLIENT_ID)
            process.env.DHAN_CLIENT_ID = keys.DHAN_CLIENT_ID;
        if (keys.DHAN_TOTP_SECRET)
            process.env.DHAN_TOTP_SECRET = keys.DHAN_TOTP_SECRET;
        if (keys.DHAN_PIN)
            process.env.DHAN_PIN = keys.DHAN_PIN;
        if (keys.DHAN_ACCESS_TOKEN)
            process.env.DHAN_ACCESS_TOKEN = keys.DHAN_ACCESS_TOKEN;
        if (keys.DHAN_API_KEY)
            process.env.DHAN_API_KEY = keys.DHAN_API_KEY;
        if (keys.DHAN_API_SECRET)
            process.env.DHAN_API_SECRET = keys.DHAN_API_SECRET;
    }
    setCachedTick(tick) {
        if (!tick || !tick.instrumentToken)
            return;
        const existing = this.tickCache.get(tick.instrumentToken);
        if (existing && existing.timestamp && tick.timestamp && tick.timestamp < existing.timestamp) {
            return; // Reject out-of-order stale tick
        }
        this.tickCache.set(tick.instrumentToken, tick);
        try {
            const { SymbologyNormalizer } = require('./SymbologyNormalizer');
            const aliases = SymbologyNormalizer.normalizeToken(tick.instrumentToken);
            for (const alias of aliases) {
                this.tickCache.set(alias, tick);
            }
        }
        catch (_) { }
    }
    getCachedTick(instrumentToken) {
        if (!instrumentToken)
            return undefined;
        const direct = this.tickCache.get(instrumentToken);
        if (direct)
            return direct;
        try {
            const { SymbologyNormalizer } = require('./SymbologyNormalizer');
            const aliases = SymbologyNormalizer.normalizeToken(instrumentToken);
            for (const alias of aliases) {
                const match = this.tickCache.get(alias);
                if (match)
                    return match;
            }
        }
        catch (_) { }
        return undefined;
    }
    async getQuote(instrumentToken) {
        const cached = this.getCachedTick(instrumentToken);
        if (cached)
            return cached;
        try {
            const tick = await this.activeProvider.getQuote(instrumentToken);
            if (tick) {
                this.setCachedTick(tick);
                return tick;
            }
        }
        catch (_) { }
        return null;
    }
    getAllCachedTicks() {
        return Array.from(this.tickCache.values());
    }
    subscribe(tokens) {
        if (!tokens || tokens.length === 0)
            return;
        tokens.forEach(t => this.subscribedTokens.add(t));
        const isWorker = process.env.PROCESS_ROLE === 'worker';
        if (isWorker && process.env.CLUSTER_MODE === 'true') {
            redis_1.redis.publish('market:subscriptions', JSON.stringify(tokens)).catch(() => { });
            return;
        }
        try {
            this.activeProvider.subscribe(tokens, (tick) => {
                this.lastTickTime = Date.now();
                this.broadcastTick(tick);
            });
        }
        catch (_) { }
    }
    unsubscribe(tokens) {
        if (!tokens || tokens.length === 0)
            return;
        tokens.forEach(t => this.subscribedTokens.delete(t));
        try {
            this.activeProvider.unsubscribe(tokens);
        }
        catch (_) { }
    }
    onTick(callback) {
        this.globalCallbacks.add(callback);
    }
    /**
     * Historical Candles — dispatched via active provider
     */
    async getHistoricalCandles(instrumentToken, timeframe, count) {
        try {
            const candles = await this.activeProvider.getHistoricalCandles(instrumentToken, timeframe, count);
            if (candles && candles.length > 0)
                return candles;
        }
        catch (_) { }
        return [];
    }
    /**
     * Option Chain — dispatched via active provider
     */
    async getOptionChain(symbol, expiry) {
        try {
            const chain = await this.activeProvider.getOptionChain(symbol, expiry);
            if (chain && chain.length > 0)
                return chain;
        }
        catch (_) { }
        return [];
    }
    getOptionExpiries(symbol) {
        const prov = this.activeProvider;
        if (typeof prov.getOptionExpiries === 'function') {
            return prov.getOptionExpiries(symbol);
        }
        return [];
    }
}
exports.MarketDataEngine = MarketDataEngine;
