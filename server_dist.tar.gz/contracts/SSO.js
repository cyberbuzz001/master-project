"use strict";
/**
 * Unified SSO Cross-System Token Contract
 */
Object.defineProperty(exports, "__esModule", { value: true });
