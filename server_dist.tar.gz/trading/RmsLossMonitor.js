"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.runCycle = runCycle;
exports.startRmsLossMonitor = startRmsLossMonitor;
exports.stopRmsLossMonitor = stopRmsLossMonitor;
/**
 * RmsLossMonitor.ts
 * Continuous polling engine for the six-tier RMS risk thresholds
 * (50/60/70/80/90/100% unrealized-loss-as-%-of-required-margin). See the
 * Phase 2 section of the RMS overhaul plan for the full design rationale —
 * notably why this polls every few seconds rather than hooking the tick
 * pipeline directly (that chain is fully synchronous end-to-end; a slow
 * handler there would freeze live pricing for the whole platform).
 */
const schema_1 = require("../db/schema");
const redis_1 = require("../db/redis");
const audit_1 = require("../middleware/audit");
const adminEventBus_1 = require("../utils/adminEventBus");
const adminNotifications_1 = require("../utils/adminNotifications");
const OMS_1 = require("./OMS");
const RmsSquareOffAction_1 = require("./RmsSquareOffAction");
const MarginMath_1 = require("./MarginMath");
const CYCLE_LOCK_KEY = 'lock:rms:loss-monitor-cycle';
const SQUAREOFF_EVENT_TYPE = 'RMS_LOSS_SQUARE_OFF';
const SQUAREOFF_REASON = 'LOSS_THRESHOLD';
const FAILED_ATTEMPT_COOLDOWN_MS = 30000;
const DEGRADED_CHECK_EVERY_N_CYCLES = 20;
const DEGRADED_THRESHOLD_FRACTION = 0.5;
const SWEEP_EVERY_N_CYCLES = 50;
let timeoutHandle = null;
let running = false;
// In-memory only — acceptable for a single-instance app (see plan). Re-set
// from scratch on every cycle's fresh position fetch, so a restart just
// means "everything looks like a fresh crossing once," not unsafe.
const lastActionedTier = new Map(); // positionId -> sort_order
const squareOffCooldownUntil = new Map(); // positionId -> epoch ms
let cachedTiers = null;
let cycleCount = 0;
let unpricedStreak = 0;
let degradedAlertSent = false;
async function getConfig() {
    const rows = await (0, schema_1.query)(`SELECT key, value FROM system_settings WHERE key IN ('RMS_MODE','RMS_LOSS_MONITOR_ENABLED','RMS_LOSS_MONITOR_INTERVAL_MS')`);
    const map = new Map(rows.map((r) => [r.key, r.value]));
    return {
        enabled: (map.get('RMS_LOSS_MONITOR_ENABLED') || 'true') === 'true',
        mode: map.get('RMS_MODE') === 'LIVE' ? 'LIVE' : 'SIMULATION',
        intervalMs: parseInt(map.get('RMS_LOSS_MONITOR_INTERVAL_MS') || '3000', 10) || 3000,
    };
}
async function getTiers() {
    if (cachedTiers && Date.now() < cachedTiers.expiresAt)
        return cachedTiers.tiers;
    const tiers = await (0, schema_1.query)('SELECT * FROM rms_risk_tiers ORDER BY sort_order ASC');
    cachedTiers = { tiers, expiresAt: Date.now() + 60000 };
    return tiers;
}
/** Highest tier whose threshold_pct is at or below lossPct, or null if below every tier. */
function highestTierCrossed(tiers, lossPct) {
    let best = null;
    for (const t of tiers) {
        if (lossPct >= t.threshold_pct)
            best = t;
    }
    return best;
}
async function suspendAccount(userId, reasonDetail, mode) {
    if (mode !== 'LIVE') {
        await (0, audit_1.logAuditAction)('SYSTEM', 'SYSTEM', 'RMS_HARD_BREACH_SUSPEND_SIMULATED', 'USER', userId, null, { reasonDetail }, '127.0.0.1');
        return;
    }
    await (0, schema_1.execute)(`UPDATE users SET status = 'SUSPENDED', suspended_reason = $1, suspended_by = 'SYSTEM', suspended_at = NOW(), updated_at = NOW() WHERE id = $2`, [reasonDetail, userId]);
    await (0, audit_1.logAuditAction)('SYSTEM', 'SYSTEM', 'RMS_HARD_BREACH_SUSPEND_EXECUTED', 'USER', userId, null, { reasonDetail }, '127.0.0.1');
    adminEventBus_1.adminEventBus.emitUserEvent('USER_STATUS_UPDATED', userId, { status: 'SUSPENDED', reason: reasonDetail, suspendedBy: 'SYSTEM' });
    await (0, adminNotifications_1.createAdminNotification)('RMS_HARD_BREACH_SUSPEND', userId, { reasonDetail, severity: 'CRITICAL' });
}
async function cancelAllOtherOrders(userId, exceptSymbol, exceptProductType) {
    const orders = await (0, schema_1.query)(`SELECT order_id FROM orders WHERE user_id = $1 AND status IN ('ACCEPTED','PENDING','EXECUTING') AND NOT (symbol = $2 AND product_type = $3)`, [userId, exceptSymbol, exceptProductType]);
    for (const o of orders) {
        await OMS_1.OMS.cancelOrder(o.order_id, userId);
    }
}
/** Exported for direct invocation — manual admin testing/verification, mirroring RmsAutoSquareOffEngine.run(). */
async function runCycle() {
    const { enabled, mode } = await getConfig();
    cycleCount++;
    if (!enabled)
        return;
    const lockAcquired = await redis_1.redis.acquireLock(CYCLE_LOCK_KEY, 10, 'rms-loss-monitor');
    if (!lockAcquired)
        return; // another cycle (or a slow previous one) is still running
    try {
        const tiers = await getTiers();
        const positions = await (0, schema_1.query)(`SELECT * FROM positions WHERE net_qty != 0`);
        const seenIds = new Set();
        let unpricedThisCycle = 0;
        let scopedCount = 0;
        for (const pos of positions) {
            const netQty = parseInt(pos.net_qty, 10);
            seenIds.add(pos.id);
            if (netQty === 0) {
                lastActionedTier.delete(pos.id);
                squareOffCooldownUntil.delete(pos.id);
                continue;
            }
            const side = netQty > 0 ? 'BUY' : 'SELL';
            const quantity = Math.abs(netQty);
            const optionDetails = (0, MarginMath_1.resolveOptionDetails)(pos.symbol, null);
            // Leverage-scope rule: only MIS (any instrument), or option-SELL
            // (writing) positions on any product type, carry a leverage-derived
            // required margin. CNC/NRML non-option (or option-BUY) positions have
            // requiredMargin == full notional, making a "% of margin lost" tier
            // meaningless (would need a ~100% price collapse to ever fire).
            const inScope = pos.product_type === 'MIS' || (!!optionDetails && side === 'SELL');
            if (!inScope)
                continue;
            scopedCount++;
            let spotPrice;
            let marginParams = { spanMarginRate: 0, exposureMarginRate: 0, additionalMarginRate: 0 };
            if (optionDetails && side === 'SELL') {
                spotPrice = (0, MarginMath_1.resolveSpotPrice)(optionDetails.underlying).price;
                marginParams = await (0, MarginMath_1.getMarginParams)(optionDetails.underlying);
            }
            const price = parseFloat(pos.ltp) > 0 ? parseFloat(pos.ltp) : parseFloat(pos.average_price || '0');
            const requiredMargin = (0, MarginMath_1.marginForLeg)({
                productType: pos.product_type, side, quantity, price,
                optionType: optionDetails?.optionType, strike: optionDetails?.strike,
                spotPrice, marginParams, charges: MarginMath_1.ZERO_CHARGES,
            }).requiredMargin;
            if (requiredMargin <= 0)
                continue;
            const { ltp, unrealizedPnl } = (0, MarginMath_1.resolveUnrealizedPnlForPosition)({
                symbol: pos.symbol, netQty, averagePrice: parseFloat(pos.average_price), dbLtp: parseFloat(pos.ltp || 0),
            });
            if (ltp <= 0) {
                // Genuinely no usable price this cycle — never treat as zero loss.
                // Leave any existing tier state untouched; just count it for the
                // platform-level degraded check below.
                unpricedThisCycle++;
                continue;
            }
            const lossPct = unrealizedPnl < 0 ? (Math.abs(unrealizedPnl) / requiredMargin) * 100 : 0;
            const tier = highestTierCrossed(tiers, lossPct);
            const currentSortOrder = tier?.sort_order ?? 0;
            const previousSortOrder = lastActionedTier.get(pos.id) ?? 0;
            if (currentSortOrder <= previousSortOrder) {
                continue; // no new escalation; stays silent (or already actioned) at this level
            }
            lastActionedTier.set(pos.id, currentSortOrder);
            if (!tier)
                continue; // currentSortOrder can't be >0 without a tier, but keeps TS happy
            const exitSide = netQty > 0 ? 'SELL' : 'BUY';
            const exitQty = Math.abs(netQty);
            if (tier.action === 'LOG') {
                await (0, RmsSquareOffAction_1.recordRiskEvent)(`RMS_LOSS_TIER_${tier.tier_name}`, mode !== 'LIVE', pos, exitSide, exitQty, {
                    severity: tier.severity, lossPct: Number(lossPct.toFixed(2)), requiredMargin, unrealizedPnl,
                });
                continue;
            }
            if (tier.action === 'RESTRICT') {
                if (mode === 'LIVE') {
                    await (0, schema_1.execute)(`UPDATE users SET risk_restriction = 'REDUCE_ONLY', updated_at = NOW() WHERE id = $1 AND risk_restriction IS DISTINCT FROM 'REDUCE_ONLY'`, [pos.user_id]);
                }
                await (0, RmsSquareOffAction_1.recordRiskEvent)(`RMS_LOSS_TIER_${tier.tier_name}`, mode !== 'LIVE', pos, exitSide, exitQty, {
                    severity: tier.severity, lossPct: Number(lossPct.toFixed(2)), requiredMargin, unrealizedPnl,
                });
                continue;
            }
            // SQUAREOFF or SUSPEND from here — both need the position closed.
            const cooldownUntil = squareOffCooldownUntil.get(pos.id);
            if (cooldownUntil && Date.now() < cooldownUntil) {
                continue; // recently failed; back off rather than retry-storm
            }
            const pendingRmsOrder = await (0, schema_1.queryOne)(`SELECT id FROM orders WHERE user_id = $1 AND symbol = $2 AND product_type = $3 AND source = 'RMS' AND status IN ('ACCEPTED','PENDING','EXECUTING') LIMIT 1`, [pos.user_id, pos.symbol, pos.product_type]);
            if (pendingRmsOrder) {
                continue; // already in flight (from this monitor or the EOD engine) — let it resolve
            }
            const result = await (0, RmsSquareOffAction_1.executeSquareOff)(pos, { mode, reason: SQUAREOFF_REASON, eventType: SQUAREOFF_EVENT_TYPE });
            if (result.status === 'FAILED') {
                squareOffCooldownUntil.set(pos.id, Date.now() + FAILED_ATTEMPT_COOLDOWN_MS);
            }
            if (tier.action === 'SUSPEND' && (result.status === 'SUBMITTED' || result.status === 'SIMULATED' || result.status === 'SKIPPED')) {
                if (mode === 'LIVE') {
                    await cancelAllOtherOrders(pos.user_id, pos.symbol, pos.product_type);
                }
                await suspendAccount(pos.user_id, `RMS_HARD_BREACH: unrealized loss reached ${lossPct.toFixed(1)}% of required margin on ${pos.symbol}`, mode);
            }
        }
        // Defensive sweep: drop any tracked position id that no longer exists at
        // all (positions closed and never re-touched by this loop's inline clear).
        if (cycleCount % SWEEP_EVERY_N_CYCLES === 0) {
            for (const id of Array.from(lastActionedTier.keys())) {
                if (!seenIds.has(id)) {
                    lastActionedTier.delete(id);
                    squareOffCooldownUntil.delete(id);
                }
            }
        }
        // Degraded-feed detection: don't let "couldn't price it" look like "fine".
        if (scopedCount > 0 && unpricedThisCycle / scopedCount >= DEGRADED_THRESHOLD_FRACTION) {
            unpricedStreak++;
        }
        else {
            unpricedStreak = 0;
            degradedAlertSent = false;
        }
        if (unpricedStreak >= DEGRADED_CHECK_EVERY_N_CYCLES && !degradedAlertSent) {
            degradedAlertSent = true;
            await (0, schema_1.execute)(`INSERT INTO risk_events (id, customer_id, event_type, severity, details) VALUES ($1, NULL, 'RMS_LOSS_MONITOR_DEGRADED', 'HIGH', $2)`, ['rev_' + Date.now().toString(36) + Math.random().toString(36).slice(2), JSON.stringify({ unpricedThisCycle, scopedCount, cycleCount })]).catch((err) => console.error('[RmsLossMonitor] Failed to record degraded event:', err.message));
            await (0, adminNotifications_1.createAdminNotification)('RMS_LOSS_MONITOR_DEGRADED', null, { severity: 'CRITICAL', unpricedThisCycle, scopedCount, cycleCount });
            console.warn(`[RmsLossMonitor] Loss monitor appears to be running blind — ${unpricedThisCycle}/${scopedCount} in-scope positions have no usable price across ${DEGRADED_CHECK_EVERY_N_CYCLES}+ cycles.`);
        }
    }
    catch (err) {
        console.error('[RmsLossMonitor] Cycle error:', err.message);
    }
    finally {
        await redis_1.redis.releaseLock(CYCLE_LOCK_KEY).catch(() => { });
    }
}
async function scheduleNextCycle() {
    const { intervalMs } = await getConfig().catch(() => ({ enabled: true, mode: 'SIMULATION', intervalMs: 3000 }));
    timeoutHandle = setTimeout(async () => {
        await runCycle().catch((err) => console.error('[RmsLossMonitor] Unhandled cycle error:', err.message));
        scheduleNextCycle();
    }, intervalMs);
}
function startRmsLossMonitor() {
    if (running)
        return;
    running = true;
    console.log('[RmsLossMonitor] Starting continuous loss-tier monitor.');
    scheduleNextCycle();
}
function stopRmsLossMonitor() {
    if (timeoutHandle)
        clearTimeout(timeoutHandle);
    running = false;
}
