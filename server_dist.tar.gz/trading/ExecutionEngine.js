"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExecutionEngine = void 0;
exports.isIndianMarketOpen = isIndianMarketOpen;
const schema_1 = require("../db/schema");
const MarketDataEngine_1 = require("../marketData/MarketDataEngine");
const VirtualWalletLedger_1 = require("./VirtualWalletLedger");
const PortfolioService_1 = require("./PortfolioService");
const crypto_1 = require("../utils/crypto");
const SymbologyNormalizer_1 = require("../marketData/SymbologyNormalizer");
const adminEventBus_1 = require("../utils/adminEventBus");
const GttEngine_1 = require("./GttEngine");
const PriceAlertEngine_1 = require("./PriceAlertEngine");
function isIndianMarketOpen() {
    const now = new Date();
    const utcHours = now.getUTCHours();
    const utcMinutes = now.getUTCMinutes();
    const istMinutes = (utcHours * 60 + utcMinutes + 330) % 1440;
    const day = now.getUTCDay();
    if (day === 0 || day === 6)
        return false;
    return istMinutes >= 555 && istMinutes <= 930;
}
class ExecutionEngine {
    static timer = null;
    static repairTimer = null;
    static isSubscribedToTicks = false;
    // ── High-Speed In-Memory Pending Order Index ──────────────────────────────
    // Keyed by normalized token/symbol -> Map<orderId, orderObj>
    static pendingOrdersByToken = new Map();
    static start() {
        console.log('[ExecutionEngine] Starting Event-Driven & In-Memory Matching Engine...');
        if (this.timer)
            clearInterval(this.timer);
        if (this.repairTimer)
            clearInterval(this.repairTimer);
        // Initialize GTT trigger engine and Price Alert engine
        void GttEngine_1.gttEngine.initialize();
        void PriceAlertEngine_1.priceAlertEngine.initialize();
        // Auto-heal any orphaned EXECUTING orders on startup
        (0, schema_1.execute)(`UPDATE orders SET status = 'ACCEPTED', updated_at = NOW() 
       WHERE status = 'EXECUTING' AND id NOT IN (SELECT order_id FROM executions)`).catch(() => { });
        (0, schema_1.execute)(`UPDATE orders SET status = 'FILLED', filled_quantity = quantity, updated_at = NOW() 
       WHERE status = 'EXECUTING' AND id IN (SELECT order_id FROM executions)`).catch(() => { });
        // Hook directly into real-time MarketDataEngine tick stream for sub-millisecond fills & triggers
        if (!this.isSubscribedToTicks) {
            MarketDataEngine_1.MarketDataEngine.getInstance().onTick((tick) => {
                this.onMarketTick(tick);
                void GttEngine_1.gttEngine.onMarketTick(tick);
                void PriceAlertEngine_1.priceAlertEngine.onMarketTick(tick);
            });
            this.isSubscribedToTicks = true;
        }
        // Run passive background safety & reconciliation cycle every 500ms
        this.timer = setInterval(() => {
            this.processPendingOrders().catch(err => {
                if (process.env.DEBUG_ORDER_ENGINE === 'true') {
                    console.error('[ExecutionEngine] Reconciliation cycle warning:', err.message);
                }
            });
        }, 500);
        // Run position audit/repair every 60 seconds
        this.repairTimer = setInterval(() => {
            PortfolioService_1.PortfolioService.auditAndRepairAllPositions().catch(() => { });
        }, 60000);
    }
    static stop() {
        if (this.timer)
            clearInterval(this.timer);
        if (this.repairTimer)
            clearInterval(this.repairTimer);
    }
    /**
     * Register a pending order into the high-speed in-memory matching tree.
     */
    static registerPendingOrder(order) {
        if (!order || !order.id)
            return;
        const tokens = [
            order.instrument_token,
            order.symbol,
            ...(order.symbol ? SymbologyNormalizer_1.SymbologyNormalizer.normalizeToken(order.symbol) : []),
            ...(order.instrument_token ? SymbologyNormalizer_1.SymbologyNormalizer.normalizeToken(order.instrument_token) : [])
        ].filter(Boolean);
        tokens.forEach(t => {
            if (!this.pendingOrdersByToken.has(t)) {
                this.pendingOrdersByToken.set(t, new Map());
            }
            this.pendingOrdersByToken.get(t).set(order.id, order);
        });
    }
    /**
     * Remove a completed/cancelled order from the in-memory matching tree.
     */
    static unregisterPendingOrder(orderId) {
        if (!orderId)
            return;
        this.pendingOrdersByToken.forEach(orderMap => {
            orderMap.delete(orderId);
        });
    }
    /**
     * High-Speed Event-Driven Tick Handler:
     * Matches pending orders immediately upon incoming Dhan live tick arrival (<500μs).
     */
    static onMarketTick(tick) {
        if (!tick || !tick.instrumentToken || tick.ltp <= 0)
            return;
        const possibleKeys = [
            tick.instrumentToken,
            ...SymbologyNormalizer_1.SymbologyNormalizer.normalizeToken(tick.instrumentToken)
        ];
        const matchedOrders = [];
        for (const key of possibleKeys) {
            const orderMap = this.pendingOrdersByToken.get(key);
            if (orderMap && orderMap.size > 0) {
                orderMap.forEach((order) => {
                    if (!order.isEvaluating) {
                        matchedOrders.push(order);
                    }
                });
            }
        }
        if (matchedOrders.length === 0)
            return;
        const ltp = tick.ltp;
        const bidPrice = tick.bid && tick.bid > 0 ? tick.bid : ltp;
        const askPrice = tick.ask && tick.ask > 0 ? tick.ask : ltp;
        for (const order of matchedOrders) {
            const price = parseFloat(order.price || '0');
            const trigPrice = parseFloat(order.trigger_price || '0');
            let executePrice = null;
            if (order.order_type === 'MARKET') {
                executePrice = order.side === 'BUY' ? askPrice : bidPrice;
            }
            else if (order.order_type === 'LIMIT') {
                if (order.side === 'BUY' && askPrice <= price) {
                    executePrice = price;
                }
                else if (order.side === 'SELL' && bidPrice >= price) {
                    executePrice = price;
                }
            }
            else if (order.order_type === 'SL' || order.order_type === 'SL_M') {
                if (order.side === 'BUY' && askPrice >= trigPrice) {
                    executePrice = order.order_type === 'SL_M' ? askPrice : price;
                }
                else if (order.side === 'SELL' && bidPrice <= trigPrice) {
                    executePrice = order.order_type === 'SL_M' ? bidPrice : price;
                }
            }
            if (executePrice && executePrice > 0) {
                order.isEvaluating = true;
                this.unregisterPendingOrder(order.id);
                const isBsModel = tick?.bidQty === 500 && tick?.askQty === 500;
                const freshnessTag = (Date.now() - (tick.timestamp || Date.now()) <= 15000)
                    ? 'live'
                    : (isBsModel ? 'synthetic_skew' : 'cached_stale');
                const fillLogic = order.order_type === 'MARKET'
                    ? (order.side === 'BUY' ? 'MARKET_ASK' : 'MARKET_BID')
                    : (order.order_type === 'LIMIT' ? 'LIMIT_MATCH' : 'STOP_LOSS');
                const provenance = {
                    tickSource: isBsModel ? 'BLACK_SCHOLES_SYNTHETIC' : 'LIVE_FEED',
                    tickTimestamp: tick.timestamp || Date.now(),
                    tickLtp: tick.ltp,
                    tickBid: bidPrice,
                    tickAsk: askPrice,
                    freshnessTag,
                    fillLogic
                };
                // Execute immediately in asynchronous microtask
                setImmediate(async () => {
                    try {
                        const claimed = await (0, schema_1.queryOne)(`UPDATE orders SET status = 'EXECUTING', updated_at = NOW() 
               WHERE id = $1 AND (status IN ('ACCEPTED', 'PENDING') OR (status = 'EXECUTING' AND updated_at < NOW() - INTERVAL '3 seconds')) 
               RETURNING id`, [order.id]);
                        if (claimed) {
                            await this.executeOrder(order, executePrice, provenance);
                        }
                    }
                    catch (err) {
                        order.isEvaluating = false;
                        this.registerPendingOrder(order);
                    }
                });
            }
        }
    }
    static async processPendingOrders() {
        try {
            const pendingOrders = await (0, schema_1.query)(`SELECT * FROM orders 
         WHERE status IN ('ACCEPTED', 'PENDING') 
            OR (status = 'EXECUTING' AND updated_at < NOW() - INTERVAL '3 seconds') 
         ORDER BY created_at ASC LIMIT 50`);
            if (pendingOrders.length === 0)
                return;
            // Sync active DB orders into in-memory matching index
            for (const order of pendingOrders) {
                this.registerPendingOrder(order);
                const engine = MarketDataEngine_1.MarketDataEngine.getInstance();
                let tick = undefined;
                const symbolAliases = [
                    ...(order.symbol ? SymbologyNormalizer_1.SymbologyNormalizer.normalizeToken(order.symbol) : []),
                    ...(order.instrument_token ? SymbologyNormalizer_1.SymbologyNormalizer.normalizeToken(order.instrument_token) : [])
                ];
                for (const alias of symbolAliases) {
                    tick = engine.getCachedTick(alias);
                    if (tick && tick.ltp > 0)
                        break;
                }
                if (!tick && (order.instrument_token || order.symbol)) {
                    engine.subscribe([order.instrument_token || order.symbol]);
                    continue;
                }
                const STALENESS_THRESHOLD_MS = 30000;
                const isStale = tick ? (Date.now() - tick.timestamp > STALENESS_THRESHOLD_MS) : true;
                if (!tick || isStale)
                    continue;
                const price = parseFloat(order.price || '0');
                const trigPrice = parseFloat(order.trigger_price || '0');
                const ltp = tick.ltp;
                const bidPrice = tick.bid && tick.bid > 0 ? tick.bid : ltp;
                const askPrice = tick.ask && tick.ask > 0 ? tick.ask : ltp;
                let executePrice = null;
                if (order.order_type === 'MARKET') {
                    executePrice = order.side === 'BUY' ? askPrice : bidPrice;
                }
                else if (order.order_type === 'LIMIT') {
                    if (order.side === 'BUY' && askPrice <= price)
                        executePrice = price;
                    if (order.side === 'SELL' && bidPrice >= price)
                        executePrice = price;
                }
                else if (order.order_type === 'SL' || order.order_type === 'SL_M') {
                    if (order.side === 'BUY' && askPrice >= trigPrice)
                        executePrice = order.order_type === 'SL_M' ? askPrice : price;
                    if (order.side === 'SELL' && bidPrice <= trigPrice)
                        executePrice = order.order_type === 'SL_M' ? bidPrice : price;
                }
                if (executePrice && executePrice > 0) {
                    let claimed = null;
                    try {
                        claimed = await (0, schema_1.queryOne)(`UPDATE orders SET status = 'EXECUTING', updated_at = NOW() 
               WHERE id = $1 AND (status IN ('ACCEPTED', 'PENDING') OR (status = 'EXECUTING' AND updated_at < NOW() - INTERVAL '3 seconds')) 
               RETURNING id`, [order.id]);
                    }
                    catch (err) {
                        if (process.env.DEBUG_ORDER_ENGINE === 'true') {
                            console.warn(`[ExecutionEngine] Order claim warning for ${order.id}:`, err.message);
                        }
                    }
                    if (!claimed)
                        continue;
                    this.unregisterPendingOrder(order.id);
                    const isBsModel = tick?.bidQty === 500 && tick?.askQty === 500;
                    const freshnessTag = (Date.now() - (tick.timestamp || Date.now()) <= 15000)
                        ? 'live'
                        : (isBsModel ? 'synthetic_skew' : 'cached_stale');
                    const fillLogic = order.order_type === 'MARKET'
                        ? (order.side === 'BUY' ? 'MARKET_ASK' : 'MARKET_BID')
                        : (order.order_type === 'LIMIT' ? 'LIMIT_MATCH' : 'STOP_LOSS');
                    const provenance = {
                        tickSource: isBsModel ? 'BLACK_SCHOLES_SYNTHETIC' : 'LIVE_FEED',
                        tickTimestamp: tick.timestamp || Date.now(),
                        tickLtp: tick.ltp,
                        tickBid: bidPrice,
                        tickAsk: askPrice,
                        freshnessTag,
                        fillLogic
                    };
                    try {
                        await this.executeOrder(order, executePrice, provenance);
                    }
                    catch (err) {
                        if (process.env.DEBUG_ORDER_ENGINE === 'true') {
                            console.error(`[ExecutionEngine] Failed to execute order ${order.order_id}:`, err.message);
                        }
                        await (0, schema_1.execute)(`UPDATE orders SET status = 'ACCEPTED', updated_at = NOW() WHERE id = $1`, [order.id]).catch(() => { });
                    }
                }
            }
        }
        catch (err) {
            if (process.env.DEBUG_ORDER_ENGINE === 'true') {
                console.warn('[ExecutionEngine] Transient error processing pending orders:', err.message);
            }
        }
        // Evaluate Position-Level Stop Loss and Trailing Stop Loss
        await this.processPositionTrailingStopLosses();
    }
    /**
     * Evaluates active positions with Stop-Loss or Trailing Stop-Loss rules.
     * Dynamically trails stop_loss_price as LTP moves favorably, and triggers
     * market square-off when the SL threshold is breached.
     */
    static async processPositionTrailingStopLosses() {
        try {
            const positionsWithSl = await (0, schema_1.query)(`SELECT p.*, u.username 
         FROM positions p
         JOIN users u ON u.id = p.user_id
         WHERE p.stop_loss_price IS NOT NULL 
           AND p.net_qty != 0`);
            if (positionsWithSl.length === 0)
                return;
            const engine = MarketDataEngine_1.MarketDataEngine.getInstance();
            for (const pos of positionsWithSl) {
                const netQty = parseInt(pos.net_qty, 10);
                if (netQty === 0)
                    continue;
                let tick = undefined;
                const aliases = [
                    pos.symbol,
                    ...SymbologyNormalizer_1.SymbologyNormalizer.normalizeToken(pos.symbol)
                ];
                for (const alias of aliases) {
                    tick = engine.getCachedTick(alias);
                    if (tick && tick.ltp > 0)
                        break;
                }
                if (!tick || tick.ltp <= 0) {
                    engine.subscribe([pos.symbol]);
                    continue;
                }
                const ltp = tick.ltp;
                const currentSl = parseFloat(pos.stop_loss_price);
                const step = parseFloat(pos.trailing_sl_step || '0');
                const jump = parseFloat(pos.trailing_sl_jump || '0');
                if (netQty > 0) {
                    // LONG POSITION
                    const baseRef = parseFloat(pos.highest_ltp_since_sl || pos.average_price || String(ltp));
                    if (step > 0 && jump > 0 && ltp >= baseRef + jump) {
                        const jumpsCount = Math.floor((ltp - baseRef) / jump);
                        const newSl = currentSl + (jumpsCount * step);
                        const newHighestRef = baseRef + (jumpsCount * jump);
                        await (0, schema_1.execute)(`UPDATE positions 
               SET stop_loss_price = $1, highest_ltp_since_sl = $2, updated_at = NOW() 
               WHERE id = $3`, [newSl, newHighestRef, pos.id]);
                        console.log(`[ExecutionEngine] 📈 Trailed Stop-Loss for Long ${pos.symbol} (User: ${pos.username}): New SL ₹${newSl.toFixed(2)} (LTP: ₹${ltp.toFixed(2)})`);
                    }
                    // Trigger SL if LTP drops below current SL price
                    if (ltp <= currentSl) {
                        console.log(`[ExecutionEngine] 🛑 Triggering Trailing Stop-Loss for Long ${pos.symbol} (User: ${pos.username}): LTP ₹${ltp.toFixed(2)} <= SL ₹${currentSl.toFixed(2)}`);
                        const { executeSquareOff } = require('./RmsSquareOffAction');
                        await executeSquareOff(pos, {
                            mode: 'LIVE',
                            reason: `Trailing Stop-Loss Triggered (LTP: ₹${ltp.toFixed(2)} <= SL: ₹${currentSl.toFixed(2)})`,
                            eventType: 'TRAILING_STOP_LOSS'
                        });
                    }
                }
                else {
                    // SHORT POSITION
                    const baseRef = parseFloat(pos.lowest_ltp_since_sl || pos.average_price || String(ltp));
                    if (step > 0 && jump > 0 && ltp <= baseRef - jump) {
                        const jumpsCount = Math.floor((baseRef - ltp) / jump);
                        const newSl = currentSl - (jumpsCount * step);
                        const newLowestRef = baseRef - (jumpsCount * jump);
                        await (0, schema_1.execute)(`UPDATE positions 
               SET stop_loss_price = $1, lowest_ltp_since_sl = $2, updated_at = NOW() 
               WHERE id = $3`, [newSl, newLowestRef, pos.id]);
                        console.log(`[ExecutionEngine] 📉 Trailed Stop-Loss for Short ${pos.symbol} (User: ${pos.username}): New SL ₹${newSl.toFixed(2)} (LTP: ₹${ltp.toFixed(2)})`);
                    }
                    // Trigger SL if LTP rises above current SL price
                    if (ltp >= currentSl) {
                        console.log(`[ExecutionEngine] 🛑 Triggering Trailing Stop-Loss for Short ${pos.symbol} (User: ${pos.username}): LTP ₹${ltp.toFixed(2)} >= SL ₹${currentSl.toFixed(2)}`);
                        const { executeSquareOff } = require('./RmsSquareOffAction');
                        await executeSquareOff(pos, {
                            mode: 'LIVE',
                            reason: `Trailing Stop-Loss Triggered (LTP: ₹${ltp.toFixed(2)} >= SL: ₹${currentSl.toFixed(2)})`,
                            eventType: 'TRAILING_STOP_LOSS'
                        });
                    }
                }
            }
        }
        catch (err) {
            if (process.env.DEBUG_ORDER_ENGINE === 'true') {
                console.error('[ExecutionEngine] Position Trailing SL error:', err.message);
            }
        }
    }
    static async executeOrder(order, price, provenance) {
        // Cheap fast-path check outside the transaction
        const existingExec = await (0, schema_1.queryOne)('SELECT id FROM executions WHERE order_id = $1', [order.id]);
        if (existingExec) {
            // Ensure order status is finalized to FILLED so it is never left stuck in EXECUTING
            await (0, schema_1.execute)(`UPDATE orders SET status = 'FILLED', filled_quantity = quantity, average_price = COALESCE(average_price, $1), updated_at = NOW() WHERE id = $2 AND status != 'FILLED'`, [price, order.id]).catch(() => { });
            return;
        }
        const tradeId = 'trd_' + (0, crypto_1.generateUUID)();
        const excId = 'exc_' + (0, crypto_1.generateUUID)();
        const qty = parseInt(order.quantity, 10);
        const tradeVal = price * qty;
        // Zero Charges & Zero Tax Policy
        const brokerage = 0.00;
        const stt = 0.00;
        const exchangeCharges = 0.00;
        const gst = 0.00;
        const stampDuty = 0.00;
        const totalCharges = 0.00;
        const exitReason = order.source === 'RMS'
            ? 'RMS_AUTO_SQUARE_OFF'
            : (order.order_type === 'LIMIT'
                ? 'TARGET_LIMIT'
                : (order.order_type === 'MARKET' ? 'MARKET_SQUARE_OFF' : 'STOP_LOSS'));
        const posResult = await (0, schema_1.withTransaction)(async (client) => {
            // B1 fix: the real idempotency guard. The `existingExec` check above runs outside any
            // lock, so two near-simultaneous executeOrder calls for the same order (e.g. an admin
            // force-execute racing the engine's own periodic pending-order sweep) could both pass it
            // before either has inserted an execution row, and both would then fill the same order
            // twice — doubling the resulting position and cash/P&L impact. Making the order's FILLED
            // transition itself the atomic guard (first statement, in this transaction) closes that:
            // only one caller's UPDATE can match status IN (...) and return a row.
            const statusUpd = await client.query(`UPDATE orders SET status = 'FILLED', filled_quantity = quantity, average_price = $1, updated_at = NOW()
         WHERE id = $2 AND status IN ('ACCEPTED', 'PENDING', 'EXECUTING')
         RETURNING id`, [price, order.id]);
            if (statusUpd.rows.length === 0) {
                return null;
            }
            // 1. Record execution fill with Immutable Provenance
            await client.query(`INSERT INTO executions (
          id, order_id, user_id, trade_id, symbol, exchange, side, quantity, price, 
          brokerage, stt, gst, exchange_charges, total_charges,
          tick_source, tick_timestamp, tick_ltp, tick_bid, tick_ask, freshness_tag, fill_logic
        )
        VALUES (
          $1, $2, $3, $4, $5, $6, $7, $8, $9, 
          $10, $11, $12, $13, $14,
          $15, $16, $17, $18, $19, $20, $21
        )`, [
                excId, order.id, order.user_id, tradeId,
                order.symbol, order.exchange || 'NSE', order.side,
                qty, price, brokerage, stt, gst, exchangeCharges, totalCharges,
                provenance?.tickSource || 'LIVE_FEED',
                provenance?.tickTimestamp || Date.now(),
                provenance?.tickLtp || price,
                provenance?.tickBid || price,
                provenance?.tickAsk || price,
                provenance?.freshnessTag || 'live',
                provenance?.fillLogic || 'MARKET'
            ]);
            // 2. (order status already transitioned to FILLED above, atomically)
            // 3. Record order event audit trail
            await client.query(`INSERT INTO order_events (id, order_id, from_status, to_status, reason, actor, metadata)
         VALUES ($1, $2, 'ACCEPTED', 'FILLED', $3, 'EXECUTION_ENGINE', $4)`, [
                'evt_' + (0, crypto_1.generateUUID)(),
                order.id,
                `Execution fill @ ₹${price.toFixed(2)} (${exitReason}) [Freshness: ${provenance?.freshnessTag || 'live'}]`,
                JSON.stringify({
                    fillPrice: price,
                    quantity: qty,
                    exitReason,
                    tradeId,
                    excId,
                    provenance: provenance || {}
                })
            ]);
            // 4. Update Position & record permanent per-trade P&L in closed_trades
            const res = await PortfolioService_1.PortfolioService.recordExecutionInTransaction(client, order.user_id, order.symbol, order.exchange || 'NSE', order.product_type || 'MIS', order.side, qty, price, exitReason, order.id, excId);
            // 5. Settle Virtual Money Ledger atomically (used_margin is recomputed
            // inside settleTradeExecutionInTransaction from the now-updated
            // position + any other pending orders — no separate blockedMargin calc)
            await VirtualWalletLedger_1.VirtualWalletLedger.settleTradeExecutionInTransaction(client, order.user_id, order.side, tradeVal, res.releasedPositionCapital, res.realizedPnlDelta, order.order_id);
            // 5b. War Room 1,000 Users Milestone: Record First Trade Activation
            try {
                const { WarRoomService } = await Promise.resolve().then(() => __importStar(require('../services/WarRoomService')));
                void WarRoomService.getInstance().recordActivation(order.user_id, order.id, 'FIRST_ORDER_FILLED').catch(() => { });
            }
            catch (_) { }
            // 6. Record in-app notification for the user
            await client.query(`INSERT INTO notifications (id, user_id, type, title, body, metadata)
         VALUES ($1, $2, 'ORDER_FILLED', $3, $4, $5)`, [
                'notif_' + (0, crypto_1.generateUUID)(),
                order.user_id,
                `Order Executed: ${order.side} ${qty} ${order.symbol}`,
                `Your ${order.side} order for ${qty} ${order.symbol} was filled at ₹${price.toFixed(2)}.`,
                JSON.stringify({ orderId: order.order_id, symbol: order.symbol, side: order.side, qty, price, tradeId })
            ]).catch(() => { });
            try {
                const { deliverToUser } = await Promise.resolve().then(() => __importStar(require('../websocket/server')));
                deliverToUser(order.user_id, {
                    type: 'NOTIFICATION',
                    data: {
                        type: 'ORDER_FILLED',
                        title: `Order Executed: ${order.side} ${qty} ${order.symbol}`,
                        body: `Your ${order.side} order for ${qty} ${order.symbol} was filled at ₹${price.toFixed(2)}.`,
                        metadata: { orderId: order.order_id, symbol: order.symbol, side: order.side, qty, price, tradeId }
                    }
                });
            }
            catch (_) { }
            return res;
        });
        if (posResult === null) {
            console.log(`[ExecutionEngine] Skipped: order ${order.order_id} was already filled/cancelled/rejected by another request.`);
            return;
        }
        console.log(`[ExecutionEngine] EXECUTION SUCCESS: Order ${order.order_id} filled @ ₹${price.toFixed(2)} (Qty: ${qty}, ExitReason: ${exitReason}, Realized P&L: ₹${(posResult?.realizedPnlDelta || 0).toFixed(2)})`);
        (0, adminEventBus_1.emitAdminOrderEvent)(order.user_id, 'ORDER_UPDATED', { ...order, status: 'FILLED', filled_quantity: qty, average_price: price });
        (0, adminEventBus_1.emitAdminTradeEvent)(order.user_id, {
            tradeId, symbol: order.symbol, side: order.side, quantity: qty, price,
            exitReason, realizedPnl: posResult?.realizedPnlDelta || 0,
        });
        // Thin signals only — Customer360/OrderMonitor/FundsDashboard already refetch the full
        // positions/wallet state via REST on receipt, matching the pattern this file's admin
        // event consumers already use for USER_STATUS_UPDATED etc. Avoids extra DB reads here,
        // on the 500ms hot-path matching loop, just to build a full payload nothing needs.
        (0, adminEventBus_1.emitAdminPositionUpdate)(order.user_id, []);
        (0, adminEventBus_1.emitAdminFundsUpdate)(order.user_id, null);
        // 7. Dispatch asynchronous trade confirmation email to client
        setImmediate(async () => {
            try {
                const { queryOne } = await Promise.resolve().then(() => __importStar(require('../db/schema')));
                const user = await queryOne('SELECT id, email, full_name FROM users WHERE id = $1', [order.user_id]);
                if (user && user.email) {
                    const { EmailService } = await Promise.resolve().then(() => __importStar(require('../services/EmailService')));
                    await EmailService.getInstance().sendOrderExecutionEmail(user, {
                        orderId: order.order_id,
                        symbol: order.symbol,
                        side: order.side,
                        quantity: qty,
                        price,
                        orderType: order.order_type || 'MARKET',
                        timestamp: Date.now(),
                    });
                }
            }
            catch (err) {
                console.warn('[ExecutionEngine] Failed to trigger trade confirmation email:', err.message);
            }
        });
    }
}
exports.ExecutionEngine = ExecutionEngine;
