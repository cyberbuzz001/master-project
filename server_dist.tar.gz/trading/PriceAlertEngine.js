"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.priceAlertEngine = exports.PriceAlertEngine = void 0;
const schema_1 = require("../db/schema");
const crypto_1 = require("../utils/crypto");
class PriceAlertEngine {
    static instance;
    activeTokens = new Set();
    lastPrices = new Map();
    static getInstance() {
        if (!PriceAlertEngine.instance) {
            PriceAlertEngine.instance = new PriceAlertEngine();
        }
        return PriceAlertEngine.instance;
    }
    async initialize() {
        try {
            const rows = await (0, schema_1.query)(`SELECT DISTINCT instrument_token, symbol FROM alerts WHERE status = 'ACTIVE'`);
            this.activeTokens.clear();
            rows.forEach(r => {
                if (r.instrument_token)
                    this.activeTokens.add(r.instrument_token);
                if (r.symbol)
                    this.activeTokens.add(r.symbol);
            });
            console.log(`[PriceAlertEngine] Initialized with ${this.activeTokens.size} active alert tokens.`);
        }
        catch (err) {
            console.warn('[PriceAlertEngine] Initialization warning:', err.message);
        }
    }
    async createAlert(dto) {
        if (!dto.userId || !dto.symbol || !dto.targetValue || dto.targetValue <= 0) {
            return { success: false, error: 'Invalid alert parameters: symbol and targetValue > 0 required' };
        }
        const id = 'alt_' + (0, crypto_1.generateUUID)();
        const condition = dto.conditionType || 'GREATER_THAN';
        try {
            await (0, schema_1.execute)(`INSERT INTO alerts (id, user_id, instrument_token, symbol, condition_type, target_value, status, message)
         VALUES ($1, $2, $3, $4, $5, $6, 'ACTIVE', $7)`, [
                id, dto.userId, dto.instrumentToken || dto.symbol, dto.symbol,
                condition, dto.targetValue, dto.message || `${dto.symbol} target price ₹${dto.targetValue}`
            ]);
            this.activeTokens.add(dto.instrumentToken || dto.symbol);
            this.activeTokens.add(dto.symbol);
            return { success: true, alertId: id };
        }
        catch (err) {
            return { success: false, error: err.message || 'Failed to create price alert' };
        }
    }
    async getUserAlerts(userId, status) {
        if (status) {
            return await (0, schema_1.query)(`SELECT * FROM alerts WHERE user_id = $1 AND status = $2 ORDER BY created_at DESC`, [userId, status.toUpperCase()]);
        }
        return await (0, schema_1.query)(`SELECT * FROM alerts WHERE user_id = $1 ORDER BY created_at DESC`, [userId]);
    }
    async deleteAlert(userId, alertId) {
        const res = await (0, schema_1.execute)(`UPDATE alerts SET status = 'CANCELLED' WHERE id = $1 AND user_id = $2`, [alertId, userId]);
        if (res === 0) {
            return { success: false, error: 'Alert not found' };
        }
        void this.initialize();
        return { success: true };
    }
    /**
     * Evaluates incoming tick against active alerts.
     * Runs in O(1) via activeTokens pre-filter to eliminate database queries when no alerts exist.
     */
    async onMarketTick(tick) {
        if (!tick || tick.ltp <= 0)
            return;
        if (!this.activeTokens.has(tick.instrumentToken) && !this.activeTokens.has(tick.symbol)) {
            return;
        }
        const prevPrice = this.lastPrices.get(tick.instrumentToken) ?? tick.ltp;
        this.lastPrices.set(tick.instrumentToken, tick.ltp);
        try {
            const activeAlerts = await (0, schema_1.query)(`SELECT * FROM alerts 
         WHERE (instrument_token = $1 OR symbol = $2) AND status = 'ACTIVE'`, [tick.instrumentToken, tick.symbol]);
            if (!activeAlerts.length) {
                this.activeTokens.delete(tick.instrumentToken);
                this.activeTokens.delete(tick.symbol);
                return;
            }
            for (const alert of activeAlerts) {
                const target = parseFloat(alert.target_value);
                let triggered = false;
                switch (alert.condition_type) {
                    case 'GREATER_THAN':
                        triggered = tick.ltp >= target;
                        break;
                    case 'LESS_THAN':
                        triggered = tick.ltp <= target;
                        break;
                    case 'CROSSES_ABOVE':
                        triggered = prevPrice < target && tick.ltp >= target;
                        break;
                    case 'CROSSES_BELOW':
                        triggered = prevPrice > target && tick.ltp <= target;
                        break;
                }
                if (triggered) {
                    const updated = await (0, schema_1.execute)(`UPDATE alerts SET status = 'TRIGGERED', triggered_at = NOW() WHERE id = $1 AND status = 'ACTIVE'`, [alert.id]);
                    if (updated > 0) {
                        console.log(`[PriceAlertEngine] Alert triggered: ${alert.symbol} hit ₹${tick.ltp}`);
                        // Insert in-app notification for the user
                        await (0, schema_1.execute)(`INSERT INTO notifications (id, user_id, type, title, body, metadata)
               VALUES ($1, $2, 'ALERT_TRIGGERED', $3, $4, $5)`, [
                            'notif_' + (0, crypto_1.generateUUID)(),
                            alert.user_id,
                            `Price Alert: ${alert.symbol}`,
                            `${alert.symbol} reached target price of ₹${tick.ltp} (Condition: ${alert.condition_type} ₹${target})`,
                            JSON.stringify({ symbol: alert.symbol, ltp: tick.ltp, targetValue: target, alertId: alert.id })
                        ]);
                        try {
                            const { deliverToUser } = await Promise.resolve().then(() => __importStar(require('../websocket/server')));
                            deliverToUser(alert.user_id, {
                                type: 'NOTIFICATION',
                                data: {
                                    type: 'ALERT_TRIGGERED',
                                    title: `Price Alert: ${alert.symbol}`,
                                    body: `${alert.symbol} reached target price of ₹${tick.ltp}`,
                                    metadata: { symbol: alert.symbol, ltp: tick.ltp, targetValue: target, alertId: alert.id }
                                }
                            });
                        }
                        catch (_) { }
                    }
                }
            }
        }
        catch (err) {
            console.error('[PriceAlertEngine] Error in onMarketTick:', err.message);
        }
    }
}
exports.PriceAlertEngine = PriceAlertEngine;
exports.priceAlertEngine = PriceAlertEngine.getInstance();
