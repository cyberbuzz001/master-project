"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RmsAutoSquareOffEngine = void 0;
/**
 * RmsAutoSquareOffEngine.ts
 * Scheduled MIS auto square-off — the backend behind the client UI's
 * "15:15 IST auto square-off" banner, which previously had nothing wired up
 * to it. Runs SIMULATION-first (system_settings.RMS_MODE) before any real
 * order is ever submitted; see the Phase 1 section of the RMS overhaul plan
 * for the full design rationale.
 */
const schema_1 = require("../db/schema");
const redis_1 = require("../db/redis");
const MarketDataEngine_1 = require("../marketData/MarketDataEngine");
const RmsSquareOffAction_1 = require("./RmsSquareOffAction");
const RUN_LOCK_KEY = 'lock:rms:auto-square-off-run';
const RUN_LOCK_TTL_SECONDS = 300;
const EVENT_TYPE = 'RMS_AUTO_SQUARE_OFF';
const REASON = 'MIS_CUTOFF';
async function getConfig() {
    const rows = await (0, schema_1.query)(`SELECT key, value FROM system_settings WHERE key IN ('RMS_MODE','MIS_AUTO_SQUARE_OFF_ENABLED','MIS_AUTO_SQUARE_OFF_TIME','MIS_AUTO_SQUARE_OFF_PRODUCT_TYPES')`);
    const map = new Map(rows.map((r) => [r.key, r.value]));
    const mode = map.get('RMS_MODE') === 'LIVE' ? 'LIVE' : 'SIMULATION';
    const enabled = (map.get('MIS_AUTO_SQUARE_OFF_ENABLED') || 'true') === 'true';
    const time = map.get('MIS_AUTO_SQUARE_OFF_TIME') || '15:15';
    const productTypes = (map.get('MIS_AUTO_SQUARE_OFF_PRODUCT_TYPES') || 'MIS')
        .split(',').map((s) => s.trim()).filter(Boolean);
    return { enabled, mode, time, productTypes };
}
class RmsAutoSquareOffEngine {
    static async run(targetExchange) {
        const ranAt = new Date().toISOString();
        const { enabled, mode, productTypes } = await getConfig();
        const segment = targetExchange === 'COMMODITY' ? 'COMMODITY' : 'EQUITY';
        const marketOpen = MarketDataEngine_1.MarketDataEngine.isMarketHours(segment);
        if (!enabled) {
            console.log(`[RmsAutoSquareOffEngine] Disabled via MIS_AUTO_SQUARE_OFF_ENABLED — skipping run for ${targetExchange || 'ALL'}.`);
            return { ranAt, mode, enabled, marketOpen, lockAcquired: false, processed: 0, skipped: 0, failed: 0, results: [] };
        }
        const lockKey = targetExchange ? `${RUN_LOCK_KEY}:${targetExchange}` : RUN_LOCK_KEY;
        const lockAcquired = await redis_1.redis.acquireLock(lockKey, RUN_LOCK_TTL_SECONDS, 'rms-engine');
        if (!lockAcquired) {
            console.log(`[RmsAutoSquareOffEngine] Another run already holds the lock (${lockKey}) — skipping.`);
            return { ranAt, mode, enabled, marketOpen, lockAcquired: false, processed: 0, skipped: 0, failed: 0, results: [] };
        }
        const results = [];
        let processed = 0, skipped = 0, failed = 0;
        try {
            let queryStr = `SELECT * FROM positions WHERE product_type = ANY($1::text[]) AND net_qty != 0`;
            const queryParams = [productTypes];
            if (targetExchange === 'EQUITY') {
                queryStr += ` AND (exchange IS NULL OR exchange != 'MCX')`;
            }
            else if (targetExchange === 'COMMODITY') {
                queryStr += ` AND exchange = 'MCX'`;
            }
            const positions = await (0, schema_1.query)(queryStr, queryParams);
            console.log(`[RmsAutoSquareOffEngine] Target=${targetExchange || 'ALL'}, Mode=${mode}. Found ${positions.length} open position(s) across [${productTypes.join(',')}].`);
            for (const pos of positions) {
                const netQty = parseInt(pos.net_qty, 10);
                if (netQty === 0)
                    continue;
                try {
                    const result = await (0, RmsSquareOffAction_1.executeSquareOff)(pos, { mode, reason: REASON, eventType: EVENT_TYPE });
                    if (result.status === 'SIMULATED' || result.status === 'SUBMITTED')
                        processed++;
                    else if (result.status === 'SKIPPED')
                        skipped++;
                    else
                        failed++;
                    results.push({
                        userId: pos.user_id, symbol: pos.symbol, exchange: pos.exchange, productType: pos.product_type,
                        netQty: result.netQty, exitSide: result.exitSide, exitQty: result.exitQty,
                        status: result.status, orderId: result.orderId, error: result.error,
                    });
                }
                catch (err) {
                    failed++;
                    console.error(`[RmsAutoSquareOffEngine] Error processing position ${pos.id}:`, err.message);
                    results.push({
                        userId: pos.user_id, symbol: pos.symbol, exchange: pos.exchange, productType: pos.product_type,
                        netQty, exitSide: netQty > 0 ? 'SELL' : 'BUY', exitQty: Math.abs(netQty),
                        status: 'FAILED', error: err.message,
                    });
                }
            }
        }
        finally {
            await redis_1.redis.releaseLock(lockKey).catch(() => { });
        }
        console.log(`[RmsAutoSquareOffEngine] Run complete. mode=${mode} processed=${processed} skipped=${skipped} failed=${failed}`);
        return { ranAt, mode, enabled, marketOpen, lockAcquired: true, processed, skipped, failed, results };
    }
}
exports.RmsAutoSquareOffEngine = RmsAutoSquareOffEngine;
