"use strict";
/**
 * Spotware cTrader Open API v2 Protocol Types & Constants
 * Reference: https://help.ctrader.com/open-api/
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProtoOAOrderStatus = exports.ProtoOAExecutionType = exports.ProtoOAOrderType = exports.ProtoOATradeSide = exports.ProtoPayloadType = void 0;
var ProtoPayloadType;
(function (ProtoPayloadType) {
    ProtoPayloadType[ProtoPayloadType["PROTO_MESSAGE"] = 5] = "PROTO_MESSAGE";
    ProtoPayloadType[ProtoPayloadType["ERROR_RES"] = 50] = "ERROR_RES";
    ProtoPayloadType[ProtoPayloadType["HEARTBEAT_EVENT"] = 51] = "HEARTBEAT_EVENT";
    ProtoPayloadType[ProtoPayloadType["PROTO_OA_APPLICATION_AUTH_REQ"] = 2100] = "PROTO_OA_APPLICATION_AUTH_REQ";
    ProtoPayloadType[ProtoPayloadType["PROTO_OA_APPLICATION_AUTH_RES"] = 2101] = "PROTO_OA_APPLICATION_AUTH_RES";
    ProtoPayloadType[ProtoPayloadType["PROTO_OA_ACCOUNT_AUTH_REQ"] = 2102] = "PROTO_OA_ACCOUNT_AUTH_REQ";
    ProtoPayloadType[ProtoPayloadType["PROTO_OA_ACCOUNT_AUTH_RES"] = 2103] = "PROTO_OA_ACCOUNT_AUTH_RES";
    ProtoPayloadType[ProtoPayloadType["PROTO_OA_VERSION_REQ"] = 2104] = "PROTO_OA_VERSION_REQ";
    ProtoPayloadType[ProtoPayloadType["PROTO_OA_VERSION_RES"] = 2105] = "PROTO_OA_VERSION_RES";
    ProtoPayloadType[ProtoPayloadType["PROTO_OA_NEW_ORDER_REQ"] = 2106] = "PROTO_OA_NEW_ORDER_REQ";
    ProtoPayloadType[ProtoPayloadType["PROTO_OA_CANCEL_ORDER_REQ"] = 2108] = "PROTO_OA_CANCEL_ORDER_REQ";
    ProtoPayloadType[ProtoPayloadType["PROTO_OA_CLOSE_POSITION_REQ"] = 2110] = "PROTO_OA_CLOSE_POSITION_REQ";
    ProtoPayloadType[ProtoPayloadType["PROTO_OA_SYMBOLS_LIST_REQ"] = 2114] = "PROTO_OA_SYMBOLS_LIST_REQ";
    ProtoPayloadType[ProtoPayloadType["PROTO_OA_SYMBOLS_LIST_RES"] = 2115] = "PROTO_OA_SYMBOLS_LIST_RES";
    ProtoPayloadType[ProtoPayloadType["PROTO_OA_TRADER_REQ"] = 2121] = "PROTO_OA_TRADER_REQ";
    ProtoPayloadType[ProtoPayloadType["PROTO_OA_TRADER_RES"] = 2122] = "PROTO_OA_TRADER_RES";
    ProtoPayloadType[ProtoPayloadType["PROTO_OA_RECONCILE_REQ"] = 2124] = "PROTO_OA_RECONCILE_REQ";
    ProtoPayloadType[ProtoPayloadType["PROTO_OA_RECONCILE_RES"] = 2125] = "PROTO_OA_RECONCILE_RES";
    ProtoPayloadType[ProtoPayloadType["PROTO_OA_EXECUTION_EVENT"] = 2126] = "PROTO_OA_EXECUTION_EVENT";
    ProtoPayloadType[ProtoPayloadType["PROTO_OA_ORDER_ERROR_EVENT"] = 2132] = "PROTO_OA_ORDER_ERROR_EVENT";
    ProtoPayloadType[ProtoPayloadType["PROTO_OA_ACCOUNTS_TOKEN_INVALID_EVENT"] = 2148] = "PROTO_OA_ACCOUNTS_TOKEN_INVALID_EVENT";
    ProtoPayloadType[ProtoPayloadType["PROTO_OA_GET_ACCOUNTS_BY_TOKEN_REQ"] = 2149] = "PROTO_OA_GET_ACCOUNTS_BY_TOKEN_REQ";
    ProtoPayloadType[ProtoPayloadType["PROTO_OA_GET_ACCOUNTS_BY_TOKEN_RES"] = 2150] = "PROTO_OA_GET_ACCOUNTS_BY_TOKEN_RES";
})(ProtoPayloadType || (exports.ProtoPayloadType = ProtoPayloadType = {}));
var ProtoOATradeSide;
(function (ProtoOATradeSide) {
    ProtoOATradeSide[ProtoOATradeSide["BUY"] = 1] = "BUY";
    ProtoOATradeSide[ProtoOATradeSide["SELL"] = 2] = "SELL";
})(ProtoOATradeSide || (exports.ProtoOATradeSide = ProtoOATradeSide = {}));
var ProtoOAOrderType;
(function (ProtoOAOrderType) {
    ProtoOAOrderType[ProtoOAOrderType["MARKET"] = 1] = "MARKET";
    ProtoOAOrderType[ProtoOAOrderType["LIMIT"] = 2] = "LIMIT";
    ProtoOAOrderType[ProtoOAOrderType["STOP"] = 3] = "STOP";
    ProtoOAOrderType[ProtoOAOrderType["STOP_LIMIT"] = 4] = "STOP_LIMIT";
    ProtoOAOrderType[ProtoOAOrderType["MARKET_RANGE"] = 5] = "MARKET_RANGE";
    ProtoOAOrderType[ProtoOAOrderType["STOP_LOSS_TAKE_PROFIT"] = 6] = "STOP_LOSS_TAKE_PROFIT";
})(ProtoOAOrderType || (exports.ProtoOAOrderType = ProtoOAOrderType = {}));
var ProtoOAExecutionType;
(function (ProtoOAExecutionType) {
    ProtoOAExecutionType[ProtoOAExecutionType["ORDER_ACCEPTED"] = 1] = "ORDER_ACCEPTED";
    ProtoOAExecutionType[ProtoOAExecutionType["ORDER_FILLED"] = 2] = "ORDER_FILLED";
    ProtoOAExecutionType[ProtoOAExecutionType["ORDER_CANCELLED"] = 3] = "ORDER_CANCELLED";
    ProtoOAExecutionType[ProtoOAExecutionType["ORDER_EXPIRED"] = 4] = "ORDER_EXPIRED";
    ProtoOAExecutionType[ProtoOAExecutionType["ORDER_AMENDED"] = 5] = "ORDER_AMENDED";
    ProtoOAExecutionType[ProtoOAExecutionType["ORDER_REJECTED"] = 6] = "ORDER_REJECTED";
    ProtoOAExecutionType[ProtoOAExecutionType["SWAP"] = 7] = "SWAP";
    ProtoOAExecutionType[ProtoOAExecutionType["DEPOSIT_WITHDRAW"] = 8] = "DEPOSIT_WITHDRAW";
    ProtoOAExecutionType[ProtoOAExecutionType["ORDER_PARTIALLY_FILLED"] = 9] = "ORDER_PARTIALLY_FILLED";
})(ProtoOAExecutionType || (exports.ProtoOAExecutionType = ProtoOAExecutionType = {}));
var ProtoOAOrderStatus;
(function (ProtoOAOrderStatus) {
    ProtoOAOrderStatus[ProtoOAOrderStatus["ORDER_STATUS_ACCEPTED"] = 1] = "ORDER_STATUS_ACCEPTED";
    ProtoOAOrderStatus[ProtoOAOrderStatus["ORDER_STATUS_FILLED"] = 2] = "ORDER_STATUS_FILLED";
    ProtoOAOrderStatus[ProtoOAOrderStatus["ORDER_STATUS_REJECTED"] = 3] = "ORDER_STATUS_REJECTED";
    ProtoOAOrderStatus[ProtoOAOrderStatus["ORDER_STATUS_EXPIRED"] = 4] = "ORDER_STATUS_EXPIRED";
    ProtoOAOrderStatus[ProtoOAOrderStatus["ORDER_STATUS_CANCELLED"] = 5] = "ORDER_STATUS_CANCELLED";
})(ProtoOAOrderStatus || (exports.ProtoOAOrderStatus = ProtoOAOrderStatus = {}));
