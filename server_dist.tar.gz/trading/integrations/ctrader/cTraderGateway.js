"use strict";
/**
 * Spotware cTrader Open API Gateway
 * Manages WebSocket connection, application/account authorization, order transmission,
 * heartbeat management, and real-time execution event streaming.
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CTraderGateway = void 0;
const ws_1 = __importDefault(require("ws"));
const events_1 = require("events");
const cTraderTypes_1 = require("./cTraderTypes");
const cTraderOrderMapper_1 = require("./cTraderOrderMapper");
const schema_1 = require("../../../db/schema");
const redis_1 = require("../../../db/redis");
class CTraderGateway extends events_1.EventEmitter {
    static instance = null;
    ws = null;
    config;
    isConnected = false;
    isAppAuthorized = false;
    authorizedAccounts = new Set();
    heartbeatTimer = null;
    reconnectTimer = null;
    pendingRequests = new Map();
    constructor() {
        super();
        const env = (process.env.CTRADER_ENV || 'demo').toLowerCase();
        const isLive = env === 'live';
        this.config = {
            clientId: process.env.CTRADER_CLIENT_ID || 'mock_ctrader_client_id',
            clientSecret: process.env.CTRADER_CLIENT_SECRET || 'mock_ctrader_client_secret',
            redirectUri: process.env.CTRADER_REDIRECT_URI || 'https://tradegrowx.in/api/v1/integrations/ctrader/oauth/callback',
            environment: env,
            wsHost: isLive ? 'live.ctraderapi.com' : 'demo.ctraderapi.com',
            wsPort: 5036,
            authUrl: 'https://openapi.ctrader.com/apps/auth',
            tokenUrl: 'https://openapi.ctrader.com/apps/token'
        };
    }
    static getInstance() {
        if (!CTraderGateway.instance) {
            CTraderGateway.instance = new CTraderGateway();
        }
        return CTraderGateway.instance;
    }
    getConfig() {
        return this.config;
    }
    getStatus() {
        return {
            isConnected: this.isConnected,
            isAppAuthorized: this.isAppAuthorized,
            authorizedAccounts: Array.from(this.authorizedAccounts),
            environment: this.config.environment
        };
    }
    /**
     * Initializes WebSocket connection to cTrader Open API
     */
    async initialize() {
        if (this.ws && (this.ws.readyState === ws_1.default.OPEN || this.ws.readyState === ws_1.default.CONNECTING)) {
            return;
        }
        const endpoint = `wss://${this.config.wsHost}:${this.config.wsPort}`;
        console.log(`[cTraderGateway] Connecting to Spotware Open API: ${endpoint}`);
        try {
            this.ws = new ws_1.default(endpoint, {
                handshakeTimeout: 10000
            });
            this.ws.on('open', () => this.handleOpen());
            this.ws.on('message', (data) => this.handleMessage(data));
            this.ws.on('error', (err) => this.handleError(err));
            this.ws.on('close', (code, reason) => this.handleClose(code, reason));
        }
        catch (err) {
            console.error(`[cTraderGateway] Failed to instantiate WebSocket:`, err.message);
            this.scheduleReconnect();
        }
    }
    handleOpen() {
        console.log(`[cTraderGateway] ✅ WebSocket Connected to cTrader Open API (${this.config.environment})`);
        this.isConnected = true;
        this.startHeartbeat();
        // Authenticate application
        this.authenticateApplication().catch(err => {
            console.warn(`[cTraderGateway] Application authentication error:`, err.message);
        });
    }
    async authenticateApplication() {
        const payload = {
            clientId: this.config.clientId,
            clientSecret: this.config.clientSecret
        };
        console.log(`[cTraderGateway] Sending Application Auth for clientId: ${this.config.clientId.slice(0, 8)}...`);
        const res = await this.sendRequest(cTraderTypes_1.ProtoPayloadType.PROTO_OA_APPLICATION_AUTH_REQ, payload);
        this.isAppAuthorized = true;
        console.log(`[cTraderGateway] ✅ Application Authenticated Successfully with Spotware.`);
        this.emit('app_authorized', res);
        // Re-authorize known active accounts from DB
        await this.restoreActiveAccounts();
    }
    /**
     * Restores active accounts from the database and sends ProtoOAAccountAuthReq
     */
    async restoreActiveAccounts() {
        try {
            const accounts = await (0, schema_1.query)(`SELECT ctid_trader_account_id, access_token 
         FROM ctrader_accounts 
         WHERE account_status = 'ACTIVE' 
         AND token_expires_at > NOW()`);
            for (const acc of accounts) {
                const ctid = parseInt(acc.ctid_trader_account_id, 10);
                if (ctid && acc.access_token) {
                    await this.authorizeAccount(ctid, acc.access_token).catch(() => { });
                }
            }
        }
        catch (err) {
            console.warn(`[cTraderGateway] Could not restore accounts from DB:`, err.message);
        }
    }
    /**
     * Authorizes an individual trader account using their OAuth access token
     */
    async authorizeAccount(ctidTraderAccountId, accessToken) {
        if (!this.isConnected || !this.isAppAuthorized) {
            throw new Error('cTrader Gateway is not connected or app is not authorized yet');
        }
        const payload = {
            ctidTraderAccountId,
            accessToken
        };
        try {
            await this.sendRequest(cTraderTypes_1.ProtoPayloadType.PROTO_OA_ACCOUNT_AUTH_REQ, payload);
            this.authorizedAccounts.add(ctidTraderAccountId);
            console.log(`[cTraderGateway] ✅ Account ${ctidTraderAccountId} authorized.`);
            return true;
        }
        catch (err) {
            console.error(`[cTraderGateway] Failed to authorize account ${ctidTraderAccountId}:`, err.message);
            throw err;
        }
    }
    /**
     * Submits a new order to cTrader
     */
    async submitOrder(req) {
        if (!this.authorizedAccounts.has(req.ctidTraderAccountId)) {
            // Attempt auto-auth from DB if not currently authorized
            const account = await (0, schema_1.query)(`SELECT access_token FROM ctrader_accounts WHERE ctid_trader_account_id = $1 LIMIT 1`, [req.ctidTraderAccountId]);
            if (account.length > 0 && account[0].access_token) {
                await this.authorizeAccount(req.ctidTraderAccountId, account[0].access_token);
            }
            else {
                throw new Error(`cTrader Account ${req.ctidTraderAccountId} is not authorized`);
            }
        }
        return await this.sendRequest(cTraderTypes_1.ProtoPayloadType.PROTO_OA_NEW_ORDER_REQ, req);
    }
    /**
     * Cancels a pending order in cTrader
     */
    async cancelOrder(ctidTraderAccountId, orderId) {
        const payload = {
            ctidTraderAccountId,
            orderId
        };
        return await this.sendRequest(cTraderTypes_1.ProtoPayloadType.PROTO_OA_CANCEL_ORDER_REQ, payload);
    }
    /**
     * Closes an existing position in cTrader
     */
    async closePosition(ctidTraderAccountId, positionId, volume) {
        const payload = {
            ctidTraderAccountId,
            positionId,
            volume
        };
        return await this.sendRequest(cTraderTypes_1.ProtoPayloadType.PROTO_OA_CLOSE_POSITION_REQ, payload);
    }
    /**
     * Core request/response dispatcher with clientMsgId correlation
     */
    sendRequest(payloadType, payload, timeoutMs = 15000) {
        return new Promise((resolve, reject) => {
            if (!this.ws || this.ws.readyState !== ws_1.default.OPEN) {
                return reject(new Error('cTrader WebSocket is not connected'));
            }
            const clientMsgId = `REQ_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
            const timeout = setTimeout(() => {
                this.pendingRequests.delete(clientMsgId);
                reject(new Error(`cTrader request timed out after ${timeoutMs}ms (type=${payloadType})`));
            }, timeoutMs);
            this.pendingRequests.set(clientMsgId, { resolve, reject, timeout });
            const message = {
                payloadType,
                payload,
                clientMsgId
            };
            try {
                this.ws.send(JSON.stringify(message));
            }
            catch (err) {
                clearTimeout(timeout);
                this.pendingRequests.delete(clientMsgId);
                reject(err);
            }
        });
    }
    handleMessage(raw) {
        try {
            const msgStr = typeof raw === 'string' ? raw : raw.toString('utf8');
            const message = JSON.parse(msgStr);
            // Handle heartbeat response
            if (message.payloadType === cTraderTypes_1.ProtoPayloadType.HEARTBEAT_EVENT) {
                return;
            }
            // Correlate with pending request
            if (message.clientMsgId && this.pendingRequests.has(message.clientMsgId)) {
                const { resolve, reject, timeout } = this.pendingRequests.get(message.clientMsgId);
                clearTimeout(timeout);
                this.pendingRequests.delete(message.clientMsgId);
                if (message.payloadType === cTraderTypes_1.ProtoPayloadType.ERROR_RES || message.payloadType === cTraderTypes_1.ProtoPayloadType.PROTO_OA_ORDER_ERROR_EVENT) {
                    return reject(new Error(message.payload?.description || message.payload?.errorCode || 'cTrader Error'));
                }
                return resolve(message.payload);
            }
            // Handle Push Execution Event from cTrader
            if (message.payloadType === cTraderTypes_1.ProtoPayloadType.PROTO_OA_EXECUTION_EVENT) {
                this.processExecutionEvent(message.payload);
            }
        }
        catch (err) {
            console.error(`[cTraderGateway] Error parsing incoming message:`, err.message);
        }
    }
    /**
     * Process execution events from cTrader app/server (fills, cancels, rejections)
     */
    async processExecutionEvent(event) {
        try {
            console.log(`[cTraderGateway] ⚡ Execution Event received: type=${event.executionType}, account=${event.ctidTraderAccountId}`);
            // 1. Update mapping table
            const updateRes = await cTraderOrderMapper_1.CTraderOrderMapper.updateExecutionMapping(event);
            // 2. Broadcast via Redis for real-time portfolio & terminal sync
            await redis_1.redis.publish('stream:trading', JSON.stringify({
                event: 'ctrader.execution',
                account: String(event.ctidTraderAccountId),
                internalOrderId: updateRes.internalOrderId || '',
                status: updateRes.status,
                payload: event
            })).catch(() => { });
            // 3. Emit local event for connected subscribers
            this.emit('execution', { event, updateRes });
        }
        catch (err) {
            console.error(`[cTraderGateway] Failed to process execution event:`, err.message);
        }
    }
    startHeartbeat() {
        if (this.heartbeatTimer)
            clearInterval(this.heartbeatTimer);
        this.heartbeatTimer = setInterval(() => {
            if (this.ws && this.ws.readyState === ws_1.default.OPEN) {
                const ping = {
                    payloadType: cTraderTypes_1.ProtoPayloadType.HEARTBEAT_EVENT,
                    payload: {}
                };
                try {
                    this.ws.send(JSON.stringify(ping));
                }
                catch (_) { }
            }
        }, 15000);
    }
    handleError(err) {
        console.error(`[cTraderGateway] WebSocket error:`, err.message);
    }
    handleClose(code, reason) {
        console.warn(`[cTraderGateway] WebSocket closed (code=${code}, reason=${reason})`);
        this.isConnected = false;
        this.isAppAuthorized = false;
        this.authorizedAccounts.clear();
        if (this.heartbeatTimer)
            clearInterval(this.heartbeatTimer);
        this.scheduleReconnect();
    }
    scheduleReconnect() {
        if (this.reconnectTimer)
            return;
        this.reconnectTimer = setTimeout(() => {
            this.reconnectTimer = null;
            this.initialize().catch(() => { });
        }, 5000);
    }
    shutdown() {
        if (this.heartbeatTimer)
            clearInterval(this.heartbeatTimer);
        if (this.reconnectTimer)
            clearTimeout(this.reconnectTimer);
        if (this.ws) {
            this.ws.close();
            this.ws = null;
        }
        this.isConnected = false;
        this.isAppAuthorized = false;
    }
}
exports.CTraderGateway = CTraderGateway;
