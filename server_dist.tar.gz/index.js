"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.server = exports.app = void 0;
const express_1 = __importDefault(require("express"));
const http_1 = __importDefault(require("http"));
const cors_1 = __importDefault(require("cors"));
const helmet_1 = __importDefault(require("helmet"));
const dotenv_1 = __importDefault(require("dotenv"));
const path_1 = __importDefault(require("path"));
dotenv_1.default.config();
// P0-3 FIX: Validate critical environment variables before any other imports
const auth_1 = require("./middleware/auth");
(0, auth_1.validateStartupEnvironment)();
const init_1 = require("./db/init");
const pool_1 = require("./db/pool");
const MarketDataEngine_1 = require("./marketData/MarketDataEngine");
const ExecutionEngine_1 = require("./trading/ExecutionEngine");
const server_1 = require("./websocket/server");
const api_1 = __importDefault(require("./routes/api"));
const adminApi_1 = __importDefault(require("./routes/adminApi"));
const warRoomRoutes_1 = require("./routes/warRoomRoutes");
const ssoRoutes_1 = require("./routes/ssoRoutes");
const SafetyLock_1 = require("./services/SafetyLock");
const cronJobs_1 = require("./utils/cronJobs");
const RmsLossMonitor_1 = require("./trading/RmsLossMonitor");
const dhanTokenRefresh_1 = require("./utils/dhanTokenRefresh");
// Technical Assertion Lock on Server Startup
SafetyLock_1.SafetyLock.assertSimulationOnly('ServerStartup');
// Global Process Resilience Guards — prevent unhandled rejections from crashing the HTTP server and returning 504s
process.on('unhandledRejection', (reason, promise) => {
    console.error('[Process] ⚠️ Unhandled Rejection:', reason?.message || reason);
    if (reason?.stack) {
        console.error(reason.stack);
    }
});
process.on('uncaughtException', (err) => {
    console.error('[Process] ⚠️ Uncaught Exception:', err.message);
    console.error(err.stack);
});
const app = (0, express_1.default)();
exports.app = app;
app.set('trust proxy', 1);
const server = http_1.default.createServer(app);
exports.server = server;
const PORT = process.env.PORT || 5000;
// ============================================================
// P1-5: Helmet.js Security Headers
// ============================================================
app.use((0, helmet_1.default)({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'", "cdn.jsdelivr.net", "unpkg.com"],
            styleSrc: ["'self'", "'unsafe-inline'", "fonts.googleapis.com"],
            fontSrc: ["'self'", "fonts.gstatic.com"],
            imgSrc: ["'self'", "data:", "blob:"],
            connectSrc: ["'self'", "ws:", "wss:"],
            frameSrc: ["'none'"],
            objectSrc: ["'none'"]
        }
    },
    hsts: process.env.NODE_ENV === 'production'
        ? { maxAge: 31536000, includeSubDomains: true, preload: true }
        : false,
    noSniff: true,
    xssFilter: true,
    frameguard: { action: 'deny' }
}));
// ============================================================
// P1-9: Explicit CORS — restrict to known origins
// ============================================================
const allowedOrigins = (process.env.ALLOWED_ORIGINS || 'http://localhost:5173,http://localhost:5000')
    .split(',')
    .map(o => o.trim());
app.use((0, cors_1.default)({
    origin: (origin, callback) => {
        // Allow same-origin requests (no origin header)
        if (!origin)
            return callback(null, true);
        // Allow any localhost origin (any port) for local development
        if (origin.startsWith('http://localhost:') || origin.startsWith('http://127.0.0.1:')) {
            return callback(null, true);
        }
        // Allow explicitly whitelisted origins
        if (allowedOrigins.includes(origin)) {
            return callback(null, true);
        }
        // Allow production platform domains and subdomains
        const isPlatformDomain = /https?:\/\/([a-z0-9-]+\.)*(tradegrowx\.in|tradegrow\.in|expertstocks\.in|github\.io)$/i.test(origin);
        if (isPlatformDomain) {
            return callback(null, true);
        }
        callback(new Error(`CORS: Origin '${origin}' is not allowed`));
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'Idempotency-Key', 'X-Request-ID']
}));
// JSON Parsers (5mb limit for QR code images and settings)
app.use(express_1.default.json({ limit: '5mb' }));
app.use(express_1.default.urlencoded({ extended: true, limit: '5mb' }));
// Register REST API Routes
app.use('/api/v1', api_1.default);
app.use('/api/v1/admin', adminApi_1.default);
app.use('/api/v1', warRoomRoutes_1.warRoomRouter);
app.use('/api/v1/auth/sso', ssoRoutes_1.ssoRouter);
app.use('/api/v1', ssoRoutes_1.ssoRouter);
// Global JSON error handler for all /api routes (Multer errors, parse errors, uncaught errors)
app.use('/api', (err, _req, res, next) => {
    if (err) {
        console.error('[API Handler Error]', err.message || err);
        if (res.headersSent) {
            return next(err);
        }
        const statusCode = err.status || err.statusCode || (err.name === 'MulterError' ? 400 : 500);
        return res.status(statusCode).json({
            success: false,
            error: {
                code: err.code || (err.name === 'MulterError' ? 'UPLOAD_ERROR' : 'INTERNAL_ERROR'),
                message: err.message || 'An unexpected error occurred during request processing'
            }
        });
    }
    next();
});
// ============================================================
// Startup: DB Init, Immediate Port Binding & Non-Blocking Async Services
// ============================================================
async function startServer() {
    try {
        // 1. Initialize database schema & migrations (fast)
        await (0, init_1.seedDatabase)();
        // 1b. Seed the most recently auto-renewed Dhan token from system_config,
        // if it's fresher than the static value docker-compose's env_file just
        // loaded. Must happen before the first MarketDataEngine.getInstance()
        // call below — that's what constructs DhanAdapter, which reads
        // process.env.DHAN_ACCESS_TOKEN synchronously in its own constructor.
        try {
            const persistedToken = await (0, dhanTokenRefresh_1.loadPersistedDhanToken)();
            if (persistedToken)
                process.env.DHAN_ACCESS_TOKEN = persistedToken;
            // Auto-renew if token is expired or expiring in < 30 mins
            if (!process.env.DHAN_ACCESS_TOKEN || (0, dhanTokenRefresh_1.isTokenExpiringSoon)(process.env.DHAN_ACCESS_TOKEN, 30)) {
                console.log('[Startup] 🔑 Dhan token is expired or expiring soon, auto-generating fresh 24h token via TOTP...');
                const autoRes = await (0, dhanTokenRefresh_1.autoGenerateDhanToken)();
                if (autoRes.success && autoRes.accessToken) {
                    process.env.DHAN_ACCESS_TOKEN = autoRes.accessToken;
                    console.log('[Startup] ✅ Fresh 24h Dhan token generated on startup!');
                }
            }
        }
        catch (err) {
            console.error('[Startup] Warning: Dhan token persistence lookup failed, continuing with env value:', err.message);
        }
        // 2. Serve Frontend Static Files in Production
        const clientDistPath = path_1.default.resolve(__dirname, '../../client/dist');
        app.use(express_1.default.static(clientDistPath));
        app.get('*', (req, res, next) => {
            if (req.path.startsWith('/api') || req.path.startsWith('/ws'))
                return next();
            res.sendFile(path_1.default.join(clientDistPath, 'index.html'), (err) => {
                if (err)
                    res.status(200).send('Trade Grow — Smart Trading Platform API Running. Client build pending.');
            });
        });
        // 3. Start HTTP Server IMMEDIATELY to prevent NGINX 504 Gateway Time-outs
        server.listen(PORT, () => {
            console.log(`=======================================================`);
            console.log(`🌱 TRADE GROW — SMART TRADING PLATFORM LISTENING ON PORT ${PORT}`);
            console.log(`🔒 SAFETY MODE: VIRTUAL PAPER TRADING ONLY (REAL MONEY DISABLED)`);
            console.log(`📊 MARKET DATA: ${MarketDataEngine_1.MarketDataEngine.getInstance().getActiveProviderName()}`);
            console.log(`🛡️  SECURITY: Helmet.js, CORS restricted, Rate limiting active`);
            console.log(`=======================================================`);
        });
        // Align keep-alive timeouts with reverse proxy / Cloudflare / Nginx (avoids silent 502s)
        server.keepAliveTimeout = 65000;
        server.headersTimeout = 66000;
        // 4. Run Heavy Market Data Engines & Background Services Asynchronously (Non-Blocking)
        (async () => {
            try {
                const isPrimary = (process.env.PROCESS_ROLE || 'primary') !== 'worker';
                const { InstrumentMasterService } = await Promise.resolve().then(() => __importStar(require('./marketData/InstrumentMasterService')));
                await InstrumentMasterService.getInstance().initializeOnStartup();
                if (isPrimary) {
                    console.log('[Startup] PROCESS_ROLE is primary — initializing upstream broker market data feed.');
                    await MarketDataEngine_1.MarketDataEngine.getInstance().initialize();
                }
                else {
                    console.log('[Startup] PROCESS_ROLE is worker — broker market data feed handled by primary node.');
                }
                // NSE scraper & AccuracyCheck DISABLED — Dhan provides all data
                // import('./services/ReconciliationMonitorService') — keep monitor but at 5 min interval
                Promise.resolve().then(() => __importStar(require('./services/ReconciliationMonitorService'))).then(({ reconciliationMonitor }) => reconciliationMonitor.start(300000))
                    .catch((err) => console.error('[Startup] Failed to start ReconciliationMonitorService:', err.message));
                ExecutionEngine_1.ExecutionEngine.start();
                (0, server_1.setupWebSocketServer)(server);
                (0, cronJobs_1.startMisAutoSquareOffJob)();
                console.log('[Startup] ✅ RMS auto square-off scheduler started.');
                (0, cronJobs_1.startExpirySettlementJob)();
                console.log('[Startup] ✅ Contract Expiry Settlement scheduler started (15:30 IST daily).');
                // Startup expired contract reconciliation check (settle any lingering past-expired contracts immediately)
                Promise.resolve().then(() => __importStar(require('./trading/ExpirySettlementEngine'))).then(({ ExpirySettlementEngine }) => ExpirySettlementEngine.settleExpiredContracts())
                    .catch((err) => console.error('[Startup] Failed to run initial expiry settlement check:', err.message));
                (0, RmsLossMonitor_1.startRmsLossMonitor)();
                console.log('[Startup] ✅ RMS continuous loss-tier monitor started.');
                const engine = MarketDataEngine_1.MarketDataEngine.getInstance();
                const dhanProvider = engine.getDhanAdapter();
                if (dhanProvider && typeof dhanProvider.getAccessToken === 'function') {
                    (0, dhanTokenRefresh_1.setDhanAdapterRef)(dhanProvider);
                    (0, cronJobs_1.startCronJobs)(() => dhanProvider.getAccessToken());
                    console.log('[Startup] ✅ Dhan token cron jobs started (30-min expiry check + 08:30 AM IST reminder).');
                }
                else {
                    console.warn('[Startup] ⚠️ DhanAdapter not found — cron jobs not started.');
                }
                console.log('[Startup] ✅ Fyers provider DISABLED. Running Dhan-only mode.');
                console.log('[Startup] ✅ All background market data engines & WebSocket services initialized cleanly.');
            }
            catch (bgErr) {
                console.error('[Startup Background Warning]', bgErr.message || bgErr);
            }
        })();
        // ── Graceful Shutdown Handler (SIGTERM & SIGINT) ─────────────────────────
        const handleShutdown = async (signal) => {
            console.log(`[Process] Received ${signal}. Initiating graceful connection draining and shutdown...`);
            const forceExitTimeout = setTimeout(() => {
                console.error('[Process] Forced shutdown after 25s grace timeout exceeded.');
                process.exit(1);
            }, 25000);
            forceExitTimeout.unref();
            try {
                server.close(() => {
                    console.log('[HTTP] HTTP listener closed.');
                });
                const { shutdownWebSocketServer } = await Promise.resolve().then(() => __importStar(require('./websocket/server')));
                await shutdownWebSocketServer();
                ExecutionEngine_1.ExecutionEngine.stop();
                await pool_1.pool.end();
                console.log('[Process] Graceful shutdown completed cleanly.');
                process.exit(0);
            }
            catch (err) {
                console.error('[Process] Error during graceful shutdown:', err.message);
                process.exit(1);
            }
        };
        process.on('SIGTERM', () => handleShutdown('SIGTERM'));
        process.on('SIGINT', () => handleShutdown('SIGINT'));
    }
    catch (err) {
        console.error('[FATAL] Server startup failed:', err.message);
        console.error(err.stack);
        process.exit(1);
    }
}
startServer();
