"use strict";
/**
 * adminEventBus.ts
 *
 * Central event bus for real-time admin notifications.
 * Routes user/trade/position/funds events to subscribed admin WebSocket clients.
 *
 * Usage:
 *   import { adminEventBus } from '../utils/adminEventBus';
 *   adminEventBus.emit('USER_STATUS_UPDATED', userId, { status: 'SUSPENDED', ... });
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.adminEventBus = void 0;
exports.emitAdminOrderEvent = emitAdminOrderEvent;
exports.emitAdminTradeEvent = emitAdminTradeEvent;
exports.emitAdminPositionUpdate = emitAdminPositionUpdate;
exports.emitAdminFundsUpdate = emitAdminFundsUpdate;
exports.emitAdminFundRequestEvent = emitAdminFundRequestEvent;
const events_1 = require("events");
class AdminEventBus extends events_1.EventEmitter {
    /** Emit an event for a specific user that all watching admins should receive */
    emitUserEvent(type, userId, payload) {
        const event = {
            type,
            userId,
            payload,
            timestamp: Date.now()
        };
        this.emit(`user:${userId}`, event);
        this.emit('all', event); // also emit to global admin listeners
    }
    /** Subscribe to events for a specific user */
    onUserEvent(userId, handler) {
        this.on(`user:${userId}`, handler);
    }
    /** Unsubscribe from events for a specific user */
    offUserEvent(userId, handler) {
        this.off(`user:${userId}`, handler);
    }
    /** Subscribe to all events (for global admin monitors) */
    onAllEvents(handler) {
        this.on('all', handler);
    }
    offAllEvents(handler) {
        this.off('all', handler);
    }
}
// Singleton event bus — shared across the entire server process
exports.adminEventBus = new AdminEventBus();
exports.adminEventBus.setMaxListeners(500); // support many concurrent admin sessions
// Thin emit helpers, kept here (not in a route file) so trading-layer code
// (ExecutionEngine, OMS) can call them without importing adminApi.ts, which
// would create a circular import (adminApi.ts already imports ExecutionEngine).
function emitAdminOrderEvent(userId, type, order) {
    exports.adminEventBus.emitUserEvent(type, userId, { order });
}
function emitAdminTradeEvent(userId, trade) {
    exports.adminEventBus.emitUserEvent('TRADE_EXECUTED', userId, { trade });
}
function emitAdminPositionUpdate(userId, positions) {
    exports.adminEventBus.emitUserEvent('POSITION_UPDATED', userId, { positions });
}
function emitAdminFundsUpdate(userId, wallet) {
    exports.adminEventBus.emitUserEvent('FUNDS_UPDATED', userId, { wallet });
}
function emitAdminFundRequestEvent(userId, type, request) {
    exports.adminEventBus.emitUserEvent(type, userId, { request });
}
