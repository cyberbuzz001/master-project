"use strict";
/**
 * cronJobs.ts
 *
 * Scheduled background jobs for Trade Grow.
 *
 * Jobs:
 *  - Every 30 min (Mon-Fri 7:30 AM–4:00 PM IST): Check Dhan token expiry and alert via Telegram
 *  - 8:30 AM IST every trading day: Send morning token renewal reminder to Telegram
 *
 * NOTE: This uses Node.js setInterval (lightweight, no external dep required).
 * For production scale, consider using 'node-cron' package: npm install node-cron
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.startCronJobs = startCronJobs;
exports.startMisAutoSquareOffJob = startMisAutoSquareOffJob;
exports.startExpirySettlementJob = startExpirySettlementJob;
exports.stopCronJobs = stopCronJobs;
const telegramAlert_1 = require("./telegramAlert");
const dhanTokenRefresh_1 = require("./dhanTokenRefresh");
const schema_1 = require("../db/schema");
const RmsAutoSquareOffEngine_1 = require("../trading/RmsAutoSquareOffEngine");
let tokenExpiryCheckInterval = null;
let morningReminderTimeout = null;
let fyersRenewalInterval = null;
let misSquareOffTimeout = null;
/**
 * Checks and auto-renews Fyers Access Token automatically in the background
 */
/**
 * Fyers auto-renewal is DISABLED — Fyers provider is not used.
 */
function startFyersAutoRenewalCheck() {
    // DISABLED: Fyers is not used. Removing this prevents crash-reconnect storms on startup.
    console.log('[CronJobs] ℹ️  Fyers auto-renewal skipped — Fyers provider is disabled.');
}
/**
 * Get milliseconds until the next occurrence of a given IST hour:minute on Mon-Fri.
 * Operates independently of the host server OS timezone by using Intl.DateTimeFormat.
 */
function getMsUntilISTTime(targetHour, targetMinute) {
    const now = new Date();
    const fmt = new Intl.DateTimeFormat('en-CA', {
        timeZone: 'Asia/Kolkata',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
    });
    const parts = fmt.formatToParts(now);
    const p = {};
    for (const part of parts) {
        if (part.type !== 'literal')
            p[part.type] = part.value;
    }
    const istYear = p.year;
    const istMonth = p.month;
    const istDay = p.day;
    const pad = (n) => String(n).padStart(2, '0');
    const isoTargetStr = `${istYear}-${istMonth}-${istDay}T${pad(targetHour)}:${pad(targetMinute)}:00+05:30`;
    let target = new Date(isoTargetStr);
    if (target.getTime() <= now.getTime()) {
        target = new Date(target.getTime() + 24 * 60 * 60 * 1000);
    }
    // Skip weekends (Saturday and Sunday in IST)
    while (true) {
        const dowStr = new Intl.DateTimeFormat('en-US', { timeZone: 'Asia/Kolkata', weekday: 'short' }).format(target);
        if (dowStr !== 'Sat' && dowStr !== 'Sun')
            break;
        target = new Date(target.getTime() + 24 * 60 * 60 * 1000);
    }
    return Math.max(1000, target.getTime() - now.getTime());
}
/**
 * Schedule the 08:30 AM IST morning Telegram reminder to renew the Dhan token.
 * Recursively re-schedules itself for the next trading day after firing.
 */
function scheduleMorningReminder(getAccessToken) {
    const msUntilMorning = getMsUntilISTTime(8, 30);
    const hoursUntil = (msUntilMorning / 1000 / 60 / 60).toFixed(1);
    console.log(`[CronJobs] ⏰ Morning token reminder scheduled in ${hoursUntil}h (08:30 AM IST next trading day).`);
    morningReminderTimeout = setTimeout(async () => {
        try {
            console.log('[CronJobs] 🌅 Running 08:30 AM Pre-Market System Readiness Probe...');
            let token = getAccessToken();
            let minutesLeft = (0, dhanTokenRefresh_1.getTokenExpiryMinutes)(token);
            // Auto-renew if token is expiring within 2 hours
            if (minutesLeft <= 120) {
                console.log('[CronJobs] 🔄 Pre-market token renewal triggered...');
                const renewRes = await (0, dhanTokenRefresh_1.autoGenerateDhanToken)();
                if (renewRes.success && renewRes.accessToken) {
                    token = renewRes.accessToken;
                    minutesLeft = (0, dhanTokenRefresh_1.getTokenExpiryMinutes)(token);
                }
            }
            const hoursLeft = (minutesLeft / 60).toFixed(1);
            const isTokenOk = minutesLeft > 0;
            // Probe Live Dhan REST Quotes
            let niftyQuoteOk = false;
            let sensexQuoteOk = false;
            let niftyLtp = 0;
            let sensexLtp = 0;
            let probeLatency = 0;
            try {
                const start = Date.now();
                const { MarketDataEngine } = require('../marketData/MarketDataEngine');
                const engine = MarketDataEngine.getInstance();
                const [niftyTick, sensexTick] = await Promise.all([
                    engine.getQuote('NSE_NIFTY50'),
                    engine.getQuote('BSE_SENSEX')
                ]);
                probeLatency = Date.now() - start;
                if (niftyTick && niftyTick.ltp > 0) {
                    niftyQuoteOk = true;
                    niftyLtp = niftyTick.ltp;
                }
                if (sensexTick && sensexTick.ltp > 0) {
                    sensexQuoteOk = true;
                    sensexLtp = sensexTick.ltp;
                }
            }
            catch (err) {
                console.warn('[CronJobs] Pre-market quote probe error:', err.message);
            }
            const { InstrumentMasterService } = require('../marketData/InstrumentMasterService');
            const scripCount = InstrumentMasterService.getInstance().getInstrumentCount?.() || 200000;
            const isAllOk = isTokenOk && (niftyQuoteOk || sensexQuoteOk);
            const statusEmoji = isAllOk ? '🟢' : '⚠️';
            const summaryMsg = `🌅 <b>Trade Grow — 08:30 AM Pre-Market System Readiness</b>\n` +
                `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
                `${isTokenOk ? '✅' : '❌'} <b>Dhan Token:</b> ${isTokenOk ? `Healthy (${hoursLeft}h / ${minutesLeft}m left)` : 'EXPIRED'}\n` +
                `${niftyQuoteOk ? '✅' : '⚠️'} <b>NIFTY 50 Feed:</b> ${niftyQuoteOk ? `₹${niftyLtp.toLocaleString('en-IN')}` : 'Standby / Pre-open'}\n` +
                `${sensexQuoteOk ? '✅' : '⚠️'} <b>SENSEX Feed:</b> ${sensexQuoteOk ? `₹${sensexLtp.toLocaleString('en-IN')}` : 'Standby / Pre-open'}\n` +
                `📡 <b>REST Latency:</b> ${probeLatency}ms\n` +
                `📊 <b>Scrip Master:</b> ~${scripCount.toLocaleString('en-IN')} instruments active\n` +
                `⚡ <b>Matching & Execution Engine:</b> ONLINE\n` +
                `🛡️ <b>RMS Auto Square-Off:</b> Scheduled for 15:15 IST\n` +
                `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
                `${statusEmoji} <b>Status:</b> ${isAllOk ? '100% READY for 09:15 AM Market Open! 🚀' : 'Action Required before Market Open'}`;
            await (0, telegramAlert_1.sendTelegramAlert)(summaryMsg);
        }
        catch (err) {
            console.error('[CronJobs] Error during 08:30 AM pre-market reminder:', err.message);
        }
        // Re-schedule for the next trading day
        scheduleMorningReminder(getAccessToken);
    }, msUntilMorning);
}
/**
 * Schedule the MIS auto square-off engine run at the configured IST time.
 * Re-reads MIS_AUTO_SQUARE_OFF_TIME from system_settings on every reschedule
 * (not cached) so an admin changing it mid-day takes effect the next trading
 * day without a restart. Falls back to '15:15' if the key is missing.
 * Not gated behind Dhan-adapter availability — unlike startCronJobs(), this
 * must run even if the market-data provider failed to initialize, since EOD
 * risk cleanup matters most exactly when other systems are degraded.
 */
let commodityMisSquareOffTimeout = null;
/**
 * Schedule the daily MIS auto square-off engine run for Equity (15:15 IST).
 */
async function scheduleMisAutoSquareOff() {
    let hour = 15, minute = 15;
    try {
        const row = await (0, schema_1.queryOne)(`SELECT value FROM system_settings WHERE key = 'MIS_AUTO_SQUARE_OFF_TIME'`);
        const raw = (row?.value || '15:15').trim();
        const match = raw.match(/^(\d{1,2}):(\d{2})$/);
        if (match) {
            hour = parseInt(match[1], 10);
            minute = parseInt(match[2], 10);
        }
    }
    catch (err) {
        console.warn('[CronJobs] Failed to read MIS_AUTO_SQUARE_OFF_TIME, defaulting to 15:15:', err.message);
    }
    const msUntilRun = getMsUntilISTTime(hour, minute);
    console.log(`[CronJobs] 🔒 Equity MIS auto square-off scheduled in ${(msUntilRun / 1000 / 60 / 60).toFixed(1)}h (${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')} IST next trading day).`);
    misSquareOffTimeout = setTimeout(async () => {
        try {
            await RmsAutoSquareOffEngine_1.RmsAutoSquareOffEngine.run('EQUITY');
        }
        catch (err) {
            console.error('[CronJobs] Equity RMS auto square-off run failed:', err.message);
        }
        // Re-schedule for the next trading day
        scheduleMisAutoSquareOff();
    }, msUntilRun);
}
/**
 * Schedule the daily MIS auto square-off engine run for MCX Commodities (23:15 IST).
 */
async function scheduleCommodityMisAutoSquareOff() {
    const hour = 23, minute = 15;
    const msUntilRun = getMsUntilISTTime(hour, minute);
    console.log(`[CronJobs] 🔒 Commodity (MCX) MIS auto square-off scheduled in ${(msUntilRun / 1000 / 60 / 60).toFixed(1)}h (23:15 IST next trading day).`);
    commodityMisSquareOffTimeout = setTimeout(async () => {
        try {
            await RmsAutoSquareOffEngine_1.RmsAutoSquareOffEngine.run('COMMODITY');
        }
        catch (err) {
            console.error('[CronJobs] Commodity RMS auto square-off run failed:', err.message);
        }
        // Re-schedule for the next trading day
        scheduleCommodityMisAutoSquareOff();
    }, msUntilRun);
}
/**
 * Start the Dhan token expiry check interval.
 * Checks every 30 minutes. Sends an alert if token expires in <60 minutes.
 */
function startTokenExpiryCheck(getAccessToken) {
    // Run immediately on start
    const checkNow = async () => {
        const token = getAccessToken();
        const hasAutoCreds = process.env.DHAN_TOTP_SECRET && process.env.DHAN_PIN && process.env.DHAN_CLIENT_ID;
        // Check if token missing or expiring in <60 min
        const isExpiring = !token || (0, dhanTokenRefresh_1.isTokenExpiringSoon)(token, 60);
        if (isExpiring) {
            if (hasAutoCreds) {
                console.log('[CronJobs] 🔄 Dhan token missing or expiring soon. Attempting automated renewal with TOTP...');
                const res = await (0, dhanTokenRefresh_1.autoGenerateDhanToken)();
                if (res.success) {
                    console.log('[CronJobs] ✅ Dhan token auto-generated & updated successfully!');
                    return;
                }
                else {
                    console.warn('[CronJobs] ⚠️ Dhan auto-generation failed:', res.message);
                }
            }
            if (token) {
                const minutesLeft = (0, dhanTokenRefresh_1.getTokenExpiryMinutes)(token);
                console.warn(`[CronJobs] ⚠️ Dhan token expiring in ${minutesLeft} minutes! Sending Telegram alert...`);
                await (0, telegramAlert_1.sendTelegramAlert)(`⚠️ <b>Trade Grow — Dhan Token Expiry Alert!</b>\n\n` +
                    `🕐 Token expires in: <b>${minutesLeft} minutes</b>\n\n` +
                    `🔑 Action required:\n` +
                    `1. Login to <a href="https://login.dhan.co">https://login.dhan.co</a>\n` +
                    `2. Copy your new Access Token\n` +
                    `3. POST to: <code>/api/internal/update-dhan-token</code>\n\n` +
                    `Body: <code>{"accessToken": "YOUR_NEW_TOKEN"}</code>`);
            }
        }
        else {
            const minutesLeft = (0, dhanTokenRefresh_1.getTokenExpiryMinutes)(token);
            if (minutesLeft > 0) {
                console.log(`[CronJobs] ✅ Dhan token healthy. Expires in ${minutesLeft} minutes (~${(minutesLeft / 60).toFixed(1)}h).`);
            }
        }
    };
    checkNow();
    // Check every 30 minutes
    tokenExpiryCheckInterval = setInterval(checkNow, 30 * 60 * 1000);
    console.log('[CronJobs] 🔄 Dhan token expiry check interval started (every 30 minutes with TOTP auto-renewal).');
}
/**
 * Start all cron jobs. Call this from server/src/index.ts after DhanAdapter initializes.
 * @param getAccessToken - A function that returns the current Dhan access token (live)
 */
function startCronJobs(getAccessToken) {
    console.log('[CronJobs] 🚀 Starting Trade Grow background cron jobs...');
    startTokenExpiryCheck(getAccessToken);
    scheduleMorningReminder(getAccessToken);
    startFyersAutoRenewalCheck();
}
let expirySettlementTimeout = null;
let expirySettlementInterval = null;
/**
 * Schedule the daily Contract Expiry Settlement engine run at 15:30 IST.
 * Settles all expiring derivative contracts across NRML/MIS/CNC.
 */
async function scheduleExpirySettlement() {
    let hour = 15, minute = 30;
    try {
        const row = await (0, schema_1.queryOne)(`SELECT value FROM system_settings WHERE key = 'EXPIRY_SETTLEMENT_TIME'`);
        const raw = (row?.value || '15:30').trim();
        const match = raw.match(/^(\d{1,2}):(\d{2})$/);
        if (match) {
            hour = parseInt(match[1], 10);
            minute = parseInt(match[2], 10);
        }
    }
    catch (err) {
        console.warn('[CronJobs] Failed to read EXPIRY_SETTLEMENT_TIME, defaulting to 15:30:', err.message);
    }
    const msUntilRun = getMsUntilISTTime(hour, minute);
    console.log(`[CronJobs] 📅 Contract Expiry Settlement scheduled in ${(msUntilRun / 1000 / 60 / 60).toFixed(1)}h (${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')} IST next trading day).`);
    expirySettlementTimeout = setTimeout(async () => {
        try {
            const { ExpirySettlementEngine } = await Promise.resolve().then(() => __importStar(require('../trading/ExpirySettlementEngine')));
            console.log('[CronJobs] 🚀 Executing scheduled 15:30 IST Contract Expiry Settlement...');
            await ExpirySettlementEngine.settleExpiredContracts();
        }
        catch (err) {
            console.error('[CronJobs] Contract Expiry Settlement run failed:', err.message);
        }
        // Re-schedule for the next trading day
        scheduleExpirySettlement();
    }, msUntilRun);
}
/**
 * Start the MIS auto square-off scheduler (both Equity at 15:15 and Commodity at 23:15 IST).
 */
function startMisAutoSquareOffJob() {
    scheduleMisAutoSquareOff();
    // Commodity (MCX) MIS auto square-off disabled per operator request
}
/**
 * Start the daily Contract Expiry Settlement scheduler and runtime background checks.
 */
function startExpirySettlementJob() {
    scheduleExpirySettlement();
    // Periodic safety check: every 5 minutes during post-market (15:30–16:00 IST), verify no expired contracts remain open
    expirySettlementInterval = setInterval(async () => {
        try {
            const now = new Date();
            const istHours = ((now.getUTCHours() + 5) % 24) + ((now.getUTCMinutes() + 30) >= 60 ? 1 : 0) + (((now.getUTCMinutes() + 30) % 60) / 60);
            if (istHours >= 15.5 && istHours <= 16.5) {
                const { ExpirySettlementEngine } = await Promise.resolve().then(() => __importStar(require('../trading/ExpirySettlementEngine')));
                await ExpirySettlementEngine.settleExpiredContracts();
            }
        }
        catch (_) { }
    }, 5 * 60 * 1000);
}
/**
 * Gracefully stop all cron jobs (for clean server shutdown).
 */
function stopCronJobs() {
    if (tokenExpiryCheckInterval)
        clearInterval(tokenExpiryCheckInterval);
    if (morningReminderTimeout)
        clearTimeout(morningReminderTimeout);
    if (fyersRenewalInterval)
        clearInterval(fyersRenewalInterval);
    if (misSquareOffTimeout)
        clearTimeout(misSquareOffTimeout);
    if (commodityMisSquareOffTimeout)
        clearTimeout(commodityMisSquareOffTimeout);
    if (expirySettlementTimeout)
        clearTimeout(expirySettlementTimeout);
    if (expirySettlementInterval)
        clearInterval(expirySettlementInterval);
    console.log('[CronJobs] 🛑 All cron jobs stopped.');
}
