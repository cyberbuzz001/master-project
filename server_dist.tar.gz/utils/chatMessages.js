"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.recordChatMessage = recordChatMessage;
exports.getChatHistory = getChatHistory;
exports.markChatReadByStaff = markChatReadByStaff;
/**
 * chatMessages.ts
 * Shared persistence + delivery for the live-chat feature (Support Chats — the last
 * of the four deferred items from Phase F1's gap analysis). One continuous thread
 * per customer; called from both the WS gateway's CHAT_SEND handler and the REST
 * fallback routes, so a message sent either way is recorded and delivered the same.
 */
const schema_1 = require("../db/schema");
const crypto_1 = require("./crypto");
const adminEventBus_1 = require("./adminEventBus");
/**
 * Persists a chat message and pushes it to any admin socket watching this customer
 * (per-customer ADMIN_SUBSCRIBE) or watching platform-wide (ADMIN_SUBSCRIBE_ALL) —
 * reusing the exact fan-out Phase E1 already wired up. Does NOT deliver to the
 * customer's own connection; that half (a direct, non-admin-flagged socket lookup)
 * only the WS gateway itself can do, since it alone holds the live `wss.clients` set
 * — see `deliverToUser` in `websocket/server.ts`, called by the route/handler after
 * this resolves.
 */
async function recordChatMessage(customerId, senderId, senderRole, text) {
    const id = 'cmsg_' + (0, crypto_1.generateUUID)();
    await (0, schema_1.execute)(`INSERT INTO chat_messages (id, customer_id, sender_id, sender_role, message) VALUES ($1, $2, $3, $4, $5)`, [id, customerId, senderId, senderRole, text]);
    const row = {
        id, customer_id: customerId, sender_id: senderId, sender_role: senderRole,
        message: text, created_at: new Date().toISOString(), read_at: null,
    };
    adminEventBus_1.adminEventBus.emitUserEvent('CHAT_MESSAGE_RECEIVED', customerId, { message: row });
    return row;
}
async function getChatHistory(customerId, limit = 100) {
    return (0, schema_1.query)(`SELECT * FROM (
      SELECT * FROM chat_messages
      WHERE customer_id = $1
      ORDER BY created_at DESC
      LIMIT $2
    ) recent
    ORDER BY created_at ASC`, [customerId, limit]);
}
async function markChatReadByStaff(customerId) {
    // Only staff-side reads clear the "customer is waiting" unread count — a customer
    // reading the admin's own reply doesn't need a symmetric "admin unread" concept.
    await (0, schema_1.execute)(`UPDATE chat_messages SET read_at = NOW() WHERE customer_id = $1 AND sender_role = 'USER' AND read_at IS NULL`, [customerId]);
}
