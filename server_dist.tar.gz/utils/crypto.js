"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.cryptoRandomString = cryptoRandomString;
exports.generateUUID = generateUUID;
const crypto_1 = __importDefault(require("crypto"));
function cryptoRandomString(length = 16) {
    return crypto_1.default.randomBytes(Math.ceil(length / 2)).toString('hex').slice(0, length);
}
function generateUUID() {
    return crypto_1.default.randomUUID();
}
