"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.verifyMetaSignature = verifyMetaSignature;
exports.isDuplicateWebhookEvent = isDuplicateWebhookEvent;
const crypto_1 = __importDefault(require("crypto"));
const redis_1 = require("../db/redis");
/**
 * Validates Meta (WhatsApp Cloud API) X-Hub-Signature-256 header against raw payload buffer.
 * Enforces constant-time comparison to prevent timing attacks.
 */
function verifyMetaSignature(rawBody, signatureHeader, appSecret) {
    if (!signatureHeader || !appSecret || !rawBody) {
        return false;
    }
    const parts = signatureHeader.split('=');
    if (parts.length !== 2 || parts[0].toLowerCase() !== 'sha256') {
        return false;
    }
    const clientSignature = parts[1].trim().toLowerCase();
    const hmac = crypto_1.default.createHmac('sha256', appSecret);
    const payloadBuffer = Buffer.isBuffer(rawBody) ? rawBody : Buffer.from(rawBody, 'utf8');
    const expectedSignature = hmac.update(payloadBuffer).digest('hex').toLowerCase();
    const clientBuf = Buffer.from(clientSignature, 'hex');
    const expectedBuf = Buffer.from(expectedSignature, 'hex');
    if (clientBuf.length !== expectedBuf.length) {
        return false;
    }
    return crypto_1.default.timingSafeEqual(clientBuf, expectedBuf);
}
/**
 * Checks and records event/message ID to prevent replay attacks across webhooks.
 * Returns true if this event is a duplicate (already processed), false if new.
 */
async function isDuplicateWebhookEvent(provider, eventId, ttlSeconds = 86400) {
    if (!eventId)
        return false;
    const key = `webhook_event:${provider}:${eventId.trim()}`;
    const isNew = await redis_1.redis.setIfNotExists(key, '1', ttlSeconds);
    return !isNew;
}
