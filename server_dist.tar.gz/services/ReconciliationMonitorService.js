"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.reconciliationMonitor = exports.ReconciliationMonitorService = void 0;
const MarketDataEngine_1 = require("../marketData/MarketDataEngine");
const telegramAlert_1 = require("../utils/telegramAlert");
class ReconciliationMonitorService {
    static instance;
    timer = null;
    isRunning = false;
    lastReport = null;
    // Auto-recovery: track consecutive all-miss checks to detect a totally dead feed
    consecutiveAllMissCount = 0;
    static DEAD_FEED_THRESHOLD = 3; // 3 checks × 5 min = 15 min dead before reconnect
    feedWasDown = false;
    autoRecoveryInProgress = false;
    static getInstance() {
        if (!ReconciliationMonitorService.instance) {
            ReconciliationMonitorService.instance = new ReconciliationMonitorService();
        }
        return ReconciliationMonitorService.instance;
    }
    start(intervalMs = 60000) {
        if (this.isRunning)
            return;
        this.isRunning = true;
        console.log(`[ReconciliationMonitor] Starting continuous price feed reconciliation monitor (${intervalMs / 1000}s interval)...`);
        // Run initial check after 10s warmup
        setTimeout(() => this.runReconciliationCheck(), 10000);
        this.timer = setInterval(() => this.runReconciliationCheck(), intervalMs);
    }
    stop() {
        if (this.timer)
            clearInterval(this.timer);
        this.isRunning = false;
        console.log('[ReconciliationMonitor] Stopped price feed reconciliation monitor.');
    }
    async runReconciliationCheck() {
        const engine = MarketDataEngine_1.MarketDataEngine.getInstance();
        // These were raw Dhan numeric security IDs (e.g. NSE_99926000), which
        // SymbologyNormalizer has no logic to resolve to the symbol-based keys
        // (NSE_NIFTY50, NSE_RELIANCE, ...) the tick cache is actually populated
        // under — every sample here always missed, silently, since this file was
        // written: every cycle logged "0/5 matched, 0 alerts" whether the feed
        // was perfectly healthy or badly diverged, because MISSING_DATA and a
        // genuinely clean check both produce alertCount=0. Switched to the same
        // canonical token format used everywhere else in this codebase.
        const sampleTokens = [
            { symbol: 'NIFTY 50', token: 'NSE_NIFTY50' },
            { symbol: 'BANKNIFTY', token: 'NSE_BANKNIFTY' },
            { symbol: 'SENSEX', token: 'BSE_SENSEX' },
            { symbol: 'FINNIFTY', token: 'NSE_FINNIFTY' },
            { symbol: 'RELIANCE', token: 'NSE_RELIANCE' },
        ];
        const results = [];
        let passedCount = 0;
        let alertCount = 0;
        let missingCount = 0;
        for (const sample of sampleTokens) {
            const cached = engine.getCachedTick(sample.token) || engine.getCachedTick(sample.token.replace(/^([A-Z]+_)/, ''));
            if (!cached) {
                missingCount++;
                results.push({
                    symbol: sample.symbol,
                    token: sample.token,
                    cachedLtp: 0,
                    referenceLtp: 0,
                    diffPct: 0,
                    status: 'MISSING_DATA',
                });
                continue;
            }
            let referenceTick = null;
            try {
                referenceTick = await engine.getQuote(sample.token);
            }
            catch (_) { }
            const refLtp = referenceTick ? referenceTick.ltp : cached.ltp;
            const cachedLtp = cached.ltp;
            const diffPct = refLtp > 0 ? Number((Math.abs(cachedLtp - refLtp) / refLtp * 100).toFixed(2)) : 0;
            const isAlert = diffPct > 0.50; // Threshold 0.50%
            const status = isAlert ? 'DIVERGENCE_ALERT' : 'MATCH';
            if (isAlert) {
                alertCount++;
                console.warn(`[ReconciliationMonitor] 🚨 DIVERGENCE ALERT: ${sample.symbol} (${sample.token}) | WS Cache: ₹${cachedLtp} vs Reference: ₹${refLtp} (Diff: ${diffPct}%)`);
            }
            else {
                passedCount++;
            }
            results.push({
                symbol: sample.symbol,
                token: sample.token,
                cachedLtp,
                referenceLtp: refLtp,
                diffPct,
                status,
            });
        }
        this.lastReport = {
            timestamp: Date.now(),
            tokensChecked: sampleTokens.length,
            passedCount,
            alertCount,
            missingCount,
            results,
        };
        // ── Dead-feed detection and auto-recovery ─────────────────────────────────
        // A totally-dead feed (all 5 tokens missing from cache) is different from
        // divergence. Track consecutive all-miss checks and force-reconnect the
        // Dhan WebSocket after DEAD_FEED_THRESHOLD consecutive failures instead of
        // waiting for an external restart (which caused a 1.5-hour LTP freeze).
        const isMarketHours = (() => {
            const now = new Date();
            // Convert to IST (UTC+5:30)
            const ist = new Date(now.getTime() + (5.5 * 60 * 60 * 1000));
            const hours = ist.getUTCHours();
            const minutes = ist.getUTCMinutes();
            const totalMin = hours * 60 + minutes;
            return totalMin >= 555 && totalMin <= 930; // 09:15 – 15:30 IST
        })();
        if (missingCount === sampleTokens.length) {
            this.consecutiveAllMissCount++;
            console.warn(`[ReconciliationMonitor] ⚠️  ${missingCount}/${sampleTokens.length} sample tokens had no cached tick at all ` +
                `(feed down, or a stale/incorrect token key). Consecutive dead checks: ${this.consecutiveAllMissCount}/${ReconciliationMonitorService.DEAD_FEED_THRESHOLD}.`);
            // First detection — send Telegram alert
            if (this.consecutiveAllMissCount === 1 && !this.feedWasDown) {
                this.feedWasDown = true;
                const marketNote = isMarketHours ? '⚠️ <b>MARKET IS OPEN</b> — LTPs are frozen for clients!' : '(Market is closed — no client impact yet)';
                (0, telegramAlert_1.sendTelegramAlert)(`🚨 <b>TradeGrow — Live Feed DOWN</b>\n\n` +
                    `${marketNote}\n\n` +
                    `📊 Dhan WebSocket: 0/5 core tokens producing ticks.\n` +
                    `🔄 Auto-recovery will trigger in ${ReconciliationMonitorService.DEAD_FEED_THRESHOLD - 1} more consecutive miss(es).`).catch(() => { });
            }
            // Threshold hit — force reconnect the WebSocket
            if (!this.autoRecoveryInProgress && this.consecutiveAllMissCount >= ReconciliationMonitorService.DEAD_FEED_THRESHOLD) {
                this.autoRecoveryInProgress = true;
                console.warn('[ReconciliationMonitor] 🔄 Feed dead for 3+ consecutive checks. Triggering automatic Dhan WebSocket force-reconnect...');
                const dhanAdapter = MarketDataEngine_1.MarketDataEngine.getInstance().getDhanAdapter();
                if (dhanAdapter && typeof dhanAdapter.setAccessToken === 'function') {
                    const currentToken = dhanAdapter.getAccessToken?.() ?? '';
                    dhanAdapter.setAccessToken(currentToken)
                        .then(() => {
                        console.log('[ReconciliationMonitor] ✅ Auto-recovery WebSocket reconnect issued.');
                        this.autoRecoveryInProgress = false;
                    })
                        .catch((err) => {
                        console.error('[ReconciliationMonitor] Auto-recovery reconnect failed:', err?.message);
                        this.autoRecoveryInProgress = false;
                    });
                }
                else {
                    console.warn('[ReconciliationMonitor] DhanAdapter not accessible for auto-recovery reconnect.');
                    this.autoRecoveryInProgress = false;
                }
                // Reset counter so we give the reconnect time to work before trying again
                this.consecutiveAllMissCount = 0;
            }
        }
        else {
            // Feed is producing ticks — reset dead-feed state
            if (this.feedWasDown) {
                console.log(`[ReconciliationMonitor] ✅ Feed recovered! ${passedCount}/${sampleTokens.length} matched cleanly.`);
                (0, telegramAlert_1.sendTelegramAlert)(`✅ <b>TradeGrow — Live Feed RECOVERED</b>\n\n` +
                    `📊 Dhan WebSocket: ${passedCount}/${sampleTokens.length} core tokens matched cleanly.\n` +
                    `🕐 Feed is live again. LTPs are updating normally.`).catch(() => { });
                this.feedWasDown = false;
            }
            this.consecutiveAllMissCount = 0;
            if (missingCount > 0) {
                // Partial miss — some tokens missing but not all (partial degradation)
                console.warn(`[ReconciliationMonitor] ⚠️  ${missingCount}/${sampleTokens.length} sample tokens had no cached tick at all (partial feed issue).`);
            }
        }
        console.log(`[ReconciliationMonitor] Check complete. ${passedCount}/${sampleTokens.length} matched cleanly. Alerts: ${alertCount}. Missing: ${missingCount}.`);
        return this.lastReport;
    }
    getLastReport() {
        return this.lastReport;
    }
}
exports.ReconciliationMonitorService = ReconciliationMonitorService;
exports.reconciliationMonitor = ReconciliationMonitorService.getInstance();
