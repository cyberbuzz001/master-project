"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LinkPeService = void 0;
/**
 * LinkPe UPI Payment Service
 * Integrates LinkPe URL schema, NPCI UPI deep links, and dedicated app schemes (GPay, PhonePe, Paytm, BHIM)
 */
const qrcode_1 = __importDefault(require("qrcode"));
const schema_1 = require("../db/schema");
class LinkPeService {
    /**
     * Get LinkPe payment links, app-specific deep links, Android intent links, and local Base64 QR code
     */
    static async generatePaymentLink(amount, userId, customNote) {
        const safeAmount = Math.max(1, amount);
        // Fetch configured UPI ID & Merchant Name from database or environment
        const upiSetting = await (0, schema_1.queryOne)(`SELECT value FROM system_settings WHERE key = 'LINKPE_UPI_ID'`);
        const nameSetting = await (0, schema_1.queryOne)(`SELECT value FROM system_settings WHERE key = 'LINKPE_MERCHANT_NAME'`);
        const upiId = upiSetting?.value || process.env.LINKPE_UPI_ID || 'tradegrow@upi';
        const merchantName = nameSetting?.value || process.env.LINKPE_MERCHANT_NAME || 'Trade Grow Brokerage';
        const note = customNote || `TradeGrow_Deposit_${userId.slice(0, 8)}`;
        const pa = encodeURIComponent(upiId);
        const pn = encodeURIComponent(merchantName);
        const tn = encodeURIComponent(note);
        // LinkPe Web Payment Link
        const linkpeUrl = `https://ptprashanttripathi.github.io/linkpe/?pa=${pa}&pn=${pn}&amt=${safeAmount}&tn=${tn}`;
        // Generic & Dedicated Mobile UPI App Schemes (iOS / Standard)
        const upiDeepLink = `upi://pay?pa=${pa}&pn=${pn}&am=${safeAmount}&tn=${tn}&cu=INR`;
        const gpayDeepLink = `tez://upi/pay?pa=${pa}&pn=${pn}&am=${safeAmount}&tn=${tn}&cu=INR`;
        const phonepeDeepLink = `phonepe://pay?pa=${pa}&pn=${pn}&am=${safeAmount}&tn=${tn}&cu=INR`;
        const paytmDeepLink = `paytmmp://pay?pa=${pa}&pn=${pn}&am=${safeAmount}&tn=${tn}&cu=INR`;
        const bhimDeepLink = `bhim://pay?pa=${pa}&pn=${pn}&am=${safeAmount}&tn=${tn}&cu=INR`;
        // Dedicated Android Intent URLs (prevents auto-opening WhatsApp Pay on Android devices)
        const gpayIntentLink = `intent://pay?pa=${pa}&pn=${pn}&am=${safeAmount}&tn=${tn}&cu=INR#Intent;scheme=upi;package=com.google.android.apps.nbu.paisa.user;end`;
        const phonepeIntentLink = `intent://pay?pa=${pa}&pn=${pn}&am=${safeAmount}&tn=${tn}&cu=INR#Intent;scheme=upi;package=com.phonepe.app;end`;
        const paytmIntentLink = `intent://pay?pa=${pa}&pn=${pn}&am=${safeAmount}&tn=${tn}&cu=INR#Intent;scheme=upi;package=net.one97.paytm;end`;
        const bhimIntentLink = `intent://pay?pa=${pa}&pn=${pn}&am=${safeAmount}&tn=${tn}&cu=INR#Intent;scheme=upi;package=in.org.npci.upiapp;end`;
        const whatsappIntentLink = `intent://pay?pa=${pa}&pn=${pn}&am=${safeAmount}&tn=${tn}&cu=INR#Intent;scheme=upi;package=com.whatsapp;end`;
        // Dynamic Local Base64 QR Code Image Data URL (Zero external API dependencies, 100% reliable)
        let qrCodeUrl = '';
        try {
            qrCodeUrl = await qrcode_1.default.toDataURL(upiDeepLink, {
                width: 300,
                margin: 2,
                errorCorrectionLevel: 'M'
            });
        }
        catch {
            qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(upiDeepLink)}`;
        }
        return {
            upiId,
            merchantName,
            amount: safeAmount,
            note,
            linkpeUrl,
            upiDeepLink,
            gpayDeepLink,
            phonepeDeepLink,
            paytmDeepLink,
            bhimDeepLink,
            gpayIntentLink,
            phonepeIntentLink,
            paytmIntentLink,
            bhimIntentLink,
            whatsappIntentLink,
            qrCodeUrl
        };
    }
}
exports.LinkPeService = LinkPeService;
