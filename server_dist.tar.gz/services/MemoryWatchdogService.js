"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.memoryWatchdog = exports.MemoryWatchdogService = void 0;
const telegramAlert_1 = require("../utils/telegramAlert");
class MemoryWatchdogService {
    static instance;
    intervalTimer = null;
    isRunning = false;
    warningThresholdMB = 1536; // 1.5 GB
    criticalThresholdMB = 2048; // 2.0 GB
    lastStats = null;
    constructor() { }
    static getInstance() {
        if (!MemoryWatchdogService.instance) {
            MemoryWatchdogService.instance = new MemoryWatchdogService();
        }
        return MemoryWatchdogService.instance;
    }
    getStats() {
        const mem = process.memoryUsage();
        return {
            heapUsedMB: Number((mem.heapUsed / (1024 * 1024)).toFixed(2)),
            heapTotalMB: Number((mem.heapTotal / (1024 * 1024)).toFixed(2)),
            rssMB: Number((mem.rss / (1024 * 1024)).toFixed(2)),
            externalMB: Number((mem.external / (1024 * 1024)).toFixed(2)),
            timestamp: Date.now()
        };
    }
    start(intervalMs = 60000) {
        if (this.isRunning)
            return;
        this.isRunning = true;
        console.log(`[MemoryWatchdog] 🛡️ Memory watchdog active (Interval: ${intervalMs / 1000}s, Warning: ${this.warningThresholdMB}MB, Critical: ${this.criticalThresholdMB}MB)`);
        this.intervalTimer = setInterval(() => {
            this.checkMemory();
        }, intervalMs);
        // Initial check after 5s
        setTimeout(() => this.checkMemory(), 5000);
    }
    stop() {
        if (this.intervalTimer) {
            clearInterval(this.intervalTimer);
            this.intervalTimer = null;
        }
        this.isRunning = false;
        console.log('[MemoryWatchdog] Memory watchdog stopped.');
    }
    checkMemory() {
        const stats = this.getStats();
        this.lastStats = stats;
        const formattedLog = `[MemoryWatchdog] 📊 Heap: ${stats.heapUsedMB} MB / ${stats.heapTotalMB} MB | RSS: ${stats.rssMB} MB | External: ${stats.externalMB} MB`;
        if (stats.heapUsedMB >= this.criticalThresholdMB) {
            console.error(`[MemoryWatchdog] 🚨 CRITICAL: High Memory Usage! ${stats.heapUsedMB} MB exceeds critical threshold (${this.criticalThresholdMB} MB)`);
            (0, telegramAlert_1.sendTelegramAlert)(`🚨 *CRITICAL MEMORY ALERT*\nNode.js Process Heap: *${stats.heapUsedMB} MB*\nRSS: *${stats.rssMB} MB*\nImmediate audit required!`);
            // Trigger GC if exposed (node --expose-gc)
            if (global.gc) {
                try {
                    console.warn('[MemoryWatchdog] 🧹 Invoking manual garbage collection...');
                    global.gc();
                }
                catch (_) { }
            }
        }
        else if (stats.heapUsedMB >= this.warningThresholdMB) {
            console.warn(`[MemoryWatchdog] ⚠️ WARNING: Elevated Heap Usage! ${stats.heapUsedMB} MB exceeds warning threshold (${this.warningThresholdMB} MB)`);
        }
        else {
            // Normal structured log
            console.log(formattedLog);
        }
    }
}
exports.MemoryWatchdogService = MemoryWatchdogService;
exports.memoryWatchdog = MemoryWatchdogService.getInstance();
