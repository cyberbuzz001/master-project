"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SafetyLock = void 0;
/**
 * SAFETY LOCK MODULE — HARDCODED SYSTEM GUARD
 * Ensures that real-money trading functionality can NEVER be activated or called.
 */
class SafetyLock {
    static REAL_MONEY_TRADING_ALLOWED = false;
    static assertSimulationOnly(callingMethodName) {
        if (this.REAL_MONEY_TRADING_ALLOWED || process.env.REAL_MONEY_TRADING === 'true') {
            const errorMsg = `CRITICAL SAFETY VIOLATION: Attempted real-money operation in method '${callingMethodName}'. Platform is HARD-LOCKED to Virtual Paper Trading only.`;
            console.error(`[SAFETY LOCK ERROR] ${errorMsg}`);
            throw new Error(errorMsg);
        }
    }
}
exports.SafetyLock = SafetyLock;
