"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.pool = void 0;
exports.getPoolMetrics = getPoolMetrics;
exports.query = query;
exports.queryOne = queryOne;
exports.execute = execute;
exports.withTransaction = withTransaction;
exports.checkDatabaseHealth = checkDatabaseHealth;
const pg_1 = require("pg");
/**
 * PostgreSQL Connection Pool
 * P0-1 FIX: Replaces SQLite with PostgreSQL for multi-user concurrent load support.
 *
 * Pool sizing:
 *   - max: 20 connections for 100 concurrent users
 *   - idleTimeoutMillis: 30s — release idle connections
 *   - connectionTimeoutMillis: 5s — fail fast if pool exhausted
 */
function createPool() {
    const databaseUrl = process.env.DATABASE_URL;
    const poolConfig = {
        max: parseInt(process.env.PG_POOL_MAX || '50', 10),
        min: parseInt(process.env.PG_POOL_MIN || '5', 10),
        idleTimeoutMillis: 30000,
        connectionTimeoutMillis: 15000,
        keepAlive: true,
        keepAliveInitialDelayMillis: 10000,
        statement_timeout: parseInt(process.env.PG_STATEMENT_TIMEOUT || '10000', 10)
    };
    if (databaseUrl) {
        return new pg_1.Pool({
            connectionString: databaseUrl,
            ...poolConfig,
            ssl: process.env.PG_SSL === 'true' ? { rejectUnauthorized: false } : false
        });
    }
    // Individual env vars (local development)
    return new pg_1.Pool({
        host: process.env.PG_HOST || 'localhost',
        port: parseInt(process.env.PG_PORT || '5432', 10),
        database: process.env.PG_DATABASE || 'stocksharp',
        user: process.env.PG_USER || 'postgres',
        password: process.env.PG_PASSWORD || 'postgres',
        ...poolConfig,
        ssl: false
    });
}
exports.pool = createPool();
exports.pool.on('error', (err) => {
    if (err.message?.includes('connection') || err.message?.includes('timeout') || err.code === 'ECONNRESET') {
        // Suppress transient TCP idle timeout pool error
        return;
    }
    console.error('[PostgreSQL] Pool error:', err.message);
});
exports.pool.on('connect', (client) => {
    // Set statement timeout for every client session
    const timeoutMs = parseInt(process.env.PG_STATEMENT_TIMEOUT || '5000', 10);
    client.query(`SET statement_timeout = ${timeoutMs}`).catch(() => { });
});
/**
 * Get real-time connection pool metrics.
 */
function getPoolMetrics() {
    return {
        totalConnections: exports.pool.totalCount,
        idleConnections: exports.pool.idleCount,
        waitingRequests: exports.pool.waitingCount,
        maxLimit: parseInt(process.env.PG_POOL_MAX || '20', 10)
    };
}
/**
 * Execute a query and return all rows.
 * Only idempotent SELECT statements are retried on transient connection drop.
 */
async function query(text, params) {
    try {
        const result = await exports.pool.query(text, params);
        return result.rows;
    }
    catch (err) {
        const isReadOnly = text.trim().toUpperCase().startsWith('SELECT');
        const isTransientConnError = err.message?.includes('connection') || err.message?.includes('timeout') || err.code === 'ECONNRESET';
        if (isReadOnly && isTransientConnError) {
            const result = await exports.pool.query(text, params);
            return result.rows;
        }
        throw err;
    }
}
/**
 * Execute a query and return the first row or null.
 * Only idempotent SELECT statements are retried on transient connection drop.
 */
async function queryOne(text, params) {
    try {
        const result = await exports.pool.query(text, params);
        return result.rows[0] ?? null;
    }
    catch (err) {
        const isReadOnly = text.trim().toUpperCase().startsWith('SELECT');
        const isTransientConnError = err.message?.includes('connection') || err.message?.includes('timeout') || err.code === 'ECONNRESET';
        if (isReadOnly && isTransientConnError) {
            const result = await exports.pool.query(text, params);
            return result.rows[0] ?? null;
        }
        throw err;
    }
}
/**
 * Execute a query and return the row count affected.
 * Mutating writes (INSERT/UPDATE/DELETE) are NEVER blindly retried to prevent double-execution.
 */
async function execute(text, params) {
    const result = await exports.pool.query(text, params);
    return result.rowCount ?? 0;
}
/**
 * Run multiple queries in a single transaction.
 * Automatically rolls back on error.
 */
async function withTransaction(fn) {
    const client = await exports.pool.connect();
    try {
        await client.query('BEGIN');
        const result = await fn(client);
        await client.query('COMMIT');
        return result;
    }
    catch (err) {
        await client.query('ROLLBACK');
        throw err;
    }
    finally {
        client.release();
    }
}
/**
 * Check if the database is reachable.
 */
async function checkDatabaseHealth() {
    const start = Date.now();
    const poolMetrics = getPoolMetrics();
    try {
        await exports.pool.query('SELECT 1');
        return { healthy: true, latencyMs: Date.now() - start, pool: poolMetrics };
    }
    catch (err) {
        return { healthy: false, latencyMs: Date.now() - start, pool: poolMetrics, error: err.message };
    }
}
