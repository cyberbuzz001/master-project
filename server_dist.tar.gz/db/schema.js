"use strict";
/**
 * PostgreSQL Schema Loader
 * P0-1 FIX: Replaces SQLite better-sqlite3 with PostgreSQL via pg pool.
 *
 * This module:
 *  1. Ensures target database exists
 *  2. Reads and executes all SQL migration files in order
 *  3. Exports query helpers for use throughout the server
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.checkDatabaseHealth = exports.withTransaction = exports.execute = exports.queryOne = exports.query = exports.pool = void 0;
exports.runMigrations = runMigrations;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const pg_1 = require("pg");
const pool_1 = require("./pool");
Object.defineProperty(exports, "pool", { enumerable: true, get: function () { return pool_1.pool; } });
Object.defineProperty(exports, "query", { enumerable: true, get: function () { return pool_1.query; } });
Object.defineProperty(exports, "queryOne", { enumerable: true, get: function () { return pool_1.queryOne; } });
Object.defineProperty(exports, "execute", { enumerable: true, get: function () { return pool_1.execute; } });
Object.defineProperty(exports, "withTransaction", { enumerable: true, get: function () { return pool_1.withTransaction; } });
Object.defineProperty(exports, "checkDatabaseHealth", { enumerable: true, get: function () { return pool_1.checkDatabaseHealth; } });
async function ensureDatabaseExists() {
    const dbName = process.env.PG_DATABASE || 'stocksharp';
    const host = process.env.PG_HOST || 'localhost';
    const port = parseInt(process.env.PG_PORT || '5432');
    const user = process.env.PG_USER || 'postgres';
    const password = process.env.PG_PASSWORD || 'postgres';
    const client = new pg_1.Client({
        host,
        port,
        database: 'postgres', // connect to default postgres DB first
        user,
        password,
    });
    try {
        await client.connect();
        const res = await client.query(`SELECT 1 FROM pg_database WHERE datname = $1`, [dbName]);
        if ((res.rowCount ?? 0) === 0) {
            console.log(`[DB] Database "${dbName}" does not exist. Creating now...`);
            await client.query(`CREATE DATABASE "${dbName}"`);
            console.log(`[DB] ✅ Database "${dbName}" created successfully.`);
        }
    }
    catch (err) {
        console.warn(`[DB] Database creation check skipped/warning: ${err.message}`);
    }
    finally {
        await client.end().catch(() => { });
    }
}
/**
 * Run all SQL migration files in order (001_, 002_, etc.)
 * Idempotent: uses CREATE TABLE IF NOT EXISTS and ON CONFLICT DO NOTHING.
 */
async function runMigrations() {
    await ensureDatabaseExists();
    let migrationsDir = path_1.default.resolve(__dirname, '../../src/db/migrations');
    if (!fs_1.default.existsSync(migrationsDir)) {
        migrationsDir = path_1.default.resolve(__dirname, 'migrations');
    }
    if (!fs_1.default.existsSync(migrationsDir)) {
        console.warn('[DB] No migrations directory found at:', migrationsDir);
        return;
    }
    const files = fs_1.default.readdirSync(migrationsDir)
        .filter(f => f.endsWith('.sql'))
        .sort();
    console.log(`[DB] Running ${files.length} migration file(s) from ${migrationsDir}...`);
    for (const file of files) {
        const sql = fs_1.default.readFileSync(path_1.default.join(migrationsDir, file), 'utf8');
        try {
            await pool_1.pool.query(sql);
            console.log(`[DB] ✅ Migration applied: ${file}`);
        }
        catch (err) {
            // If constraint violation on re-running an old or superseded check constraint, log warning rather than halting server
            if (err.message && err.message.includes('check constraint') && err.message.includes('violated by some row')) {
                console.warn(`[DB] ⚠️ Migration warning on ${file}: ${err.message}. Continuing...`);
            }
            else {
                console.error(`[DB] ❌ Migration failed: ${file} — ${err.message}`);
                throw err;
            }
        }
    }
    console.log('[DB] All migrations complete.');
}
