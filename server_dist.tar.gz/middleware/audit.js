"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.logAuditAction = logAuditAction;
const schema_1 = require("../db/schema");
const crypto_1 = require("../utils/crypto");
/**
 * Log an auditable action to the audit_logs table.
 * PostgreSQL async version.
 */
async function logAuditAction(actorId, actorRole, action, resourceType, resourceId, beforeState, afterState, ipAddress, requestId) {
    try {
        await (0, schema_1.execute)(`INSERT INTO audit_logs (id, actor_id, actor_role, action, resource_type, resource_id, before_state, after_state, ip_address, request_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9::inet, $10)`, [
            'aud_' + (0, crypto_1.generateUUID)(),
            actorId, actorRole, action, resourceType,
            resourceId || null,
            beforeState ? JSON.stringify(beforeState) : null,
            afterState ? JSON.stringify(afterState) : null,
            ipAddress || '127.0.0.1',
            requestId || null
        ]);
    }
    catch (err) {
        // Audit log failures should never crash the app — log to stderr only
        console.error('[AuditLog] Failed to log action:', err.message);
    }
}
