"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.kycUpload = void 0;
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const multer_1 = __importDefault(require("multer"));
const crypto_1 = require("../utils/crypto");
// Ensure protected non-public KYC uploads directory exists
const getUploadsDir = () => {
    const dir = process.env.UPLOADS_DIR
        ? path_1.default.resolve(process.env.UPLOADS_DIR, 'kyc')
        : path_1.default.resolve(process.cwd(), 'uploads', 'kyc');
    if (!fs_1.default.existsSync(dir)) {
        fs_1.default.mkdirSync(dir, { recursive: true });
    }
    return dir;
};
const storage = multer_1.default.diskStorage({
    destination: (_req, _file, cb) => {
        const dir = getUploadsDir();
        cb(null, dir);
    },
    filename: (_req, file, cb) => {
        const ext = path_1.default.extname(file.originalname).toLowerCase() || '.png';
        const uniqueName = `kyc_doc_${Date.now()}_${(0, crypto_1.generateUUID)()}${ext}`;
        cb(null, uniqueName);
    }
});
const fileFilter = (_req, file, cb) => {
    const allowedExts = ['.jpg', '.jpeg', '.png', '.pdf', '.webp', '.heic', '.heif'];
    const allowedMimeTypes = [
        'image/jpeg',
        'image/jpg',
        'image/pjpeg',
        'image/png',
        'image/webp',
        'image/heic',
        'image/heif',
        'application/pdf',
        'application/octet-stream'
    ];
    const ext = path_1.default.extname(file.originalname).toLowerCase();
    const mime = (file.mimetype || '').toLowerCase();
    if (allowedExts.includes(ext) || allowedMimeTypes.includes(mime)) {
        cb(null, true);
    }
    else {
        cb(new Error(`Invalid document format (${file.originalname}). Only JPG, PNG, WEBP, and PDF files are allowed.`));
    }
};
exports.kycUpload = (0, multer_1.default)({
    storage,
    limits: {
        fileSize: 15 * 1024 * 1024, // 15 MB max size per file
    },
    fileFilter,
});
