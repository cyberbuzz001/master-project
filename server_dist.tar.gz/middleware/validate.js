"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateBody = validateBody;
exports.validateQuery = validateQuery;
/**
 * Zod-based request body validation middleware factory.
 * Returns a 400 with structured field errors if validation fails.
 */
function validateBody(schema) {
    return (req, res, next) => {
        const result = schema.safeParse(req.body);
        if (!result.success) {
            const zodErr = result.error;
            const errors = zodErr.issues.map((e) => ({
                field: e.path.join('.'),
                message: e.message
            }));
            const detailedMessage = errors.map(e => e.message).filter(Boolean).join('. ') || 'Request validation failed';
            res.status(400).json({
                success: false,
                error: {
                    code: 'VALIDATION_ERROR',
                    message: detailedMessage,
                    fields: errors
                }
            });
            return;
        }
        req.body = result.data; // Replace with parsed + coerced data
        next();
    };
}
function validateQuery(schema) {
    return (req, res, next) => {
        const result = schema.safeParse(req.query);
        if (!result.success) {
            const zodErr = result.error;
            const errors = zodErr.issues.map((e) => ({
                field: e.path.join('.'),
                message: e.message
            }));
            res.status(400).json({
                success: false,
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Query parameter validation failed',
                    fields: errors
                }
            });
            return;
        }
        next();
    };
}
