"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateUserRoleSchema = exports.UpdateUserStatusSchema = exports.UpdateRiskSettingSchema = exports.AdminAdjustBalanceSchema = exports.CreateWatchlistSchema = exports.AddWatchlistItemSchema = exports.SubmitOrderSchema = exports.ChangePasswordSchema = exports.TotpVerifySchema = exports.LoginSchema = exports.RegisterSchema = void 0;
const zod_1 = require("zod");
// ---------------------------------------------------
// AUTH SCHEMAS
// ---------------------------------------------------
exports.RegisterSchema = zod_1.z.object({
    username: zod_1.z.string()
        .trim()
        .min(2, 'Username must be at least 2 characters')
        .max(30, 'Username must be at most 30 characters')
        .regex(/^[a-zA-Z0-9_ ]+$/, 'Username may contain letters, numbers, spaces and underscores')
        .optional(),
    email: zod_1.z.string().trim().toLowerCase().email('Invalid email address').max(100),
    phoneNumber: zod_1.z.string()
        .trim()
        .min(10, 'Please enter a valid 10-digit mobile number')
        .max(16, 'Mobile number is too long')
        .regex(/^[+]?[0-9\s-]{10,16}$/, 'Please enter a valid mobile number (e.g. 9876543210 or +919876543210)'),
    password: zod_1.z.string()
        .min(6, 'Password must be at least 6 characters')
        .max(72, 'Password must be at most 72 characters'),
    otp: zod_1.z.string()
        .trim()
        .length(6, 'Verification code must be 6 digits')
        .regex(/^\d{6}$/, 'Verification code must be 6 numeric digits')
        .optional()
});
exports.LoginSchema = zod_1.z.object({
    email: zod_1.z.string().min(1, 'Email or username is required').max(100),
    password: zod_1.z.string().min(1, 'Password is required').max(72),
    totp_code: zod_1.z.string().length(6).optional()
});
exports.TotpVerifySchema = zod_1.z.object({
    code: zod_1.z.string().length(6, 'TOTP code must be 6 digits').regex(/^\d{6}$/, 'TOTP code must be numeric')
});
exports.ChangePasswordSchema = zod_1.z.object({
    current_password: zod_1.z.string().min(1),
    new_password: zod_1.z.string().min(8).max(72)
});
// ---------------------------------------------------
// ORDER SCHEMAS (Zod v3/v4 compatible)
// ---------------------------------------------------
exports.SubmitOrderSchema = zod_1.z.object({
    instrumentToken: zod_1.z.string().min(1, 'Instrument token is required').max(100),
    exchange: zod_1.z.enum(['NSE', 'BSE', 'NFO', 'BFO', 'MCX', 'CDS']),
    symbol: zod_1.z.string().min(1).max(50),
    side: zod_1.z.enum(['BUY', 'SELL']),
    quantity: zod_1.z.preprocess((val) => typeof val === 'string' ? parseInt(val, 10) : val, zod_1.z.number().int().positive('Quantity must be a positive integer').max(100000)),
    price: zod_1.z.preprocess((val) => typeof val === 'string' ? parseFloat(val) : (val ?? 0), zod_1.z.number().min(0).max(1000000)).default(0),
    triggerPrice: zod_1.z.preprocess((val) => typeof val === 'string' ? parseFloat(val) : (val ?? 0), zod_1.z.number().min(0).max(1000000)).optional().default(0),
    orderType: zod_1.z.enum(['MARKET', 'LIMIT', 'SL', 'SL_M']),
    productType: zod_1.z.enum(['MIS', 'CNC', 'NRML'])
});
// ---------------------------------------------------
// WATCHLIST SCHEMAS
// ---------------------------------------------------
exports.AddWatchlistItemSchema = zod_1.z.object({
    watchlistId: zod_1.z.string().min(1),
    instrumentToken: zod_1.z.string().min(1).max(100),
    symbol: zod_1.z.string().min(1).max(50),
    exchange: zod_1.z.enum(['NSE', 'BSE', 'NFO', 'BFO', 'MCX', 'CDS'])
});
exports.CreateWatchlistSchema = zod_1.z.object({
    name: zod_1.z.string().min(1, 'Watchlist name is required').max(50)
});
// ---------------------------------------------------
// ADMIN SCHEMAS
// ---------------------------------------------------
exports.AdminAdjustBalanceSchema = zod_1.z.object({
    amount: zod_1.z.preprocess((val) => typeof val === 'string' ? parseFloat(val) : val, zod_1.z.number()
        .refine(v => v !== 0, 'Amount cannot be zero')
        .refine(v => Math.abs(v) <= 100_000_000, 'Amount cannot exceed ₹10 Crore')),
    reason: zod_1.z.string().min(1, 'Reason is required').max(200)
});
exports.UpdateRiskSettingSchema = zod_1.z.object({
    key: zod_1.z.string().min(1).max(100),
    value: zod_1.z.string().min(1).max(500)
});
exports.UpdateUserStatusSchema = zod_1.z.object({
    status: zod_1.z.enum(['ACTIVE', 'SUSPENDED', 'DISABLED']),
    reason: zod_1.z.string().max(200).optional()
});
exports.UpdateUserRoleSchema = zod_1.z.object({
    role: zod_1.z.enum([
        'USER',
        'MANAGER',
        'FINANCE_MANAGER',
        'RISK_MANAGER',
        'OPERATIONS_MANAGER',
        'KYC_OFFICER',
        'DEALER',
        'SUPPORT_AGENT',
        'ANALYST',
        'READ_ONLY_AUDITOR',
        'ADMIN',
        'SUPER_ADMIN'
    ])
});
