"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const crypto_1 = __importDefault(require("crypto"));
const webhookSecurity_1 = require("../utils/webhookSecurity");
describe('Webhook Security & Authenticity Verification', () => {
    const testSecret = 'secret_test_meta_webhook_2026_xyz';
    const testPayload = JSON.stringify({
        object: 'whatsapp_business_account',
        entry: [{ id: '12345', changes: [] }]
    });
    test('accepts valid X-Hub-Signature-256 HMAC', () => {
        const rawBuffer = Buffer.from(testPayload, 'utf8');
        const hmac = crypto_1.default.createHmac('sha256', testSecret).update(rawBuffer).digest('hex');
        const header = `sha256=${hmac}`;
        const isValid = (0, webhookSecurity_1.verifyMetaSignature)(rawBuffer, header, testSecret);
        expect(isValid).toBe(true);
    });
    test('rejects tampered payload', () => {
        const rawBuffer = Buffer.from(testPayload, 'utf8');
        const hmac = crypto_1.default.createHmac('sha256', testSecret).update(rawBuffer).digest('hex');
        const header = `sha256=${hmac}`;
        const tamperedBuffer = Buffer.from(testPayload + ' ', 'utf8');
        const isValid = (0, webhookSecurity_1.verifyMetaSignature)(tamperedBuffer, header, testSecret);
        expect(isValid).toBe(false);
    });
    test('rejects incorrect secret', () => {
        const rawBuffer = Buffer.from(testPayload, 'utf8');
        const hmac = crypto_1.default.createHmac('sha256', 'wrong_secret').update(rawBuffer).digest('hex');
        const header = `sha256=${hmac}`;
        const isValid = (0, webhookSecurity_1.verifyMetaSignature)(rawBuffer, header, testSecret);
        expect(isValid).toBe(false);
    });
    test('rejects missing or malformed signature header', () => {
        const rawBuffer = Buffer.from(testPayload, 'utf8');
        expect((0, webhookSecurity_1.verifyMetaSignature)(rawBuffer, undefined, testSecret)).toBe(false);
        expect((0, webhookSecurity_1.verifyMetaSignature)(rawBuffer, 'invalid_header', testSecret)).toBe(false);
        expect((0, webhookSecurity_1.verifyMetaSignature)(rawBuffer, 'md5=abcd1234', testSecret)).toBe(false);
    });
    test('detects and suppresses replayed webhook message IDs', async () => {
        const uniqueMsgId = `wamid_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
        const firstSeen = await (0, webhookSecurity_1.isDuplicateWebhookEvent)('meta_test', uniqueMsgId);
        expect(firstSeen).toBe(false);
        const replayed = await (0, webhookSecurity_1.isDuplicateWebhookEvent)('meta_test', uniqueMsgId);
        expect(replayed).toBe(true);
        const anotherMsg = await (0, webhookSecurity_1.isDuplicateWebhookEvent)('meta_test', `${uniqueMsgId}_other`);
        expect(anotherMsg).toBe(false);
    });
});
